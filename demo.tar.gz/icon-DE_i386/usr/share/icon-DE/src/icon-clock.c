// g++ -o ./bin/icon-clock ./src/icon-clock.c -lX11 -lImlib2 -lXmu `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib-2.0/glib.h>
#include "Imlib2.h"

Display                        *disp;
Window                          win3;
Visual                         *vis;
Colormap                        cm;
int                             depth;
XSetWindowAttributes            attr;
int i3;
int mytoggle = 0;
Imlib_Image                 buffer3;
Imlib_Font                    font3;
int clock_move=0;
char Alarm1[3][32];
char say_text[3][1024];
int open_close[3];

#include "./other_src/wm_ctrl.c"
#include "./other_src/ReplaceStr.c"
#include "./other_src/MWMHints.h"

void showwin3(int screenX,int screenY)
{
    char text[1024];    
    int text_w,text_h;
    char aa[32];
    imlib_context_set_font(font3);
    imlib_context_set_color(0, 0, 0, 255);
    time_t now_time;
    now_time=time(0);
    if (i3==1)
    {
        strftime(text, sizeof(text), "  %H:%M  ",localtime(&now_time) );
        i3=0;
    } else {
        strftime(text, sizeof(text), "  %H %M  ",localtime(&now_time) );
        i3=1;
        strftime(aa, sizeof(aa), "%H:%M",localtime(&now_time) );
        if ((open_close[0]==1) and (strcmp(aa,Alarm1[0])==0 ))
            sprintf(text,"%s",say_text[0]);
        if ((open_close[1]==1) and (strcmp(aa,Alarm1[1])==0 ))
            sprintf(text,"%s",say_text[1]);
        if ((open_close[2]==1) and (strcmp(aa,Alarm1[2])==0 ))
            sprintf(text,"%s",say_text[2]);
    }
    
    imlib_get_text_size(text, &text_w, &text_h);
    XRaiseWindow(disp,win3);
    XMapWindow(disp, win3);
    imlib_context_set_drawable(win3); 
         /* draw the range */
    imlib_context_set_image(buffer3);
    imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
         /* free it */
            //         imlib_free_color_range();
    imlib_context_set_image(buffer3);
    imlib_context_set_drawable(win3); 
    imlib_render_image_on_drawable(0, 0); 
    imlib_context_set_font(font3);
    imlib_context_set_color(0, 0, 0, 255);
    imlib_text_draw(5,2,text);
    /* set the buffer image as our current image */
    imlib_context_set_image(buffer3);
    imlib_render_image_on_drawable(0, 0); 
    imlib_context_set_image(buffer3);
}

int main(int argc, char **argv)
{
    XEvent                      ev;
    const char                 *display_name = getenv("DISPLAY");
    char                        text[1024];
    char                       *skip;
    Imlib_Color_Range            range;
    int    text_w, text_h;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }

    int screenX=10;
    int screenY=10;
    char submenue[1000];
    char ch2[1024];
    int n=0;
    int Tiling_mode=0;
    char title_win_xy2[6][50];
    char title_win_xy3[9][50];
    char title_win_xy4[12][50];
    char usermenufile[1024];
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));
    int bord=1;
    if ( strcmp(home,"") == 0 )

    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
//----arguments x y width height lower/raise(0/1) picture hidemode
    if ( argc == 1 )
    {
        printf("usage: icon-clock x y skip have_title(0/1)\n");
        return 1;
    }
    if ( argc != 5 )
    {
        return 1;
    }
 // printf("ok\n");
    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    skip=argv[3];
    sscanf(argv[4], "%d", &bord);

    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);

    attr.override_redirect=True;

     /**
        * Start rendering
        */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
   
    unsigned long i=1;
    i3=1;
    Window cur_win=0;
//    Window cur_win_id;
    MWMHints mwmhints;
    Atom prop;
    MWMHints *hints;
    Atom type;
    int format;
    unsigned long nitems;
    unsigned long bytes_after;

    int xfd = ConnectionNumber(disp);
    long ticks;
    fd_set rfds;
    time_t now_time;
    struct timeval now, tm,LastTime;
    now_time=time(0);

    list_windows(disp,skip);
    
    gettimeofday(&LastTime, 0);


    buffer3 = imlib_create_image(1000, 30);    
    char font_path[1024];
    sprintf(font_path,"%s/.icon-DE/fonts",home);
    imlib_add_path_to_font_path(font_path);
    imlib_add_path_to_font_path("/usr/share/fonts/truetype/wqy/");
    imlib_add_path_to_font_path("/usr/share/fonts/wenquanyi/wqy-zenhei/");
    font3 = imlib_load_font("Vera/11");
    if (font3 == NULL)
        font3 = imlib_load_font("wqy-zenhei.ttc/11");
    imlib_context_set_font(font3);
    imlib_context_set_color(0, 0, 0, 255);
    if (i3==1)
    {
        strftime(text, sizeof(text), "%H:%M",localtime(&now_time) );
        i3=0;
    } else {
        strftime(text, sizeof(text), "%H %M",localtime(&now_time) );
        i3=1;
    }
    imlib_get_text_size(text, &text_w, &text_h);
    win3=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,text_w+30,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
    XSelectInput(disp, win3, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
//    imlib_free_font();

    Tiling_mode=0;
    unsigned long action;
    gchar *tmp_prop2, *tmp2;
    gchar *tmp_prop1, *tmp1;

//    char command[1024]=" ";
    FILE *freeNum;

    char rcfile[10]="clock.rc";
    sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
    if (access(usermenufile,0)==-1)
    {
        system("mkdir ~/.icon-DE");
        system("cp /etc/icon-de/clock.rc ~/.icon-DE/");
    }
    freeNum=fopen(usermenufile,"r");
    if ( freeNum==NULL)
    { 
        printf("error on open %s\n",usermenufile); 
        exit(1); 
    }
    char buffer_rc[1024];

    while ( ! feof(freeNum) )
    {
        fgets(buffer_rc,1024,freeNum);
        for (n=0;n<1024;n++)
            if (buffer_rc[n]=='\n') buffer_rc[n]='\0';
//        printf("%s\n",buffer_rc); 
//        for (n=0;n<1024;n++)
//            command[n]='\0';
        if (strcmp(buffer_rc,"")!=0 )
        {
            sprintf(ch2,"%c",buffer_rc[0]);
            if (strcmp(ch2,"#")!=0 ) 
            {
                sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
                if (strcmp(ch2,"Alarm1:")==0 )
                {
                    for (n=0;n<1024-7;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+7];
                    } 
                    for (n=1016;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    int m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(Alarm1[0],"%s",ch2);
                    m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(say_text[0],"%s",ch2);
                    open_close[0] = atoi(buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
                if (strcmp(ch2,"Alarm2:")==0 )
                {
                    for (n=0;n<1024-7;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+7];
                    } 
                    for (n=1016;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    int m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(Alarm1[1],"%s",ch2);
                    m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(say_text[1],"%s",ch2);
                    open_close[1] = atoi(buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
                if (strcmp(ch2,"Alarm3:")==0 )
                {
                    for (n=0;n<1024-7;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+7];
                    } 
                    for (n=1016;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    int m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(Alarm1[2],"%s",ch2);
                    m=0;
//                    ch='a';
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer_rc[m] != ' ' )
                    {
                        sprintf(ch2,"%s%c",ch2,buffer_rc[m]);
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    } 
                    sprintf(say_text[2],"%s",ch2);
                    open_close[2] = atoi(buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_1_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[0],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_1_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[1],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_2_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[2],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_2_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[3],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_3_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[4],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window02_3_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy2[5],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_1_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[0],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_1_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[1],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_1_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[2],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_2_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[3],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_2_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[4],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_2_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[5],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_3_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[6],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_3_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[7],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window03_3_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy3[8],"%s",buffer_rc);
                }
                
                
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_1_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[0],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_1_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[1],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_1_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[2],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_1_4:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[3],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_2_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[4],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_2_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[5],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_2_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[6],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_2_4:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[7],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_3_1:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[8],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_3_2:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[9],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_3_3:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[10],"%s",buffer_rc);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15],buffer_rc[16],buffer_rc[17],buffer_rc[18],buffer_rc[19]);
                if (strcmp(ch2,"Tiling_window04_3_4:")==0 )
                {
                    for (n=0;n<1024-20;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+20];
                    } 
                    for (n=1003;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(title_win_xy4[11],"%s",buffer_rc);
                }
            }
        }        
    }
    fclose(freeNum);


    while (1)
    {
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case Expose:
                break;
            case MotionNotify:
                break;
            default:
                break;
            case EnterNotify:		
                break;
            case LeaveNotify:		
                if (clock_move==0)
                {
//                    XMoveWindow(disp, win, screenX, screenY+30);
                    XMoveWindow(disp, win3, screenX, screenY+30);
                    clock_move=1;
                } else {
//                    XMoveWindow(disp, win, screenX, screenY);
                    XMoveWindow(disp, win3, screenX, screenY);
                    clock_move=0;
                }
                break;
            case ButtonPress:				
                int is_5=0;
                int is_6=0;
                if(ev.xbutton.button==1)
                {
                    if (list_windows(disp,skip)!=EXIT_FAILURE)
                    {
                        bord=1;
                        memset(&mwmhints, 0, sizeof(mwmhints));
                        prop = XInternAtom(disp, "_MOTIF_WM_HINTS", False);
                        mwmhints.flags = MWM_HINTS_DECORATIONS;
                        mwmhints.decorations = 0;
                        for (i=0;i<win_count;i++)
                        {
                            if (win_pid_list[i]!=0)
                            {
                                XChangeProperty(disp, win_pid_list[i], prop, prop, 32, PropModeReplace,
                                            (unsigned char *) &mwmhints,
                                            PROP_MWM_HINTS_ELEMENTS);
                            }
                        }
                        sprintf(submenue,"icon-wharf BORD 1");
                        system(submenue);
                    }    
                    break;
                }
                if(ev.xbutton.button==2)
                {
                    if (get_active_window(disp)!=0)
                    {    
                        if (bord==0)
                        {
                            bord=1;
                            memset(&mwmhints, 0, sizeof(mwmhints));
                            prop = XInternAtom(disp, "_MOTIF_WM_HINTS", False);
                            mwmhints.flags = MWM_HINTS_DECORATIONS;
                            mwmhints.decorations = 0;
                            XChangeProperty(disp, get_active_window(disp), prop, prop, 32, PropModeReplace,
                                            (unsigned char *) &mwmhints,
                                            PROP_MWM_HINTS_ELEMENTS);
                        }     else     {
                            bord=0;
                            memset(&mwmhints, 0, sizeof(mwmhints));
                            prop = XInternAtom(disp, "_MOTIF_WM_HINTS", FALSE);
                            hints=(MWMHints*)&prop;
                            XGetWindowProperty( disp,get_active_window(disp),
                                            prop,0,5,
                                            False,AnyPropertyType,&type,&format,&nitems,
                                            &bytes_after,(unsigned char **)&hints );
                            if ( type != None )
                            {
                                hints->flags=MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
                                hints->functions|=( MWM_FUNC_MOVE | MWM_FUNC_CLOSE | MWM_FUNC_MINIMIZE | MWM_FUNC_MAXIMIZE | MWM_FUNC_RESIZE );
                                hints->decorations|=MWM_DECOR_ALL;
                            }
                            else
                            {
                                memset( &prop,0,sizeof( MWMHints ) );
                                hints=(MWMHints*)&prop;
                                hints->flags=( MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS);
                                hints->functions=( MWM_FUNC_MOVE | MWM_FUNC_CLOSE | MWM_FUNC_MINIMIZE | MWM_FUNC_MAXIMIZE | MWM_FUNC_RESIZE );
                                hints->decorations=( MWM_DECOR_ALL );
                            }

                            XChangeProperty( disp,get_active_window(disp),prop,prop,32,
                                    PropModeReplace,(const unsigned char*)&prop,5 );
                            if ( hints != (MWMHints*)&prop ) XFree( hints );
                        }
                    }
                    break;
                }
                if(ev.xbutton.button==3)
                {
                    if (list_windows(disp,skip)!=EXIT_FAILURE)
                    {
                        bord=0;
                        memset(&mwmhints, 0, sizeof(mwmhints));

                        for (i=0;i<win_count;i++)
                        {
                            if (win_pid_list[i]!=0)
                            {
                                prop = XInternAtom(disp, "_MOTIF_WM_HINTS", FALSE);
                                hints=(MWMHints*)&prop;
                                XGetWindowProperty( disp,win_pid_list[i],
                                            prop,0,5,
                                            False,AnyPropertyType,&type,&format,&nitems,
                                            &bytes_after,(unsigned char **)&hints );
                                if ( type != None )
                                {
                                    hints->flags=MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS;
                                    hints->functions|=( MWM_FUNC_MOVE | MWM_FUNC_CLOSE | MWM_FUNC_MINIMIZE | MWM_FUNC_MAXIMIZE | MWM_FUNC_RESIZE );
                                    hints->decorations|=MWM_DECOR_ALL;
                                }
                                else
                                {
                                    memset( &prop,0,sizeof( MWMHints ) );
                                    hints=(MWMHints*)&prop;
                                    hints->flags=( MWM_HINTS_FUNCTIONS | MWM_HINTS_DECORATIONS);
                                    hints->functions=( MWM_FUNC_MOVE | MWM_FUNC_CLOSE | MWM_FUNC_MINIMIZE | MWM_FUNC_MAXIMIZE | MWM_FUNC_RESIZE );
                                    hints->decorations=( MWM_DECOR_ALL );
                                }
                                XChangeProperty( disp,win_pid_list[i],prop,prop,32,
                                        PropModeReplace,(const unsigned char*)&prop,5 );
                            }
                        }
                        if ( hints != (MWMHints*)&prop ) XFree( hints );
                        sprintf(submenue,"icon-wharf BORD 0 ");
                        system(submenue);
                    }    
                    break;
                }
                if(ev.xbutton.button==4)
                {
                    list_windows(disp,skip);
                    cur_win=get_active_window(disp);
//                    printf("%d\n",win_count);
                    if (win_count==2)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[0]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[1]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[0]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[1]);
                                }            
                                Tiling_mode=1;
                            }    
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[2]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[3]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[2]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[3]);
                                }            
                            }        
                            Tiling_mode=2;
                        } else if (Tiling_mode==2)    {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[4]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[5]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[4]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[5]);
                                }            
                            }        
                            Tiling_mode=3;
                        } else if (Tiling_mode==3) {
                            if (cur_win!=0)
                            {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                        action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                    } 
                    if (win_count==3)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[0]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy3[1]);
                                                is_5=1;
                                            } else
                                                window_move_resize(disp,win_pid_list[i],title_win_xy3[2]);
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[0]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[1]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[2]);
                                }            
                            }
                            Tiling_mode=1;
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[3]);
                                    else
                                    {
                                        if (is_5==0)
                                        {
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[4]);
                                            is_5=1;
                                        } else
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[5]);
                                    }    
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[3]);
                                    if (i==1) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[4]);
                                    if (i==2) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[5]);
                                } 
                            }    
                            Tiling_mode=2;
                        } else if (Tiling_mode==2) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[6]);
                                    else
                                    {
                                        if (is_5==0)
                                        {
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[7]);
                                            is_5=1;
                                        } else
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[8]);
                                    }    
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[6]);
                                    if (i==1) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[7]);
                                    if (i==2) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[8]);
                                } 
                            }    
                            Tiling_mode=3;
                        } else {
                            if (cur_win!=0) {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                    action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                        break;
                    }    
                    if (win_count==4)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[0]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[1]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[2]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[3]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[0]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[1]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[2]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[3]);
                                }            
                            }
                            Tiling_mode=1;
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[4]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[5]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[6]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[7]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[4]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[5]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[6]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[7]);
                                }            
                            }
                            Tiling_mode=2;
                        } else if (Tiling_mode==2) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[8]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[9]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[10]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[11]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[8]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[9]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[10]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[11]);
                                }            
                            }
                            Tiling_mode=3;
                        } else {
                            if (cur_win!=0) {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                    action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                        break;
                    }    
                }
                if(ev.xbutton.button==5)
                {
                    list_windows(disp,skip);
                    cur_win=get_active_window(disp);
                    if (win_count==2)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[0]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[1]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[0]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[1]);
                                }            
                                Tiling_mode=1;
                            }    
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[2]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[3]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[2]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[3]);
                                }            
                            }        
                            Tiling_mode=2;
                        } else if (Tiling_mode==2)    {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[4]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[5]);
//                                    printf("%s %d \n",title_win_xy[0],win_pid_list[i]);
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[4]);
                                    else
                                        window_move_resize(disp,win_pid_list[i],title_win_xy2[5]);
                                }            
                            }        
                            Tiling_mode=3;
                        } else if (Tiling_mode==3) {
                            if (cur_win!=0)
                            {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                        action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                    } 
                    if (win_count==3)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[0]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy3[1]);
                                                is_5=1;
                                            } else
                                                window_move_resize(disp,win_pid_list[i],title_win_xy3[2]);
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[0]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[1]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[2]);
                                }            
                            }
                            Tiling_mode=1;
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[3]);
                                    else
                                    {
                                        if (is_5==0)
                                        {
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[4]);
                                            is_5=1;
                                        } else
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[5]);
                                    }    
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[3]);
                                    if (i==1) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[4]);
                                    if (i==2) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[5]);
                                } 
                            }    
                            Tiling_mode=2;
                        } else if (Tiling_mode==2) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                    if (win_pid_list[i]==cur_win) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[6]);
                                    else
                                    {
                                        if (is_5==0)
                                        {
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[7]);
                                            is_5=1;
                                        } else
                                            window_move_resize(disp,win_pid_list[i],title_win_xy3[8]);
                                    }    
                                } else { 
                                    if (i==0) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[6]);
                                    if (i==1) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[7]);
                                    if (i==2) 
                                        window_move_resize(disp,win_pid_list[i],title_win_xy3[8]);
                                } 
                            }    
                            Tiling_mode=3;
                        } else {
                            if (cur_win!=0) {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                    action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                    }    
                    if (win_count==4)
                    {
                        if (Tiling_mode==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[0]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[1]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[2]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[3]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[0]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[1]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[2]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[3]);
                                }            
                            }
                            Tiling_mode=1;
                        } else if (Tiling_mode==1) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[4]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[5]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[6]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[7]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[4]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[5]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[6]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[7]);
                                }            
                            }
                            Tiling_mode=2;
                        } else if (Tiling_mode==2) {
                            for (i=0;i<win_count;i++)
                            {
                                init_window(win_pid_list[i]);
                                if (cur_win!=0)
                                {
                                        if (win_pid_list[i]==cur_win) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[8]);
                                        else
                                        {
                                            if (is_5==0)
                                            {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[9]);
                                                is_5=1;
                                                is_6=0;
                                            } else if (is_6==0) {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[10]);
                                                is_6=1;
                                            } else {
                                                window_move_resize(disp,win_pid_list[i],title_win_xy4[11]);
                                                is_5=0;
                                                is_6=0;
				            }
                                        }    
                                } else { 
                                        if (i==0) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[8]);
                                        if (i==1) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[9]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[10]);
                                        if (i==2) 
                                            window_move_resize(disp,win_pid_list[i],title_win_xy4[11]);
                                }            
                            }
                            Tiling_mode=3;
                        } else {
                            if (cur_win!=0) {
                                const char *p1="fullscreen", *p2="above";
                                Atom prop1 = 0;
                                Atom prop2 = 0;
                                action = _NET_WM_STATE_ADD;
                                tmp_prop2 = g_strdup_printf("_NET_WM_STATE_%s", tmp2 = g_ascii_strup(p2, -1));
                                p_verbose("State 2: %s\n", tmp_prop2); 
                                prop2 = XInternAtom(disp, tmp_prop2, False);
                                tmp_prop1 = g_strdup_printf("_NET_WM_STATE_%s", tmp1 = g_ascii_strup(p1, -1));
                                p_verbose("State 1: %s\n", tmp_prop1); 
                                prop1 = XInternAtom(disp, tmp_prop1, False);
                                client_msg(disp, cur_win, "_NET_WM_STATE", 
                                    action, (unsigned long)prop1, (unsigned long)prop2, 0, 0);
                            }	    
                            Tiling_mode=0;
                        }
                    }    
                    break;
                }    
            }
        } else {
                //display 是由 XopenDisplay 返回的 Display *
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=1000)
            {
                gettimeofday(&LastTime, 0);
                showwin3(screenX,screenY);
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=200000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        } /* End else*/
    }
    imlib_context_set_image(buffer3);
    imlib_context_set_drawable(win3); 
    imlib_render_image_on_drawable(0, 0); 
    imlib_context_set_image(buffer3);
    imlib_context_set_font(font3);
    imlib_context_set_color(0, 0, 0, 255);
    imlib_text_draw(5,2,text);
    imlib_free_font();
    /* set the buffer image as our current image */
    imlib_context_set_image(buffer3);
    imlib_render_image_on_drawable(0, 0); 
    imlib_context_set_image(buffer3);
    imlib_free_image();

    return 0;
}

