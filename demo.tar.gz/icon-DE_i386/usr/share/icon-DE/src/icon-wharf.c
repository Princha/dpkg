// g++ -o ./icon-wharf ./icon-wharf.c    -lX11
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <X11/Xlib.h>
#include <X11/extensions/XShm.h>
#include <X11/Xutil.h>
#include <X11/extensions/shape.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>

Display                        *disp;
Window                          win;
Visual                         *vis;
Colormap                        cm;
int                             depth;
XSetWindowAttributes attr;
char *appToRun;

int main(int argc, char **argv)
{
    int                                 x, y;
//    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
    if (display_name == NULL)
        display_name = ":0";
//    disp = XOpenDisplay(display_name);
//    if (disp == NULL) 
//    {
//        fprintf(stderr, "Can't open display %s\n", display_name);
//        return 1;
//    }

    int mode=1;
    char *selectedgroup;
    int raisemode;
    int xmain;
    int ymain;
    int sizemain;
    int gapmain;
    int sizesub;
    int gapsub;
    int autohidemainbutton;
    int autohideSubbutton;
    int MouseMoveOpenSubIcon;
    char usermenufile[1024];
    char *run_mode;
    int i=0;
    char command[1024]=" ";
    FILE *freeNum;
    char skip[1024]=" ";
    int run=0;
    char win_move[1024]="0,0,1280,1024";
    int bord=0;
    double trans_icon=0.65;
    double trans_wind=0.85;
//    char title_win_xy[10][1024];
    char home[1024];
    int l_id=0;
    
    sprintf(home,"%s",getenv("HOME"));
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
    if ( argc == 2 ) 
    {
        run_mode=argv[1];
        if (strcmp(run_mode,"INIT")==0 )
        {
            mode=2;
            run=1;
        }
        if (strcmp(run_mode,"RESET")==0 )
            mode=2;
    }    
    if ( argc == 3 ) 
    {
        run_mode=argv[1];
        sscanf(argv[2], "%d", &bord);
        if (strcmp(run_mode,"START")==0 )
            mode=0;
        if (strcmp(run_mode,"BORD")==0 )
            mode=3;
    }
    if ( argc == 6 ) 
    {
        sscanf(argv[1], "%d", &x);
        sscanf(argv[2], "%d", &y);
        selectedgroup=argv[3];
        sscanf(argv[4], "%d", &raisemode);
        sscanf(argv[5], "%d", &bord);
        mode=1;
    }
    char rcfile[10]="wharf.rc";
    sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
    if (access(usermenufile,0)==-1)
    {
        system("mkdir ~/.icon-DE");
        system("mkdir ~/.icon-DE/fonts");
        if (access("/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",0)!=-1)
            system("cp /usr/share/fonts/truetype/wqy/wqy-zenhei.ttc ~/.icon-DE/fonts/Vera.ttf");
        if (access("/usr/share/fonts/wenquanyi/wqy-zenhei/wqy-zenhei.ttc",0)!=-1)
            system("cp /usr/share/fonts/wenquanyi/wqy-zenhei/wqy-zenhei.ttc ~/.icon-DE/fonts/Vera.ttf");
        system("cp -a /usr/share/icon-DE/* ~/.icon-DE/");
        system("cp -a /etc/icon-de/* ~/.icon-DE/");
    }
    freeNum=fopen(usermenufile,"r");
    if ( freeNum==NULL)
    { 
        printf("error on open %s\n",usermenufile); 
        exit(1); 
    }
    int gc=0;
    int gd=1;
    char ch2[1024];
    char buffer[1024];
//    char ch;
    int n=0;
    int m=0;
    char group[1024]="0";
    int show_sys_inf=0;
    if (mode==2)
    {
        system("killall icon-dock 2>/dev/null");
        system("killall icon-clock 2>/dev/null");
        system("killall iconrun3 2>/dev/null");
        system("killall iconrun2 2>/dev/null");
        system("killall iconrun1 2>/dev/null");
    }        
    if (mode==3)
    {
        system("killall icon-dock 2>/dev/null");
        system("killall iconrun3 2>/dev/null");
        system("killall iconrun2 2>/dev/null");
        system("killall iconrun1 2>/dev/null");
    }        
    while ( ! feof(freeNum) )
    {
        fgets(buffer,1024,freeNum);
        l_id=l_id+1;
        for (n=0;n<1024;n++)
            if (buffer[n]=='\n') buffer[n]='\0';
//        printf("%s\n",buffer); 
        for (n=0;n<1024;n++)
          command[n]='\0';
        if (strcmp(buffer,"")!=0 )
        {
            sprintf(ch2,"%c",buffer[0]);
            if (strcmp(ch2,"#")!=0 ) 
            {
                sprintf(ch2,"%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]);
                if (strcmp(ch2,"skip:")==0 )
                {
                    for (n=0;n<1019;n++)
                    {
                         buffer[n]=buffer[n+5];
                    } 
                    for (n=1018;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    sprintf(skip,"%s",buffer);
                }
                sprintf(ch2,"%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3]);
                if ((strcmp(ch2,"run:")==0 ) and (run==1))
                {
                    for (n=0;n<1020;n++)
                    {
                         buffer[n]=buffer[n+4];
                    } 
                    for (n=1019;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    system(buffer);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11],buffer[12]);                //show_sys_inf:
                if (strcmp(ch2,"show_sys_inf:")==0 )
                {
                    for (n=0;n<1024-13;n++)
                    {
                         buffer[n]=buffer[n+13];
                    } 
                    for (n=1010;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    show_sys_inf=atoi(buffer);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);                //show_sys_inf:
                if ((strcmp(ch2,"have_title:")==0 ) and (mode==2))
                {
                    for (n=0;n<1024-11;n++)
                    {
                         buffer[n]=buffer[n+11];
                    } 
                    for (n=1012;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    bord=atoi(buffer);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);                //show_sys_inf:
                if (strcmp(ch2,"trans_icon:")==0 )
                {
                    for (n=0;n<1024-11;n++)
                    {
                         buffer[n]=buffer[n+11];
                    } 
                    for (n=1012;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    trans_icon=atof(buffer);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);                //show_sys_inf:
                if (strcmp(ch2,"trans_wind:")==0 )
                {
                    for (n=0;n<1024-11;n++)
                    {
                         buffer[n]=buffer[n+11];
                    } 
                    for (n=1012;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    trans_wind=atof(buffer);
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11],buffer[12],buffer[13]);
                if (bord==0)
                {
                    if (strcmp(ch2,"windows_where:")==0 )
                    {
                        for (n=0;n<1010;n++)
                        {
                             buffer[n]=buffer[n+14];
                        } 
                        for (n=1009;n<1024;n++)
                        {
                             buffer[n]='\0';
                        } 
                        sprintf(win_move,"%s",buffer);
                    }    
                } else {
                    if (strcmp(ch2,"no_bord_where:")==0 )
                    {
                        for (n=0;n<1010;n++)
                        {
                             buffer[n]=buffer[n+14];
                        } 
                        for (n=1009;n<1024;n++)
                        {
                             buffer[n]='\0';
                        } 
                        sprintf(win_move,"%s",buffer);
                    }    
                }
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);
                if (strcmp(ch2,"baseconfig:")==0 )
                {
                    for (n=0;n<1013;n++)
                    {
                         buffer[n]=buffer[n+11];
                    } 
                    for (n=1012;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
//                    printf("baseconfig:%s\n",buffer); 
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    xmain = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    ymain = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    sizemain = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    gapmain = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    sizesub = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    gapsub = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    raisemode = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    autohidemainbutton = atoi(ch2);
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while ( buffer[m] != ' ' )
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m+1];
                    } 
                    for (n=1024-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    } 
                    autohideSubbutton = atoi(ch2);
                    MouseMoveOpenSubIcon= atoi(buffer);
                    if (mode==2)
                    {
                        sprintf(command,"icon-clock %d %d \"%s\" %d &",xmain+sizemain-20,ymain,skip,bord);
                        system(command);
                    }
                }
                sprintf(ch2,"%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]);
                if (strcmp(ch2,"group")==0 )
                {
                    m=0;
                    for (n=0;n<1024;n++)
                        ch2[n]='\0';
                    while (( buffer[m] != ':' ) and (buffer[m] != '#'))
                    {
                        ch2[m]=buffer[m];
                        m=m+1;
                    }
                    for (n=0;n<m-5;n++)
                    {
                         ch2[n]=ch2[n+5];
                    } 
                    for (n=m-5;n<m;n++)
                    {
                         ch2[n]='\0';
                    }
                    sprintf(group,"%s",ch2);
                    if (buffer[m+1] == ' ')
                        m=m+2;
                    else
                        m=m+1;
                    for (n=0;n<1024-m;n++)
                    {
                         buffer[n]=buffer[n+m];
                    } 
                    for (n=1023-m;n<1024;n++)
                    {
                         buffer[n]='\0';
                    }
                    for (n=0;n<1024;n++)
                    { 
                        if (buffer[n]=='\n')
                        {
                            buffer[n]='\0';
                        }
                    }        

                    if ((mode==2) or (mode==3))
                    {
                        sprintf(command,"iconrun1 %d %d %d %d %d %s %s %d %d \"%s\" \"%s\" %d %d %f &",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,group,buffer,autohidemainbutton,MouseMoveOpenSubIcon,skip,win_move,bord,show_sys_inf,trans_icon);
//                        printf("iconrun1 %d %d %d %d %d %s %s %d %d \"%s\" \"%s\" %d %d %f &\n",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,group,buffer,autohidemainbutton,MouseMoveOpenSubIcon,skip,win_move,bord,show_sys_inf,trans_icon);
                        system(command);
                        gc=gc+1;
                    }
                    if (mode==0)
                    {    //usage: iconrun2 x y width height lower/raise(0/1) autohideSubbutton(0/1/2) MouseMoveOpenSubIcon(0/1) group single/group(1)    windows_class_for_skip windows_move_to(x,y,w,h) bord(0/1) trans_icon trans_wind image tag\n");
                        sprintf(command,"iconrun2 %d %d %d %d %d %d %d %s 1 \"%s\" \"%s\" %d %f %f %s %d &",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,MouseMoveOpenSubIcon,group,skip,win_move,bord,trans_icon,trans_wind,buffer,l_id);
//                        printf("iconrun2 %d %d %d %d %d %d %d %s 1 \"%s\" \"%s\" %d %f %f %s %d &\n",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,MouseMoveOpenSubIcon,group,skip,win_move,bord,trans_icon,trans_wind,buffer,l_id);
                        system(command);
                        gc=gc+1;
                    }
                }
                else
                {
                    sprintf(ch2,"%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5]);
                    if (strcmp(ch2,"single")==0 )
                    {
                        m=0;
                        for (n=0;n<1024;n++)
                            ch2[n]='\0';
                        while (( buffer[m] != ':' ) and (buffer[m] != '#'))
                        {
                            ch2[m]=buffer[m];
                            m=m+1;
                        }
                        for (n=0;n<m-6;n++)
                        {
                             ch2[n]=ch2[n+6];
                        } 
                        for (n=m-6;n<m;n++)
                        {
                             ch2[n]='\0';
                        }

                        for (n=0;n<1024;n++)
                        { 
                            if (buffer[n]=='\n')
                            {
                                buffer[n]='\0';
                            }
                        }
                        sprintf(group,"%s",ch2);
                        if (buffer[m+1] == ' ')
                            m=m+2;
                        else
                            m=m+1;
                        for (n=0;n<1024-m;n++)
                        {
                             buffer[n]=buffer[n+m];
                        } 
                        for (n=1023-m;n<1024;n++)
                        {
                             buffer[n]='\0';
                        } 
                        if (mode==0)
                        {
                            sprintf(command,"iconrun2 %d %d %d %d %d %d %d %s 0 \"%s\" \"%s\" %d %f %f %s %d &",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,MouseMoveOpenSubIcon,group,skip,win_move,bord,trans_icon,trans_wind,buffer,l_id);
//                            printf("iconrun2 %d %d %d %d %d %d %d %s 0 \"%s\" \"%s\" %d %f %f %s %d &\n",xmain,ymain+gc*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,MouseMoveOpenSubIcon,group,skip,win_move,bord,trans_icon,trans_wind,buffer,l_id);
                            system(command);
                            gc=gc+1;
                        }
                    } else {
                        sprintf(ch2,"%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3]);
                        if (strcmp(ch2,"dock")==0 )
                        {
                            m=0;
                            for (n=0;n<1024;n++)
                                ch2[n]='\0';
                            while (( buffer[m] != ':' ) and (buffer[m] != '#'))
                            {
                                ch2[m]=buffer[m];
                                m=m+1;
                            }
                            for (n=0;n<m-4;n++)
                            {
                                 ch2[n]=ch2[n+4];
                            } 
                            for (n=m-4;n<m;n++)
                            {
                                 ch2[n]='\0';
                            }

                            for (n=0;n<1024;n++)
                            { 
                                if (buffer[n]=='\n')
                                {
                                    buffer[n]='\0';
                                }
                            }        
                            sprintf(group,"%s",ch2);
                            if (buffer[m+1] == ' ')
                                m=m+2;
                            else
                                m=m+1;
                            for (n=0;n<1024-m;n++)
                            {
                                 buffer[n]=buffer[n+m];
                            } 
                            for (n=1023-m;n<1024;n++)
                            {
                                 buffer[n]='\0';
                            } 
                            if ((mode==2) or (mode==3))
                            {
                                sprintf(command,"icon-dock %d %d %d %d %d %d %s \"%s\" 0 &",xmain,ymain-gd*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,buffer,skip);
//                                printf("icon-dock %d %d %d %d %d %d %s \"%s\" 0 &\n",xmain,ymain-gd*(sizemain+gapmain),sizemain,sizemain,raisemode,autohideSubbutton,buffer,skip);
                                system(command);
                                gd=gd+1;
                            }
                        }
                        else
                        {
                            for (n=0;n<1024;n++)
                            { 
                                if (buffer[n]=='\n')
                                {
                                    buffer[n]='\0';
                                }
                            }        
                            if (( mode == 1 ) and (strcmp(group,selectedgroup)==0 ))
                            {
                                sprintf(command,"iconrun3 %d %d %d %d %d %d %s \"%s\" \"%s\" %d %f %f %d &", (x+gapsub+(sizesub+gapsub)*i),y-((sizesub-sizemain)/2),sizesub,sizesub,raisemode,MouseMoveOpenSubIcon,buffer,skip,win_move,bord,trans_icon,trans_wind,l_id);
//                                printf("iconrun3 %d %d %d %d %d %d %s \"%s\" \"%s\" %d %f %f %d &\n", (x+gapsub+(sizesub+gapsub)*i),y-((sizesub-sizemain)/2),sizesub,sizesub,raisemode,MouseMoveOpenSubIcon,buffer,skip,win_move,bord,trans_icon,trans_wind,l_id);
                                system(command);
                                i=i+1;
                            }
                        }
                    }    
                }     
            } 
        }
    }
    fclose(freeNum);
    return 0;

}

