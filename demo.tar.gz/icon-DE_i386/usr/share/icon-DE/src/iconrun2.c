// g++ -o ./iconrun2 ./iconrun2.c    -lImlib2 -lX11 -lXmu `pkg-config --cflags --libs glib-2.0`

#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib-2.0/glib.h>
#include <stdio.h>
#include <stdlib.h>
#include <map>
#include <cstdio>
#include <cstring>
#include <iconv.h>
#include <iostream>
#include <fstream>
#include <unistd.h>

using namespace std;

#include "Imlib2.h"

Display                        *disp;
Window                            win,win4;
Window                            win2;
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
char *appToRun;
int mytoggle = 0;
int bord=0;
double trans_wind=0.85;
char *title;
char *skip;
char home[1024];
char c_rc[2048]="N/A";

#include "./other_src/wm_ctrl.c"
#include "./other_src/find_icon.c"

char Char2Int(char ch){
    if(ch>='0' && ch<='9')return (char)(ch-'0');
    if(ch>='a' && ch<='f')return (char)(ch-'a'+10);
    if(ch>='A' && ch<='F')return (char)(ch-'A'+10);
    return -1;
}

char Str2Bin(char *str){
    char tempWord[2];
    char chn;

    tempWord[0] = Char2Int(str[0]);                //make the B to 11 -- 00001011
    tempWord[1] = Char2Int(str[1]);                //make the 0 to 0    -- 00000000

    chn = (tempWord[0] << 4) | tempWord[1];        //to change the BO to 10110000

    return chn;
}

string UrlDecode(string str){
    string output="";
    char tmp[2];
    int i=0,len=str.length();
    
    while(i<len)
    {
        if(str[i]=='%')
        {
            tmp[0]=str[i+1];
            tmp[1]=str[i+2];
            output+=Str2Bin(tmp);
            i=i+3;
        }
        else if(str[i]=='+')
        {
            output+=' ';
            i++;
        }
        else{
            output+=str[i];
            i++;
        }
    }
    
    return output;
}


// 代码转换操作类 用于将utf-8 格式转成 gb2312
class CodeConverter {
    private:
            iconv_t cd;
    public:
            CodeConverter(const char *_charset,const char *to_charset) {// 构造
                cd = iconv_open(to_charset,_charset);
            }
        
            ~CodeConverter() {// 析构
                iconv_close(cd);
            }
        
            int convert(char *inbuf,int inlen,char *outbuf,int outlen) {// 转换输出
                char **pin = &inbuf;
                char **pout = &outbuf;

                memset(outbuf,0,outlen);
                return iconv(cd,pin,(size_t *)&inlen,pout,(size_t *)&outlen);
            }
};

//输入url_Utf-8 ,输出utf-8
string url2str_utf8(string instr){
    string input;
    input=UrlDecode(instr);

    const int    outlen=instr.length();
    char output[outlen];

    CodeConverter cc = CodeConverter("utf-8","utf-8");
    cc.convert((char *)input.c_str(),strlen(input.c_str()),output,outlen);

    return output;
}

//输入url_gb2312 ,输出 gb2312 实际上是直接调用 UrlDecode()
string url2str_gb2312(string str){
    return UrlDecode(str);
}



char * read_desktop_entry(char * desk_file_name)
{
    string ss;
    FILE *fp=NULL;
    FILE *fp2=NULL;
    char buffer[4096];
    char l1[2]="N";
    char l3[4]="N/A";
    char l4[5]="N/A";
    char l5[6]="N/A";
    char l7[8]="N/A";
    char l8[9]="N/A";
//    char l9[10]="N/A";
    char l11[12]="N/A";
    char l12[13]="N/A";
    char l14[15]="N/A";
    char l18[19]="N/A";
    char type[1024]="";
    char name[1024]="";
    char name_zh[1024]="";
    char icon_file[2048];
    char icon[1024]="";
    char exec[1024]="";
    char term[64]="False";
    char comment[1024]="";
    char comment_zh[1024]="";
    char url[1024]="N/A";
    char gene[1024]="";
    char gene_zh[1024]="";
    int i;
//    char full_path_icon[4096]="";
    char title[1024]="aaa";
    char c_term[1024];
    char e_term[100];
    char c_cmd[1024];

    ss=string(4096,'\0');
    ss.assign(desk_file_name);
    for (i=0;i<4089;i++)
    {
        ss[i]=ss[i+7];
        if (ss[i]=='\n')
            ss[i]='\0';
        if (ss[i]=='\r')
            ss[i]='\0';
    }
    for (i=4096;i>0;i--)
    {
        if (ss[i]=='\n')
            ss[i]='\0';
        if (ss[i]=='\r')
            ss[i]='\0';
        if (ss[i]==' ')
            ss[i]='\0';
        else
            break;    
    }
    ss=url2str_utf8(ss);
    cout<<ss<<endl;;
    cout << flush;
    if (access(ss.c_str(),0)!=-1)
    {
        fp=fopen(ss.c_str(),"r");
        if(fp==NULL) 
        {
        printf("not open 1\n");
        }
        else
        {
            fgets(buffer,4096,fp);
            for (i=0;i<4096;i++)
                if (buffer[i]=='\n') buffer[i]='\0';
            if (strcmp(buffer,"[Desktop Entry]")==0 )
            {
                sprintf(gene_zh,"N/A");
                sprintf(comment_zh,"N/A");
                sprintf(name_zh,"N/A");
                sprintf(url,"N/A");
                sprintf(exec,"N/A");
                sprintf(type,"N/A");
                sprintf(name,"N/A");
                sprintf(comment,"N/A");
                sprintf(icon,"N/A");
                sprintf(gene,"N/A");
                while ( ! feof(fp) )
                {
                    fgets(buffer,4096,fp);
                    for (i=0;i<4096;i++)
                    if (buffer[i]=='\n') buffer[i]='\0';
                    sprintf(l1,"%c",buffer[0]);
                    sprintf(l3,"%c%c%c",buffer[0],buffer[1],buffer[2]);
                    sprintf(l4,"%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3]);
                    sprintf(l5,"%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4]);
                    sprintf(l7,"%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6]);
                    sprintf(l8,"%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7]);
                    sprintf(l11,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);
                    sprintf(l12,"%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11]);
                    sprintf(l14,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11],buffer[12],buffer[13]);
                    sprintf(l18,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11],buffer[12],buffer[13],buffer[14],buffer[15],buffer[16],buffer[17]);
                    if (strcmp(l1,"[")==0 ) break;
                    if (strcmp(l18,"GenericName[zh_CN]")==0 )
                    {
                        ReplaceStr(buffer,"GenericName[zh_CN] = ","");
                        ReplaceStr(buffer,"GenericName[zh_CN]= ","");
                        ReplaceStr(buffer,"GenericName[zh_CN] =","");
                        ReplaceStr(buffer,"GenericName[zh_CN]=","");
                        ReplaceStr(buffer,"GenericName[zh_CN]","");
                        printf("GenericName[zh_CN]: %s\n",buffer);
                        sprintf(gene_zh,"%s",buffer);
                    }
                    else if (strcmp(l14,"Comment[zh_CN]")==0 )
                    {
                        ReplaceStr(buffer,"Comment[zh_CN] = ","");
                        ReplaceStr(buffer,"Comment[zh_CN]= ","");
                        ReplaceStr(buffer,"Comment[zh_CN] =","");
                        ReplaceStr(buffer,"Comment[zh_CN]=","");
                        ReplaceStr(buffer,"Comment[zh_CN]","");
                        printf("Comment[zh_CN]: %s\n",buffer);
                        sprintf(comment_zh,"%s",buffer);
                    }
                    else if (strcmp(l12,"GenericName[")==0 )
                    {
                        //printf("Name[zh_CN]: %s\n",buffer);
                    }
                    else if (strcmp(l11,"Name[zh_CN]")==0 )
                    {
                        ReplaceStr(buffer,"Name[zh_CN] = ","");
                        ReplaceStr(buffer,"Name[zh_CN]= ","");
                        ReplaceStr(buffer,"Name[zh_CN] =","");
                        ReplaceStr(buffer,"Name[zh_CN]=","");
                        ReplaceStr(buffer,"Name[zh_CN]","");
                        printf("Name[zh_CN]: %s\n",buffer);
                        sprintf(name_zh,"%s",buffer);
                    }
                    else if (strcmp(l11,"GenericName")==0 )
                    {
                        ReplaceStr(buffer,"GenericName = ","");
                        ReplaceStr(buffer,"GenericName= ","");
                        ReplaceStr(buffer,"GenericName =","");
                        ReplaceStr(buffer,"GenericName=","");
                        ReplaceStr(buffer,"GenericName","");
                        printf("GenericName: %s\n",buffer);
                        sprintf(gene,"%s",buffer);
                    }
                    else if (strcmp(l8,"Terminal")==0 )
                    {
                        ReplaceStr(buffer,"Terminal = ","");
                        ReplaceStr(buffer,"Terminal= ","");
                        ReplaceStr(buffer,"Terminal =","");
                        ReplaceStr(buffer,"Terminal=","");
                        ReplaceStr(buffer,"Terminal","");
                        printf("Terminal: %s\n",buffer);
                        sprintf(term,"%s",buffer);
                    }
                    else if (strcmp(l8,"Comment[")==0 )
                    {
                        //printf("Comment: %s\n",buffer);
                    }
                    else if (strcmp(l7,"Comment")==0 )
                    {
                        ReplaceStr(buffer,"Comment = ","");
                        ReplaceStr(buffer,"Comment= ","");
                        ReplaceStr(buffer,"Comment =","");
                        ReplaceStr(buffer,"Comment=","");
                        ReplaceStr(buffer,"Comment","");
                        printf("Comment: %s\n",buffer);
                        sprintf(comment,"%s",buffer);
                    }
                    else if (strcmp(l5,"Name[")==0 )
                    {
                        //printf("Name: %s\n",buffer);
                    }
                    else if (strcmp(l4,"Icon")==0 )
                    {
                        ReplaceStr(buffer,"Icon = ","");
                        ReplaceStr(buffer,"Icon =","");
                        ReplaceStr(buffer,"Icon= ","");
                        ReplaceStr(buffer,"Icon=","");
                        ReplaceStr(buffer,"Icon","");
                        printf("Icon: %s\n",buffer);
                        sprintf(icon,"%s",buffer);
                    }
                    else if (strcmp(l4,"Type")==0 )
                    {
                        ReplaceStr(buffer,"Type = ","");
                        ReplaceStr(buffer,"Type= ","");
                        ReplaceStr(buffer,"Type =","");
                        ReplaceStr(buffer,"Type=","");
                        ReplaceStr(buffer,"Type","");
                        printf("Type: %s\n",buffer);
                        sprintf(type,"%s",buffer);
                    }
                    else if (strcmp(l4,"Name")==0 )
                    {
                        ReplaceStr(buffer,"Name = ","");
                        ReplaceStr(buffer,"Name= ","");
                        ReplaceStr(buffer,"Name =","");
                        ReplaceStr(buffer,"Name=","");
                        ReplaceStr(buffer,"Name","");
                        printf("Name: %s\n",buffer);
                        sprintf(name,"%s",buffer);
                    }
                    else if (strcmp(l4,"Exec")==0 )
                    {
                        ReplaceStr(buffer,"Exec = ","");
                        ReplaceStr(buffer,"Exec= ","");
                        ReplaceStr(buffer,"Exec =","");
                        ReplaceStr(buffer,"Exec=","");
                        ReplaceStr(buffer,"Exec","");
                        printf("Exec: %s \n",buffer);
                        sprintf(exec,"%s ",buffer);
                    }
                    else if (strcmp(l3,"URl")==0 )
                    {
                        ReplaceStr(buffer,"URL = ","");
                        ReplaceStr(buffer,"URL= ","");
                        ReplaceStr(buffer,"URL =","");
                        ReplaceStr(buffer,"URL=","");
                        ReplaceStr(buffer,"URL","");
                        printf("URl: %s\n",buffer);
                        sprintf(url,"%s",buffer);
                    }
                }
                if ((strcmp(type,"Application")==0) or (strcmp(type,"application")==0) or (strcmp(type,"APPLICATION")==0) )
                {
                    if ((strcmp(term,"True")==0) or (strcmp(term,"true")==0) or (strcmp(term,"TRUE")==0) )
                    {
                        sprintf(icon_file,"%s/.icon-DE/icon-de.rc",home);
                        if (access(icon_file,0)!=-1)
                        {
                            fp2=fopen(icon_file,"r");
                        }
                        else if (access("usr/share/icon-DE/icon-de.rc",0)!=-1)
                            fp2=fopen("usr/share/icon-DE/icon-de.rc","r");
                        if (fp2==NULL)
                        {
                            printf("can't open ~/.icon-DE/icon-de.rc\n");
                        }
                        fgets(buffer,4096,fp2);
                        for (i=0;i<4096;i++)
                            if (buffer[i]=='\n') buffer[i]='\0';
                        while ( ! feof(fp2) )
                        {
                            sprintf(l11,"%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6]);
                            if (strcmp(l11,"c_term:")==0 )
                            {
                                ReplaceStr(buffer,"c_term:","");
                                sprintf(c_term,"%s",buffer);
                                printf("%s\n",c_term);
                            }
                            if (strcmp(l11,"e_term:")==0 )
                            {
                                ReplaceStr(buffer,"e_term:","");
                                sprintf(e_term,"%s",buffer);
                                printf("%s\n",c_term);
                            }
                            fgets(buffer,4096,fp2);
                            for (i=0;i<4096;i++)
                                if (buffer[i]=='\n') buffer[i]='\0';
                        }
                        fclose(fp2);
                        sprintf(c_cmd,"%s %s %s",c_term,e_term,exec);
                        system(c_cmd);
                        sleep(3);
                        if (get_active_window(disp)!=0)
                        if (get_window_title(disp,get_active_window(disp))!=NULL)
                            sprintf(title,"%s",get_window_title(disp,get_active_window(disp)));
                        if (strcmp(name_zh,"N/A")==0 )
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name,title);
                        }
                        else
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name_zh,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name_zh,title);
                        }
                    }
                    else
                    {
                        system(exec);
                        sleep(3);
                        if (get_active_window(disp)!=0)
                        if (get_window_title(disp,get_active_window(disp))!=NULL)
                            sprintf(title,"%s",get_window_title(disp,get_active_window(disp)));
                        if (strcmp(name_zh,"N/A")==0 )
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,exec,name,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,exec,name,title);
                        }
                        else
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,exec,name_zh,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,exec,name_zh,title);
                        }
                    }  
                } else
                {
                    if (strcmp(url,"N/A")!=0)
                    {
                        sprintf(icon_file,"%s/.icon-DE/icon-de.rc",home);
                        if (access(icon_file,0)!=-1)
                        {
                            fp2=fopen(icon_file,"r");
                        }
                        else if (access("usr/share/icon-DE/icon-de.rc",0)!=-1)
                            fp2=fopen("usr/share/icon-DE/icon-de.rc","r");
                        if (fp2==NULL)
                        {
                            printf("can't open ~/.icon-DE/icon-de.rc\n");
                        }
                        fgets(buffer,4096,fp2);
                        for (i=0;i<4096;i++)
                            if (buffer[i]=='\n') buffer[i]='\0';
                        while ( ! feof(fp2) )
                        {
                            sprintf(l11,"%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8]);
                            if (strcmp(l11,"c_brower:")==0 )
                            {
                                ReplaceStr(buffer,"c_brower:","");
                                sprintf(c_term,"%s",buffer);
                                printf("%s\n",c_term);
                            }
                            fgets(buffer,4096,fp2);
                            for (i=0;i<4096;i++)
                                if (buffer[i]=='\n') buffer[i]='\0';
                        }
                        fclose(fp2);
                        sprintf(c_cmd,"%s %s",c_term,exec);
                        system(c_cmd);
                        sleep(3);
                        if (get_active_window(disp)!=0)
                        if (get_window_title(disp,get_active_window(disp))!=NULL)
                            sprintf(title,"%s",get_window_title(disp,get_active_window(disp)));
                        if (strcmp(name_zh,"N/A")==0 )
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name,title);
                        }
                        else
                        {
                            printf("%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name_zh,title);
                            sprintf(c_rc,"%s \"%s\" \"%s\" \"%s\" ",icon,c_cmd,name_zh,title);
                        }
                    }
                }
            } else
            {
                printf("打开的不是Desktop Entry文件！！\n");
            } 
            fclose(fp);
        }    
    } else {
        printf("not open 2\n");
    }
    return c_rc;

}
//Convert an atom name in to a std::string
string GetAtomName(Display* disp, Atom a)
{
    if(a == None)
        return "None";
    else
        return XGetAtomName(disp, a);
}

struct Property
{
    unsigned char *data;
    int format, nitems;
    Atom type;
};


//This atom isn't provided by default
Atom XA_TARGETS;


//This fetches all the data from a property
Property read_property(Display* disp, Window w, Atom property)
{
    Atom actual_type;
    int actual_format;
    unsigned long nitems;
    unsigned long bytes_after;
    unsigned char *ret=0;
    
    int read_bytes = 1024;    

    //Keep trying to read the property until there are no
    //bytes unread.
    do
    {
        if(ret != 0)
            XFree(ret);
        XGetWindowProperty(disp, w, property, 0, read_bytes, False, AnyPropertyType,
                            &actual_type, &actual_format, &nitems, &bytes_after, 
                            &ret);

        read_bytes *= 2;
    }while(bytes_after != 0);
    
//    cerr << endl;
//    cerr << "Actual type: " << GetAtomName(disp, actual_type) << endl;
//    cerr << "Actual format: " << actual_format << endl;
//    cerr << "Number of items: " << nitems <<    endl;

    Property p = {ret, actual_format, nitems, actual_type};

    return p;
}


// This function takes a list of targets which can be converted to (atom_list, nitems)
// and a list of acceptable targets with prioritees (datatypes). It returns the highest
// entry in datatypes which is also in atom_list: ie it finds the best match.
Atom pick_target_from_list(Display* disp, Atom* atom_list, int nitems, map<string, int> datatypes)
{
    Atom to_be_requested = None;
    //This is higger than the maximum priority.
    int priority=INT_MAX;

    for(int i=0; i < nitems; i++)
    {
        string atom_name = GetAtomName(disp, atom_list[i]);
//        cerr << "Type " << i << " = " << atom_name << endl;
    
        //See if this data type is allowed and of higher priority (closer to zero)
        //than the present one.
        if(datatypes.find(atom_name)!= datatypes.end())
            if(priority > datatypes[atom_name])
            {    
//                cerr << "Will request type: " << atom_name << endl;
                priority = datatypes[atom_name];
                to_be_requested = atom_list[i];
            }
    }

    return to_be_requested;
}

// Finds the best target given up to three atoms provided (any can be None).
// Useful for part of the Xdnd protocol.
Atom pick_target_from_atoms(Display* disp, Atom t1, Atom t2, Atom t3, map<string, int> datatypes)
{
    Atom atoms[3];
    int    n=0;

    if(t1 != None)
        atoms[n++] = t1;

    if(t2 != None)
        atoms[n++] = t2;

    if(t3 != None)
        atoms[n++] = t3;

    return pick_target_from_list(disp, atoms, n, datatypes);
}


// Finds the best target given a local copy of a property.
Atom pick_target_from_targets(Display* disp, Property p, map<string, int> datatypes)
{
    //The list of targets is a list of atoms, so it should have type XA_ATOM
    //but it may have the type TARGETS instead.

    if((p.type != XA_ATOM && p.type != XA_TARGETS) || p.format != 32)
    { 
        //This would be really broken. Targets have to be an atom list
        //and applications should support this. Nevertheless, some
        //seem broken (MATLAB 7, for instance), so ask for STRING
        //next instead as the lowest common denominator

        if(datatypes.count("STRING"))
            return XA_STRING;
        else
            return None;
    }
    else
    {
        Atom *atom_list = (Atom*)p.data;
        
        return pick_target_from_list(disp, atom_list, p.nitems, datatypes);
    }
}


void exposelist(void);

int main(int argc, char **argv)
{
    int                                 w, h, x, y;
    Imlib_Image                 im_bg = NULL;
    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
    Imlib_Image                 buffer,buffer4;
    Imlib_Image                 back;
    Imlib_Image                 bigback;
    Imlib_Font                    font;
    char                                text[4096];
    Imlib_Color_Range     range;
    int    text_w, text_h;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=64;
    int screenHeight;
    screenHeight=64;
    int screenX=10;
    int screenY=10;
    int lowerraise=0;
    char *group;
    char *picname;
    char *tag;
    int xl=0;
    int yl=0;
    int mytoggle = 0;
    int mytoggle2 = 0;
    int store=0;
    int autohideSubbutton=0;
    int MouseMoveOpenSubIcon=0;
    int s_g;
    char *win_move;
    unsigned long l_id;

    double trans_icon=0.65;

    char submenue[1000];
    sprintf(home,"%s",getenv("HOME"));
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
    Window                            cur_win_id;

    if ( argc == 1 )
    {
        printf("usage1: iconrun2 x y width height lower/raise(0/1) autohideSubbutton(0/1/2) MouseMoveOpenSubIcon(0/1) group single/group(0)    windows_class_for_skip windows_move_to(x,y,w,h) bord(0/1) trans_icon trans_wind image tag application title l_id\n");
        printf("usage2: iconrun2 x y width height lower/raise(0/1) autohideSubbutton(0/1/2) MouseMoveOpenSubIcon(0/1) group single/group(1)    windows_class_for_skip windows_move_to(x,y,w,h) bord(0/1) trans_icon trans_wind image tag l_id\n");
        return 1;
    }
    if (( argc != 20 ) and ( argc != 18 ))
    {
        return 1;
    }

    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    sscanf(argv[5], "%d", &lowerraise);
    sscanf(argv[6], "%d", &autohideSubbutton);
    sscanf(argv[7], "%d", &MouseMoveOpenSubIcon);
    group=argv[8];
    sscanf(argv[9], "%d", &s_g);
    skip=argv[10];
    win_move=argv[11];
    sscanf(argv[12], "%d", &bord);
    trans_icon = atof (argv[13]);
    trans_wind = atof (argv[14]);
    picname=argv[15];

    if (s_g==1)
    {
        tag=argv[16];
        sscanf(argv[17], "%ld", &l_id);
    }
    
    if (s_g==0)
    {
        appToRun = argv[16];
        tag=argv[17];
//        printf("%s",appToRun);
        title=argv[18];
        sscanf(argv[19], "%ld", &l_id);
    }
    

    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);

    attr.override_redirect=True;
 //win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,CopyFromParent,InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask|CWBorderPixel|CWSaveUnder|CWColormap|CWBackPixel,&attr);
    win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
//     win =    XCreateSimpleWindow(disp, DefaultRootWindow(disp), 0, 0, 100, 100, 0, 0, 0);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    XMapWindow(disp, win);

    if(lowerraise==0)
         XLowerWindow(disp,win);
    if(lowerraise==1)
         XRaiseWindow(disp,win);
    trans(trans_icon,win);

     /**
        * Start rendering
        */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
    w=screenWidth;
    h=screenHeight;
    char back_pic[1280],mouse_pic[1280];
    sprintf(back_pic,"%s/.icon-DE/pics/background.png",home);
    if (access(back_pic,0)==-1)
        sprintf(back_pic,"/usr/share/icon-DE/pics/background.png");
    back = imlib_load_image(back_pic);
    imlib_context_set_image(back);
    buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);
    im_bg = imlib_load_image(find_icon_file(picname));
    if (im_bg == NULL)
        im_bg = imlib_load_image("/usr/share/icon-DE/iconcache/face-smile.png");
    XMapWindow(disp, win);
    imlib_context_set_image(im_bg);

    int is=imlib_image_get_width();
    int ih=imlib_image_get_height();
    int d1=screenWidth-is;
    d1=d1/2;
    int d2=screenHeight-ih;
    d2=d2/2;
    unsigned long i=0;
    unsigned long cur_win=0;
    imlib_context_set_image(im_bg);
    imlib_context_set_blend(1);

    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);
    imlib_render_image_on_drawable_at_size(d1-1, d2-1,is+2,ih+2);
    bigback=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);

    imlib_render_image_on_drawable(d1, d2);
    back=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    XResizeWindow(disp, win, w, h);
    XSync(disp, False);
    if (autohideSubbutton==1)
         XMoveWindow(disp,win,-screenWidth+2 , screenY);
    if (autohideSubbutton==2)
         XMoveWindow(disp,win,-screenWidth/2 , screenY);

    char font_path[1024];
    sprintf(font_path,"%s/.icon-DE/fonts",home);
    imlib_add_path_to_font_path(font_path);
    imlib_add_path_to_font_path("/usr/share/fonts/truetype/wqy/");
    imlib_add_path_to_font_path("/usr/share/fonts/wenquanyi/wqy-zenhei/");

    x = -9999;
    y = -9999;
    x = -screenWidth/2;
    y = -screenHeight/2;
    int can_close,cur_times;
    can_close=0;
    cur_times=0;
    int tra=0;

    map<string, int> datatypes;
    datatypes["text/uri-list"] = 1;
    datatypes["STRING"] = 2;
    Atom sel = XInternAtom(disp, "PRIMARY", 0);
    Atom XdndEnter = XInternAtom(disp, "XdndEnter", False);
    Atom XdndPosition = XInternAtom(disp, "XdndPosition", False);
    Atom XdndStatus = XInternAtom(disp, "XdndStatus", False);
    Atom XdndTypeList = XInternAtom(disp, "XdndTypeList", False);
    Atom XdndActionCopy = XInternAtom(disp, "XdndActionCopy", False);
    Atom XdndDrop = XInternAtom(disp, "XdndDrop", False);
    Atom XdndLeave = XInternAtom(disp, "XdndLeave", False);
    Atom XdndFinished = XInternAtom(disp, "XdndFinished", False);
    Atom XdndSelection = XInternAtom(disp, "XdndSelection", False);
//    Atom XdndProxy = XInternAtom(disp, "XdndProxy", False);
    Window drop_window;
    drop_window = win;
    Atom XdndAware = XInternAtom(disp, "XdndAware", False);
    Atom version=5;
    XChangeProperty(disp, win, XdndAware, XA_ATOM, 32, PropModeReplace, (unsigned char*)&version, 1);
    XA_TARGETS = XInternAtom(disp, "TARGETS", False);
    XFlush(disp);
    Atom to_be_requested = None;
    bool sent_request = 0;
    int xdnd_version=0;
    Window xdnd_source_window=None;
    Atom target = ev.xselection.target;

    bool m_mouse=0;                   //Are we currently dragging
    int have_press=0;
    int have_release=0;
    int m_button=0;

    int xfd = ConnectionNumber(disp);
    long ticks;
    fd_set rfds;
//    time_t now_time;
    struct timeval now, tm,LastTime;

    while (1)
    {
        Imlib_Image                temp, temp2;
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case ClientMessage:
                if(ev.xclient.message_type == XdndEnter)
                {
                    bool more_than_3 = ev.xclient.data.l[1] & 1;
                    Window source = ev.xclient.data.l[0];
                    xdnd_version = ( ev.xclient.data.l[1] >> 24);
                    if(more_than_3)
                    {
                        //Fetch the list of possible conversions
                        //Notice the similarity to TARGETS with pastev.
                        Property p = read_property(disp, source , XdndTypeList);
                        to_be_requested = pick_target_from_targets(disp, p, datatypes);
                        XFree(p.data);
                    }
                    else
                    {
                        //Use the available list
                        to_be_requested = pick_target_from_atoms(disp, ev.xclient.data.l[2], ev.xclient.data.l[3], ev.xclient.data.l[4], datatypes);
                    }
            }
            else if(ev.xclient.message_type == XdndPosition)
            {
//                    Atom action=XdndActionCopy;
                    if(xdnd_version >= 2)
                        action = ev.xclient.data.l[4];
                    //Xdnd: reply with an XDND status message
                    XClientMessageEvent m;
                    memset(&m, sizeof(m), 0);
                    m.type = ClientMessage;
                    m.display = ev.xclient.display;
                    m.window = ev.xclient.data.l[0];
                    m.message_type = XdndStatus;
                    m.format=32;
                    m.data.l[0] = drop_window;
                    m.data.l[1] = (to_be_requested != None);
                    m.data.l[2] = 0; //Specify an empty rectangle
                    m.data.l[3] = 0;
                    m.data.l[4] = XdndActionCopy; //We only accept copying anyway.

                    XSendEvent(disp, ev.xclient.data.l[0], False, NoEventMask, (XEvent*)&m);
                    XFlush(disp);
            }
            else if(ev.xclient.message_type == XdndLeave)
            {
                    //to_be_requested = None;

                    //We can't actually reset to_be_requested, since OOffice always
                    //sends this event, even when it doesn't mean to.
                    cerr << "Xdnd cancelled.\n";
            }
            else if(ev.xclient.message_type == XdndDrop)
            {
                    if(to_be_requested == None)
                    {
                        //It's sending anyway, despite instructions to the contrary.
                        //So reply that we're not interested.
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = ev.xclient.data.l[0];
                        m.message_type = XdndFinished;
                        m.format=32;
                        m.data.l[0] = drop_window;
                        m.data.l[1] = 0;
                        m.data.l[2] = None; //Failed.
                        XSendEvent(disp, ev.xclient.data.l[0], False, NoEventMask, (XEvent*)&m);
                    }
                    else
                    {
                        xdnd_source_window = ev.xclient.data.l[0];
                        if(xdnd_version >= 1)
                            XConvertSelection(disp, XdndSelection, to_be_requested, sel, win, ev.xclient.data.l[2]);
                        else
                            XConvertSelection(disp, XdndSelection, to_be_requested, sel, win, CurrentTime);
                    }
                }
                break;
            case SelectionNotify:
                target = ev.xselection.target;
                if(ev.xselection.property == None)
                {
                    //If the selection can not be converted, quit with error 2.
                    //If TARGETS can not be converted (nothing owns the selection)
                    //then quit with code 3.
                    //return 2 + (target == XA_TARGETS);
                }
                else 
                {
                    Property prop = read_property(disp, win, sel);

                    //If we're being given a list of targets (possible conversions)
                    if(target == XA_TARGETS && !sent_request)
                    {
                        sent_request = 1;
                        to_be_requested = pick_target_from_targets(disp, prop, datatypes);

                        if(to_be_requested == None)
                        {
                                cerr << "No matching datatypes.\n";
                                return 1;
                        }
                        else //Request the data type we are able to select
                        {
//                                cerr << "Now requsting type " << GetAtomName(disp, to_be_requested) << endl;
                                XConvertSelection(disp, sel, to_be_requested, sel, win, CurrentTime);
                        }
                    }
                    else if(target == to_be_requested)
                    {
                        //Dump the binary data
//                        cout.write((char*)prop.data, prop.nitems * prop.format/8);
                        char c_cr[1024];
                        sprintf(c_cr,"%s\n",read_desktop_entry((char *)prop.data));
                        printf("%s",c_cr);
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = disp;
                        m.window = xdnd_source_window;
                        m.message_type = XdndFinished;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = 1;
                        m.data.l[2] = XdndActionCopy; //We only ever copy.
                         //Reply that all is well.
                        XSendEvent(disp, xdnd_source_window, False, NoEventMask, (XEvent*)&m);
                        //Un-proxy the root window
//                        return 0;

                        XFree(prop.data);
                        char submenue[1024];
                        char c_cmd[1024];
                        char f_buffer[4096];
                        FILE * fp=NULL;
                        FILE * fp2=NULL;
                        sprintf(submenue,"%s/.icon-DE/wharf.rc",home);
                        if (access(submenue,0)!=-1)
                        {
                            
                            sprintf(c_cmd,"cp -f %s %s~",submenue,submenue);
                            printf("%s\n",c_cmd);
                            system(c_cmd);
                            sprintf(submenue,"%s/.icon-DE/wharf.rc~",home);
                            fp=fopen(submenue,"r");
                            if (fp==NULL)
                            {
                                printf("not open 1\n");
                            }
                            else
                            {
                                sprintf(submenue,"%s/.icon-DE/wharf.rc",home);
                                fp2=fopen(submenue,"w");
                                fgets(f_buffer,4096,fp);
                                i=1;
                                while ( ! feof(fp) )
                                {
                                    fputs(f_buffer,fp2);
                                    if ( i==l_id )
                                        fputs(c_cr,fp2);
                                    fgets(f_buffer,4096,fp);
                                    i=i+1;
                                }
                            }
                            fclose(fp);
                            fclose(fp2);
                            sleep(2);
                            sprintf(submenue,"icon-wharf RESET");
                            system(submenue);
                        }
                    }
                    cerr << endl;
                }
                break;
            case Expose:
                break;
            case MotionNotify:
                x = ev.xmotion.x;
                y = ev.xmotion.y;
            default:
                break;
            case EnterNotify:        
                if(lowerraise==0)
                     XLowerWindow(disp,win);
                if(lowerraise==1)
                     XRaiseWindow(disp,win);
                mytoggle = 1;
                system("killall iconrun3 2>/dev/null");    
                buffer = imlib_create_image(1000, 30);    
                font = imlib_load_font("Vera/8");
                if (font == NULL)
                    font = imlib_load_font("wqy-zenhei.ttc/8");
                imlib_context_set_font(font);
                imlib_context_set_color(0, 0, 0, 255);
                sprintf(text,"%s",tag);
                imlib_get_text_size(text, &text_w, &text_h);
                win2=XCreateWindow(disp,DefaultRootWindow(disp),screenX+screenWidth+4,screenY-18,text_w+40,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                XRaiseWindow(disp,win2);
                XMapWindow(disp, win2);
                imlib_context_set_drawable(win2); 
//                imlib_context_set_image(buffer);
                     /* draw the range */
                imlib_context_set_image(buffer);
                imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
                     /* free it */
            //         imlib_free_color_range();
                imlib_context_set_image(buffer);
                imlib_render_image_on_drawable(0, 0); 
                imlib_context_set_image(buffer);
                imlib_context_set_font(font);
                imlib_context_set_color(0, 0, 0, 255);
                imlib_text_draw(5,2,text);
                /* set the buffer image as our current image */
                imlib_context_set_image(buffer);
                imlib_context_set_drawable(win2); 
                imlib_render_image_on_drawable(0, 0); 
                imlib_context_set_image(buffer);
                imlib_free_image();
                imlib_context_set_font(font);
                imlib_free_font();
                imlib_context_set_image(im_bg);
                imlib_context_set_drawable(win);

                XMoveWindow(disp,win,screenX , screenY);

                if (((MouseMoveOpenSubIcon==1) or (MouseMoveOpenSubIcon==2)) and (s_g==1))
                {
                    sprintf(submenue , "icon-wharf %d %d %s %d %d" , screenWidth+screenX , screenY , group , lowerraise, bord);
                    system(submenue);    
                }
                break;
            case LeaveNotify:
                if (m_mouse!=1)
                {
                    x = -screenWidth/2;
                    y = -screenHeight/2;
                    if ( mytoggle2 == 1)
                    {
                        if (win_pid_list[cur_win]!=0)
                        {
                            init_window(win_pid_list[cur_win]);
                            action_window(disp,win_pid_list[cur_win],'a');
                            window_move_resize(disp,win_pid_list[cur_win],win_move);
                        }    
                        mytoggle2 = 0;
                    }        
                    mytoggle = 0;
                    XDestroyWindow(disp,win2);    
                    store=0;
    //2012.04.04
                    if (autohideSubbutton==1) 
                        XMoveWindow(disp,win,-screenWidth+2 , screenY);
                    if (autohideSubbutton==2) 
                        XMoveWindow(disp,win,-screenWidth/2 , screenY);

    //2012.04.04
                }
                break;
            case ButtonPress:
                if(ev.xbutton.button==1)
                {
                    gettimeofday(&LastTime, 0);
                    have_press=1;
                    have_release=0;
                }
                break;
            case ButtonRelease:
                if(ev.xbutton.button==1)
                {
                    have_release=1;
                    have_press=0;
                    m_button=0;
                    if ( m_mouse == 0 )
                    {
                        if (s_g==0)
                        {
                            system("killall iconrun3 2>/dev/null");         
                            exposelist();
                            if (MouseMoveOpenSubIcon==1) 
                                system("killall iconrun2 2>/dev/null");    
                        }
                        if (s_g==1)
                        {
                            if(store==1)
                            {
                                store=0;
                                break;
                            }
                            sprintf(submenue , "icon-wharf %d %d %s %d %d" , screenWidth+screenX , screenY , group , lowerraise, bord);
                            system(submenue);    
                            store+=1;
                        }
                    }
                    else
                    {
                        x = ev.xmotion.x;
                        y = ev.xmotion.y;
                        if ((x>=100) and (x<=138) and (y>=96) and (y<=130))
                        {
                            imlib_context_set_drawable(win4);
                            imlib_context_set_image(buffer4);
                            imlib_render_image_on_drawable(0, 0);
                            imlib_free_image();
                            XDestroyWindow(disp,win4);
                            imlib_context_set_image(im_bg);
                            imlib_context_set_drawable(win);
                            m_button=0;
                            m_mouse=0;
                            if ( mytoggle2 == 1)
                            {
                                if (win_pid_list[cur_win]!=0)
                                {
                                    init_window(win_pid_list[cur_win]);
                                    action_window(disp,win_pid_list[cur_win],'a');
                                    window_move_resize(disp,win_pid_list[cur_win],win_move);
                                }    
                                mytoggle2 = 0;
                            }        
                            mytoggle = 0;
                            XDestroyWindow(disp,win2);    
                            store=0;
            //2012.04.04
                            if (autohideSubbutton==1) 
                                XMoveWindow(disp,win,-screenWidth+2 , screenY);
                            if (autohideSubbutton==2) 
                                XMoveWindow(disp,win,-screenWidth/2 , screenY);
                            XSync(disp, False);
                            XFlush(disp); 
                        }
                        if ((x>=54) and (x<=90) and (y>=8) and (y<=43))
                            m_button=4;
                        if ((x>=54) and (x<=90) and (y>=53) and (y<=86))
                            m_button=2;
                        if ((x>=54) and (x<=90) and (y>=96) and (y<=129))
                            m_button=5;
                        if ((x>=100) and (x<=138) and (y>=8) and (y<=86))
                            m_button=3;
                    }
                } 
                if ((ev.xbutton.button==2) or (m_button==2))
                {
                    double t=atof(group);
                    if (t>=10) t=10;
                    t=t/10;
                    if (get_active_window(disp)!=0)
                    {
                        if (tra==0)
                        {
                            sprintf(submenue , "icon-trans %f 2" , t);
                            system(submenue);    
                            tra=1;
                        } else {
                            sprintf(submenue , "icon-trans 1 2");
                            system(submenue);    
                            tra=0;
                        } 
                    }
                    break;
                }
                if ((ev.xbutton.button==3) or (m_button==3))
                {
             /* if we click anywhere in the window, exit */
                    system("killall iconrun3 2>/dev/null");    
                    if (MouseMoveOpenSubIcon==1)
                        system("killall iconrun2 2>/dev/null");    
//                                                                     exit(0);
                    break;
                }
                if ((ev.xbutton.button==4) or (m_button==4))
                {
                    if (s_g==0)
                    {
                        cur_times=cur_times+1;
                        if ((can_close==1) or (cur_times>=3))
                        {
                            system("killall iconrun3 2>/dev/null");    
                            if (MouseMoveOpenSubIcon==1)
                                system("killall iconrun2 2>/dev/null");    
                        }
                        list_windows(disp,skip);
                        if (get_active_window(disp)==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                if (win_pid_list[i]!=0) 
                                if (get_window_title(disp,win_pid_list[i])!=NULL)
                                if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                {
                                    action_window(disp,win_pid_list[i],'a');
                                    can_close=0;
                                }    
                            }     
                        } else {
                            if ( get_window_title(disp,get_active_window(disp))!=NULL)
                            {
                                cur_win_id=get_active_window(disp);
                                init_window(cur_win_id);
                                if (strstr(get_window_title(disp,cur_win_id),title)==NULL)
                                {
                                    for (i=0;i<win_count;i++)
                                    {
                                        if (win_pid_list[i]!=0) 
                                        if (get_window_title(disp,win_pid_list[i])!=NULL)
                                        if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                        {
                                            action_window(disp,win_pid_list[i],'a');
                                            can_close=0;
                                        }    
                                    }     
                                }    else {
                                    if (get_active_window(disp)!=0)
                                    {
                                        cur_win_id=get_active_window(disp);
                                        init_window(cur_win_id);
//                                        printf("%s %d \n",win_move,cur_win_id);
                                        window_move_resize(disp,cur_win_id,win_move);
                                    }
                                }    
                            }
                        } 
                    }    else {
                        list_windows(disp,skip);
                        if (win_pid_list[cur_win]==0)
                        {
                            cur_win=0;
                            sprintf(text,"没有活动窗口");
                        }    else    {
                            if (get_window_title(disp,win_pid_list[cur_win])!=NULL)
                            {
                                if (cur_win<win_count-1) {
                                    cur_win=cur_win+1;    
                                } else    {
                                    cur_win=0;    
                                } 
                                sprintf(text,"%s",get_window_title(disp,win_pid_list[cur_win]));
                                mytoggle = 1;
                                mytoggle2 = 1;
                            } else {
                                sprintf(text,"没有活动窗口");
                                cur_win=0;    
                            }        
                        } 
                        mytoggle = 1;
                        buffer = imlib_create_image(1000, 30);    
                        font = imlib_load_font("Vera/8");
                        if (font == NULL)
                            font = imlib_load_font("wqy-zenhei.ttc/8");
                        imlib_context_set_font(font);
                        imlib_context_set_color(0, 0, 0, 255);
                        imlib_get_text_size(text, &text_w, &text_h);
//                        win2=XCreateWindow(disp,DefaultRootWindow(disp),screenX+screenWidth+4,screenY-18,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                        XRaiseWindow(disp,win2);
                        XMapWindow(disp, win2);
                        imlib_context_set_drawable(win2); 
//                        imlib_context_set_image(buffer);
                        imlib_context_set_image(buffer);
                        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
            //         imlib_free_color_range();
                        imlib_context_set_image(buffer);
                        imlib_render_image_on_drawable(0, 0); 
                        imlib_context_set_image(buffer);
                        imlib_context_set_font(font);
                        imlib_context_set_color(0, 0, 0, 255);
                        imlib_text_draw(5,2,text);
                        imlib_context_set_image(buffer);
                        imlib_context_set_drawable(win2); 
                        imlib_render_image_on_drawable(0, 0); 
                        imlib_context_set_image(buffer);
                        imlib_free_image();
                        imlib_context_set_font(font);
                        imlib_free_font();
                        imlib_context_set_image(im_bg);
                        imlib_context_set_drawable(win); 
                        system("killall iconrun3 2>/dev/null");    
                    }
                    break;
                }
                if ((ev.xbutton.button==5) or (m_button==5))
                {
                    if (s_g==0)
                    {
                        cur_times=cur_times+1;
                        if ((can_close==1) or (cur_times>=3))
                        {
                            system("killall iconrun3 2>/dev/null");    
                            if (MouseMoveOpenSubIcon==1)
                                system("killall iconrun2 2>/dev/null");    
                        }
                        list_windows(disp,skip);
                        if (get_active_window(disp)==0)
                        {
                            for (i=0;i<win_count;i++)
                            {
                                if (win_pid_list[i]!=0) 
                                if (get_window_title(disp,win_pid_list[i])!=NULL)
                                if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                {
                                    action_window(disp,win_pid_list[i],'a');
                                    can_close=0;
                                }    
                            }     
                        } else {
                            if (get_window_title(disp,get_active_window(disp))!=NULL)
                            {
                                cur_win_id=get_active_window(disp);
                                init_window(cur_win_id);
                                if (strstr(get_window_title(disp,cur_win_id),title)==NULL)
                                {
                                    for (i=0;i<win_count;i++)
                                    {
                                        if (win_pid_list[i]!=0) 
                                        if (get_window_title(disp,win_pid_list[i])!=NULL)
                                        if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                        {
                                            action_window(disp,win_pid_list[i],'a');
                                            can_close=0;
                                        }    
                                    }     
                                }    else {
                                    if (get_active_window(disp)!=0)
                                    {
                                        cur_win_id=get_active_window(disp);
                                        init_window(cur_win_id);
//                                    printf("%s %d \n",win_move,cur_win_id);
                                        window_move_resize(disp,cur_win_id,win_move);
                                    }
                                }    
                            }
                        }    
                    }    else {
                        list_windows(disp,skip);
                        if (win_pid_list[cur_win]==0)
                        {
                            cur_win=0;
                            sprintf(text,"没有活动窗口");
                        }    else    {
                            if (get_window_title(disp,win_pid_list[cur_win])!=NULL)
                            {
                                if (cur_win>0) {
                                    cur_win=cur_win-1;    
                                } else    {
                                    cur_win=win_count-1;
                                } 
                                sprintf(text,"%s",get_window_title(disp,win_pid_list[cur_win]));
                                mytoggle = 1;
                                mytoggle2 = 1;
                            } else {
                                sprintf(text,"没有活动窗口");
                                cur_win=0;    
                            }        
                        } 
                        mytoggle = 1;
                        buffer = imlib_create_image(1000, 30);    
                        font = imlib_load_font("Vera/8");
                        if (font == NULL)
                            font = imlib_load_font("wqy-zenhei.ttc/8");
                        imlib_context_set_font(font);
                        imlib_context_set_color(0, 0, 0, 255);
                        imlib_get_text_size(text, &text_w, &text_h);
//                        win2=XCreateWindow(disp,DefaultRootWindow(disp),screenX+screenWidth+4,screenY-18,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                        XRaiseWindow(disp,win2);
                        XMapWindow(disp, win2);
                        imlib_context_set_drawable(win2); 
//                        imlib_context_set_image(buffer);
                        imlib_context_set_image(buffer);
                        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
            //         imlib_free_color_range();
                        imlib_context_set_image(buffer);
                        imlib_render_image_on_drawable(0, 0); 
                        imlib_context_set_image(buffer);
                        imlib_context_set_font(font);
                        imlib_context_set_color(0, 0, 0, 255);
                        imlib_text_draw(5,2,text);
                        imlib_context_set_image(buffer);
                        imlib_context_set_drawable(win2); 
                        imlib_render_image_on_drawable(0, 0); 
                        imlib_context_set_image(buffer);
                        imlib_free_image();
                        imlib_context_set_font(font);
                        imlib_free_font();
                        imlib_context_set_image(im_bg);
                        imlib_context_set_drawable(win); 
                        system("killall iconrun3 2>/dev/null");    
                    }
                    break;
                }
            }
        }
         else {
        //display 是由 XopenDisplay 返回的 Display *
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=800)
            {
                if ((have_press==1) and (have_release==0) and (m_mouse==0))
                {
                    win4=XCreateWindow(disp,DefaultRootWindow(disp),screenX+screenWidth,screenY+screenHeight,153,193,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                    XSelectInput(disp, win4, ButtonPressMask | ButtonReleaseMask );
                    XMapWindow(disp, win4);
                    imlib_context_set_drawable(win4); 
                    sprintf(mouse_pic,"%s/.icon-DE/iconcache/mouse.png",home);
                    if (access(mouse_pic,0)==-1)
                    {
                        system("cp /usr/share/icon-DE/iconcache/mouse.png ~/.icon-DE/iconcache/mouse.png");
                        sprintf(mouse_pic,"/usr/share/icon-DE/iconcache/mouse.png");
                    }
                    buffer4 = imlib_load_image(mouse_pic);
                    imlib_context_set_image(buffer4);
                    imlib_render_image_on_drawable(0, 0);
                    m_mouse=1;
                    imlib_context_set_image(im_bg);
                    imlib_context_set_drawable(win);
/*
                    imlib_context_set_image(back);
                    imlib_render_image_on_drawable(0, 0);
                    imlib_free_image();
                    imlib_context_set_font(font);
                    imlib_free_font();
*/
                }
                gettimeofday(&LastTime, 0);
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=300000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
            if (m_mouse==1)
            {
                imlib_context_set_drawable(win4); 
                imlib_context_set_image(buffer4);
                imlib_render_image_on_drawable(0, 0);
                imlib_context_set_image(back);
                imlib_context_set_drawable(win); 
            }

            imlib_context_set_blend(1);
            if(mytoggle == 1)
            {
                imlib_context_set_image(bigback);
                xl=x-24;
                yl=y-24;
            }else{
                imlib_context_set_image(back);
                xl=x-10;
                yl=y-10;
            }
            temp = imlib_clone_image();
            imlib_context_set_image(temp);
            char bump[]="bump_map_point(x=[],y=[],map=""blend.jpg);";
            imlib_apply_filter
            (bump, &xl, &yl);
            imlib_context_set_image(back);
            imlib_render_image_on_drawable(0, 0);
            temp2 = im_bg;
            im_bg = temp;
            imlib_context_set_image(im_bg);
            imlib_context_set_blend(1);
            imlib_render_image_on_drawable(0, 0);
            im_bg = temp2;
            imlib_context_set_image(temp);
            imlib_free_image();
        } /* End else*/
    }
    return 0;
}


void exposelist(void){
    //printf("exposelist\n");
    char app[2000];
    if ((bord==1) or (trans_wind<1))
    {
        sprintf(app , "icon-bord \"%s\" \"%s\" %d %f &" ,title,skip,bord,trans_wind);
        system(app);    
    }
    sprintf(app,"%s &",appToRun);
//    printf("%s \n",app);
    system(app);
}
