// g++ -o ./icon-wmcl ./icon-wmcl.c    -lImlib2 -lX11 -lXmu `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib-2.0/glib.h>

#include "Imlib2.h"

Display                        *disp;
Window                            win;
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
char *appToRun;
int i3;

#include "./other_src/MWMHints.h"
#include "./other_src/wm_ctrl.c"

int main(int argc, char **argv)
{
    int                                 x, y;
    Imlib_Image                 im_bg = NULL;
    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
//    Imlib_Image                 buffer;
    Imlib_Image                 back;
    char                                *skip;
    Imlib_Color_Range     range;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }
    Imlib_Image                temp, temp2;

    int xl=0;
    int yl=0;
    char *title;
    int w_chg=0;
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));
    int bord=1;
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
//----arguments x y width height lower/raise(0/1) picture hidemode
    if ( argc != 3 )
    {
        printf("usage: title skip \n");
        return 1;
    }
    title=argv[1];
    skip=argv[2];
    
//    screenWidth=2;
//    screenHeight=2;
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);

    attr.override_redirect=True;
 //win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,CopyFromParent,InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask|CWBorderPixel|CWSaveUnder|CWColormap|CWBackPixel,&attr);
    win=XCreateWindow(disp,DefaultRootWindow(disp),-10,-10,5,5,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
//     win =    XCreateSimpleWindow(disp, DefaultRootWindow(disp), 0, 0, 100, 100, 0, 0, 0);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    XMapWindow(disp, win);

    XRaiseWindow(disp,win);

     /**
        * Start rendering
        */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
//    w=screenWidth;
//    h=screenHeight;
    char back_pic[1280];
    sprintf(back_pic,"%s/.icon-DE/pics/desk_icon_back.png",home);
    if (access(back_pic,0)==-1)
        sprintf(back_pic,"/usr/share/icon-DE/pics/desk_icon_back.png");
    back = imlib_load_image(back_pic);
    imlib_context_set_image(back);
//    buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);
    XMapWindow(disp, win);
    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);

    XResizeWindow(disp, win, 5, 5);
    XSync(disp, False);
    unsigned long i=1;
    i3=1;
//    Window cur_win=0;
//    Window                            cur_win_id;
    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    long ticks;
//                        MWMHints mwmhints;
//                        Atom prop;

    sleep(20);

//    time_t now_time;
    struct timeval now, tm,LastTime;
//    now_time=time(0);
    gettimeofday(&LastTime, 0);
    
    int cg=1;

//    printf("ok\n");
    if (bord==1)
    {
    } else {
	
    }
    list_windows(disp,skip);
    while (1)
    {
        w_chg=1;
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case Expose:
                break;
            case MotionNotify:
                x = ev.xmotion.x;
                y = ev.xmotion.y;
            default:
                break;
            case EnterNotify:		
                break;
            case LeaveNotify:		
                break;
            case ButtonPress:				
                if(ev.xbutton.button==1)
                {
                    break;
                }
            }    
        } else {
                //display 是由 XopenDisplay 返回的 Display *
                //w_chg=0;
            if (cg==0)
            {
                system("killall -9 Xephyr    2>/dev/null");
                system("kill -9 -1    2>/dev/null");
                sleep(10);
                return 1;
            }    
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=2000)
            {
                cg=0;
                list_windows(disp,skip);
                gettimeofday(&LastTime, 0);
                for (i=0;i<win_count;i++)
                {
                    if (win_pid_list[i]!=0)
                    if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                         cg=1;
                }
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=100000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        } /* End else*/
        if (w_chg==1)
        {
            imlib_context_set_image(back);
            xl=x-10;
            yl=y-10;
        }
    }
    imlib_context_set_image(im_bg);
    imlib_context_set_drawable(win);
    temp = imlib_clone_image();
    imlib_context_set_image(temp);
    char bump[]="bump_map_point(x=[],y=[],map=""blend.jpg);";
    imlib_apply_filter
        (bump, &xl, &yl);
    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    temp2 = im_bg;
    im_bg = temp;
    imlib_context_set_image(im_bg);
    imlib_context_set_blend(1);
    imlib_render_image_on_drawable(0, 0);
    im_bg = temp2;
    imlib_context_set_image(temp);
    imlib_free_image();
    return 0;
}

