//g++ -o ./bin/icon-panel ./src/icon-panel.c  -lX11 -lXft  `pkg-config --cflags --libs glib-2.0` -I/usr/include/freetype2
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>  //tray
#include <sys/time.h>
#include <sys/wait.h>
#include <X11/Xatom.h>
#include <X11/Xft/Xft.h>
#include <glib-2.0/glib.h>

#define DEBUG printf("%s:\t%d\n", __FUNCTION__, __LINE__)

#define MAX_TASK_WIDTH 100
#define WINWIDTH (scr_width)
//#define XFT_FONT "DejaVu Sans YuanTi-7"
char XFT_FONT[1024]="WenQuanYi Zen Hei-8";
#define PAGER_DIGIT_WIDTH 6
#define PAGER_BUTTON_WIDTH 20

//tray begin

/* defined in the systray spec */
#define SYSTEM_TRAY_REQUEST_DOCK    0
#define SYSTEM_TRAY_BEGIN_MESSAGE   1
#define SYSTEM_TRAY_CANCEL_MESSAGE  2
         
int argc;
char **argv;
Atom kde_systray_prop = None;
Atom net_opcode_atom;
Window net_sel_win;
char r_name[]="docker";
char r_class[]="Docker";
static gboolean envir_utf8; //2012.04.18
static void window_set_title (Display *disp, Window win,const char *title,const char mode); //2012.04.18

static Atom net_sel_atom;
static Atom net_manager_atom;
static Atom net_message_data_atom;

typedef enum {
  KDE = 1, /* kde specific */
  NET      /* follows the standard (freedesktop.org) */
} TrayWindowType;

typedef struct
{
  TrayWindowType type;
  Window id;
  int x, y;
} TrayWindow;

void reposition_icons();
void fix_geometry();
void inline set_prop(Window win, Atom at, Atom type, long val);

Window t_win = None, t_hint_win = None, t_root = None;
gboolean t_wmaker = FALSE; /* WindowMakerMode!!! wheeee */
GSList *t_icons = NULL;
int t_width = 0, t_height = 0;
int t_border = 1; /* blank area around icons. must be > 0 */
gboolean t_horizontal = TRUE; /* layout direction */
int t_icon_size = 15; /* width and height of systray icons */
int WINHEIGHT=15;

static char *t_display_string = NULL;
/* excluding the border. sum of all child apps */
static gboolean t_exit_app = FALSE;
#define VERSION "1.5"
//tray end

// tags name
const char *tags_name[] = {"乾", "坤", "震", "巽", "艮", "兑", "坎", "离"};


typedef struct task
{
	struct task *next;
	Window win;
	Pixmap icon;
	Pixmap mask;
	char *name;
	int pos_x;
	int width;
	unsigned int focused:1;
	unsigned int iconified:1;
	unsigned int icon_copied:1;
}
task;

typedef struct taskbar
{
	Window win;
	task *task_list;
	int num_tasks;
	int my_desktop;
	unsigned int hidden:1;
	unsigned int at_top:1;
}
taskbar;

#define MWM_HINTS_DECORATIONS         (1L << 1)
typedef struct _mwmhints
{
	unsigned long flags;
	unsigned long functions;
	unsigned long decorations;
	long inputMode;
	unsigned long status;
}
MWMHints;

#define WIN_STATE_STICKY          (1<<0)	/* everyone knows sticky */
#define WIN_STATE_MINIMIZED       (1<<1)	/* ??? */
#define WIN_STATE_MAXIMIZED_VERT  (1<<2)	/* window in maximized V state */
#define WIN_STATE_MAXIMIZED_HORIZ (1<<3)	/* window in maximized H state */
#define WIN_STATE_HIDDEN          (1<<4)	/* not on taskbar but window visible */
#define WIN_STATE_SHADED          (1<<5)	/* shaded (NeXT style) */
#define WIN_STATE_HID_WORKSPACE   (1<<6)	/* not on current desktop */
#define WIN_STATE_HID_TRANSIENT   (1<<7)	/* owner of transient is hidden */
#define WIN_STATE_FIXED_POSITION  (1<<8)	/* window is fixed in position even */
#define WIN_STATE_ARRANGE_IGNORE  (1<<9)	/* ignore for auto arranging */

#define WIN_HINTS_SKIP_FOCUS      (1<<0)	/* "alt-tab" skips this win */
#define WIN_HINTS_SKIP_WINLIST    (1<<1)	/* not in win list */
#define WIN_HINTS_SKIP_TASKBAR    (1<<2)	/* not on taskbar */
#define WIN_HINTS_GROUP_TRANSIENT (1<<3)	/* ??????? */
#define WIN_HINTS_FOCUS_ON_CLICK  (1<<4)	/* app only accepts focus when clicked */
#define WIN_HINTS_DO_NOT_COVER    (1<<5)	/* attempt to not cover this window */

Display *dd;
Window root_win;
GC fore_gc;
taskbar tb;
int scr_screen;
int scr_depth;
int scr_width;
int scr_height;
int text_y;
int pager_size;
int tray_size;
int task_width;
unsigned int tag_mask;
static char stext[256] = "";

XftDraw *xftdraw;
XftFont *xfs;
XGlyphInfo *extents;

struct colors {
    unsigned short red, green, blue;
} cols[] = {
    {0xd75c, 0xd75c, 0xd75c},         /* 0. light gray */
    {0xbefb, 0xbaea, 0xbefb},         /* 1. mid gray */
    {0xaefb, 0xaaea, 0xaefb},         /* 2. dark gray */
    {0xefbe, 0xefbe, 0xefbe},         /* 3. white */
    {0x4000, 0x4000, 0x4000},         /* 4. darkest gray */
    {0x0000, 0x0000, 0x0000},         /* 5. black */
    {0x2000, 0x2000, 0x2000},
    {0x6000, 0x6000, 0x6000},
    {0x8000, 0x8000, 0x8000},
    {0xa000, 0xa000, 0xa000},
};

#define PALETTE_COUNT (sizeof(cols) / sizeof(cols[0].red) / 3)

unsigned long palette[PALETTE_COUNT];

const char *atom_names[] = {
    /* clients */
    "WM_STATE",
    "_MOTIF_WM_HINTS",
    "_NET_WM_STATE",
    "_NET_WM_STATE_SKIP_TASKBAR",
    "_NET_WM_STATE_SHADED",
    "_NET_WM_DESKTOP",
    "_NET_WM_WINDOW_TYPE",
    "_NET_WM_WINDOW_TYPE_DOCK", /* 8 */
    "_NET_WM_STRUT",
    "_WIN_HINTS",
    /* root */
    "_NET_CLIENT_LIST",
    "_NET_NUMBER_OF_DESKTOPS",
    "_NET_CURRENT_DESKTOP",
};

#define ATOM_COUNT (sizeof(atom_names) / sizeof(atom_names[0]))

Atom atoms[ATOM_COUNT];
Atom netwmname;

#define atom_WM_STATE atoms[0]
#define atom__MOTIF_WM_HINTS atoms[1]
#define atom__NET_WM_STATE atoms[2]
#define atom__NET_WM_STATE_SKIP_TASKBAR atoms[3]
#define atom__NET_WM_STATE_SHADED atoms[4]
#define atom__NET_WM_DESKTOP atoms[5]
#define atom__NET_WM_WINDOW_TYPE atoms[6]
#define atom__NET_WM_WINDOW_TYPE_DOCK atoms[7]
#define atom__NET_WM_STRUT atoms[8]
#define atom__WIN_HINTS atoms[9]
#define atom__NET_CLIENT_LIST atoms[10]
#define atom__NET_NUMBER_OF_DESKTOPS atoms[11]
#define atom__NET_CURRENT_DESKTOP atoms[12]

//tray bagin**********************************************************
gboolean icon_add(Window id, TrayWindowType type);
void icon_remove(GSList *node);

static void net_create_selection_window()
{
  net_sel_win = XCreateSimpleWindow(dd, t_root, -1, -1, 1, 1, 0, 0, 0);
  window_set_title (dd, net_sel_win,"IconTask",'T'); 
  assert(net_sel_win);
  XClassHint classhints;
  classhints.res_name = r_name;
  classhints.res_class = r_class;
  XSetClassHint(dd,net_sel_win,&classhints);
}


static void net_destroy_selection_window()
{
  XDestroyWindow(dd, net_sel_win);
  net_sel_win = None;
}


void net_init()
{
  char *name;
  XEvent m;

  name = g_strdup_printf("_NET_SYSTEM_TRAY_S%d", DefaultScreen(dd));
  net_sel_atom = XInternAtom(dd, name, False);
  assert(net_sel_atom);
  net_opcode_atom = XInternAtom(dd, "_NET_SYSTEM_TRAY_OPCODE", False);
  assert(net_opcode_atom);
  net_manager_atom = XInternAtom(dd, "MANAGER", False);
  assert(net_manager_atom);
  net_message_data_atom = XInternAtom(dd, "_NET_SYSTEM_TRAY_MESSAGE_DATA",
                                      False);
   assert(net_message_data_atom);

  net_create_selection_window();
  
  XSetSelectionOwner(dd, net_sel_atom, net_sel_win, CurrentTime);
  if (XGetSelectionOwner(dd, net_sel_atom) != net_sel_win)
    return; /* we don't get the selection */

  m.type = ClientMessage;
  m.xclient.message_type = net_manager_atom;
  m.xclient.format = 32;
  m.xclient.data.l[0] = CurrentTime;
  m.xclient.data.l[1] = net_sel_atom;
  m.xclient.data.l[2] = net_sel_win;
  m.xclient.data.l[3] = 0;
  m.xclient.data.l[4] = 0;
  XSendEvent(dd, t_root, False, StructureNotifyMask, &m);
}


void net_destroy()
{
  net_destroy_selection_window();
}


void net_message(XClientMessageEvent *e)
{
  unsigned long opcode;
  Window id;

  assert(e);

  opcode = e->data.l[1];

  switch (opcode)
  {
  case SYSTEM_TRAY_REQUEST_DOCK: /* dock a new icon */
    id = e->data.l[2];
    if (id && icon_add(id, NET))
      XSelectInput(dd, id, StructureNotifyMask);
    break;

  case SYSTEM_TRAY_BEGIN_MESSAGE:
    g_printerr("Message From Dockapp\n");
    id = e->window;
    break;

  case SYSTEM_TRAY_CANCEL_MESSAGE:
    g_printerr("Message Cancelled\n");
    id = e->window;
    break;

  default:
    if (opcode == net_message_data_atom) {
      g_printerr("Text For Message From Dockapp:\n%s\n", e->data.b);
      id = e->window;
      break;
    }
    
    /* unknown message type. not in the spec. */
    g_printerr("Warning: Received unknown client message to System Tray "
               "selection window.\n");
    break;
  }
}


void net_icon_remove(TrayWindow *traywin)
{
  assert(traywin);
  
  XSelectInput(dd, traywin->id, NoEventMask);
}


void kde_update_icons();

gboolean error;
int window_error_handler(Display *d, XErrorEvent *e)
{
  d=d;e=e;
  if (e->error_code == BadWindow) {
    error = TRUE;
  } else {
    g_printerr("X ERROR NOT BAD WINDOW!\n");
    abort();
  }
  return 0;
}


gboolean icon_swallow(TrayWindow *traywin)
{
  XErrorHandler old;

  error = FALSE;
  old = XSetErrorHandler(window_error_handler);
  XReparentWindow(dd, traywin->id, t_win, 0, 0);
  XSync(dd, False);
  XSetErrorHandler(old);

  return !error;
}


/*
  The traywin must have its id and type set.
*/
gboolean icon_add(Window id, TrayWindowType type)
{
  TrayWindow *traywin;

  assert(id);
  assert(type);

  if (t_wmaker) {
    /* do we have room in our window for another icon? */
    unsigned int max = (t_width / t_icon_size) * (t_height / t_icon_size);
    if (g_slist_length(t_icons) >= max)
      return FALSE; /* no room, sorry! REJECTED! */
  }

  traywin = g_new0(TrayWindow, 1);
  traywin->type = type;
  traywin->id = id;

  if (!icon_swallow(traywin)) {
    g_free(traywin);
    return FALSE;
  }

  /* find the positon for the systray app window */
  if (!t_wmaker) {
    traywin->x = t_border + (t_horizontal ? t_width : 0);
    traywin->y = t_border + (t_horizontal ? 0 : t_height);
  } else {
    int count = g_slist_length(t_icons);
    traywin->x = t_border + ((t_width % t_icon_size) / 2) +
      (count % (t_width / t_icon_size)) * t_icon_size;
    traywin->y = t_border + ((t_height % t_icon_size) / 2) +
      (count / (t_height / t_icon_size)) * t_icon_size;
  }

  /* add the new icon to the list */
  t_icons = g_slist_append(t_icons, traywin);

  /* watch for the icon trying to resize itself! BAD ICON! BAD! */
  XSelectInput(dd, traywin->id, StructureNotifyMask);

  /* position and size the icon window */
  XMoveResizeWindow(dd, traywin->id,
                    traywin->x, traywin->y, t_icon_size, t_icon_size);
  
  /* resize our window so that the new window can fit in it */
  fix_geometry();

  /* flush before clearing, otherwise the clear isn't effective. */
  XFlush(dd);
  /* make sure the new child will get the right stuff in its background
     for ParentRelative. */
//  XClearWindow(dd, t_win);
  
  /* show the window */
  XMapRaised(dd, traywin->id);

  return TRUE;
}


void icon_remove(GSList *node)
{
  XErrorHandler old;
  TrayWindow *traywin = (TrayWindow*)node->data;
  Window traywin_id = traywin->id;

  if (traywin->type == NET)
    net_icon_remove(traywin);

  XSelectInput(dd, traywin->id, NoEventMask);
  
  /* remove it from our list */
  g_free(node->data);
  t_icons = g_slist_remove_link(t_icons, node);

  /* reparent it to root */
  error = FALSE;
  old = XSetErrorHandler(window_error_handler);
  XReparentWindow(dd, traywin_id, t_root, 0, 0);
  XSync(dd, False);
  XSetErrorHandler(old);

  reposition_icons();
  fix_geometry();
}
gboolean xprop_get8(Window window, Atom atom, Atom type, int size,
                    gulong *count, guchar **value)
{
  Atom ret_type;
  int ret_size;
  unsigned long ret_bytes;
  int result;
  unsigned long nelements = *count;
  unsigned long maxread = nelements;

  *value = NULL;
  
  /* try get the first element */
  result = XGetWindowProperty(dd, window, atom, 0l, 1l, False,
                              AnyPropertyType, &ret_type, &ret_size,
                              &nelements, &ret_bytes, value);
  if (! (result == Success && ret_type == type &&
         ret_size == size && nelements > 0)) {
    if (*value) XFree(*value);
    *value = NULL;
    nelements = 0;
  } else {
    /* we didn't the whole property's value, more to get */
    if (! (ret_bytes == 0 || maxread <= nelements)) {
      int remain;
      
      /* get the entire property since it is larger than one element long */
      XFree(*value);
      /*
        the number of longs that need to be retreived to get the property's
        entire value. The last + 1 is the first long that we retrieved above.
      */
      remain = (ret_bytes - 1)/sizeof(long) + 1 + 1;
      /* dont get more than the max */
      if (remain > size/8 * (signed)maxread)
        remain = size/8 * (signed)maxread;
      result = XGetWindowProperty(dd, window, atom, 0l, remain,
                                  False, type, &ret_type, &ret_size,
                                  &nelements, &ret_bytes, value);
      /*
       If the property has changed type/size, or has grown since our first
        read of it, then stop here and try again. If it shrank, then this will
        still work.
      */
      if (!(result == Success && ret_type == type &&
            ret_size == size && ret_bytes == 0)) {
        if (*value) XFree(*value);
        xprop_get8(window, atom, type, size, count, value);
      }
    }
  }

  *count = nelements;
  return *value != NULL;
}

gboolean xprop_get32(Window window, Atom atom, Atom type, int size,
                     gulong *count, gulong **value)
{
  return xprop_get8(window, atom, type, size, count, (guchar**)value);
}
                     
void kde_init()
{
  kde_systray_prop = XInternAtom(dd,
                                 "_KDE_NET_SYSTEM_TRAY_WINDOWS", False);
  assert(kde_systray_prop);

  XSelectInput(dd, t_root, PropertyChangeMask);
  kde_update_icons();
}

void kde_update_icons()
{
  gulong count = (unsigned) -1; /* grab as many as possible */
  Window *ids;
  unsigned int i;
  GSList *it, *next;
  gboolean removed = FALSE; /* were any removed? */

  if (! xprop_get32(t_root, kde_systray_prop, XA_WINDOW, sizeof(Window)*8,
                    &count, &ids))
    return;

  /* add new windows to our list */
  for (i = 0; i < count; ++i) {
    for (it = t_icons; it != NULL; it = g_slist_next(it)) {
      TrayWindow *traywin = (TrayWindow*)it->data;
      if (traywin->id == ids[i])
        break;
    }
    if (!it)
      icon_add(ids[i], KDE);
  }

  /* remove windows from our list that no longer exist in the property */
  for (it = t_icons; it != NULL;) {
    TrayWindow *traywin = (TrayWindow*)it->data;
    gboolean exists;

    if (traywin->type != KDE) {
      /* don't go removing non-kde windows */
      exists = TRUE;
    } else {
      exists = FALSE;
      for (i = 0; i < count; ++i) {
        if (traywin->id == ids[i]) {
          exists = TRUE;
          break;
        }
      }
    }
    
    next = g_slist_next(it);
    if (!exists) {
      icon_remove(it);
      removed =TRUE;
    }
    it = next;
  }

  if (removed) {
    /* at least one tray app was removed, so reorganize 'em all and resize*/
    reposition_icons();
    fix_geometry();
  }

  XFree(ids);
}


void signal_handler(int signal)
{
  switch (signal)
  {
  case SIGSEGV:
  case SIGFPE:
    g_printerr("Segmentation Fault or Critical Error encountered. "
               "Dumping core and aborting.\n");
    abort();
    
  case SIGPIPE:
  case SIGTERM:
  case SIGINT:
  case SIGHUP:
    t_exit_app = TRUE;
  }
}


void parse_cmd_line()
{
  int i;
  gboolean help = FALSE;
  
  for (i = 1; i < argc; i++) {
    if (0 == strcasecmp(argv[i], "-display")) {
      ++i;
      if (i < argc) {
        t_display_string = argv[i];
      } else { /* argument doesn't exist */
        g_printerr("-display requires a parameter\n");
        help = TRUE;
      }
    } else if (0 == strcasecmp(argv[i], "-wmaker")) {
      t_wmaker = TRUE;
    } else if (0 == strcasecmp(argv[i], "-vertical")) {
      t_horizontal = FALSE;
    } else if (0 == strcasecmp(argv[i], "-border")) {
      ++i;

      if (i < argc) {
        int b = atoi(argv[i]);
        if (b > 0) {
          t_border = b;
        } else {
          g_printerr("-border must be a value greater than 0\n");
          help = TRUE;
        }
      } else { /* argument doesn't exist */
        g_printerr("-border requires a parameter\n");
        help = TRUE;
      }
      } else if (0 == strcasecmp(argv[i], "-iconsize")) {
      ++i;
      if (i < argc) {
        int s = atoi(argv[i]);
        if (s > 0) {
          t_icon_size = s;
        } else {
          g_printerr("-iconsize must be a value greater than 0\n");
          help = TRUE;
        }
      } else { /* argument doesn't exist */
        g_printerr("-iconsize requires a parameter\n");
        help = TRUE;
      }
    } else {
      if (argv[i][0] == '-')
        help = TRUE;
    }


    if (help) {
      /* show usage help */
      g_print("%s - version \n", argv[0]);
      g_print("Copyright 2003, Ben Jansens <ben@orodu.net>\n\n");
      g_print("Usage: %s [OPTIONS]\n\n", argv[0]);
      g_print("Options:\n");
      g_print("  -help             Show this help.\n");
      g_print("  -display DISLPAY  The X display to connect to.\n");
      g_print("  -border           The width of the border to put around the\n"
              "                    system tray icons. Defaults to 1.\n");
      g_print("  -vertical         Line up the icons vertically. Defaults to\n"
              "                    horizontally.\n");
      g_print("  -wmaker           WindowMaker mode. This makes docker a\n"
              "                    fixed size (64x64) to appear nicely in\n"
              "                    in WindowMaker.\n"
              "                    Note: In this mode, you have a fixed\n"
              "                    number of icons that docker can hold.\n");
      g_print("  -iconsize SIZE    The size (width and height) to display\n"
              "                    icons as in the system tray. Defaults to\n"
              "                    24.\n");
      exit(1);
    }
  }
}

void create_hint_win()
{
  XWMHints hints;
  XClassHint classhints;

  t_hint_win = XCreateSimpleWindow(dd, t_win, 0, 0, 1, 1, 0, 0, 0);
  window_set_title (dd, t_hint_win,"IconTask",'T'); 
  assert(t_hint_win);

  hints.flags = StateHint | WindowGroupHint | IconWindowHint;
  hints.initial_state = WithdrawnState;
  hints.window_group = t_hint_win;
  hints.icon_window = t_win;

  classhints.res_name = r_name;
  classhints.res_class = r_class;
  XSetWMProperties(dd, t_hint_win, NULL, NULL, argv, argc,
                   NULL, &hints, &classhints);

  XMapWindow(dd, t_hint_win);
}


void create_main_window()
{
    MWMHints mwm;
    XSizeHints size_hints;
    XWMHints wmhints;
    XSetWindowAttributes att;
    unsigned long strut[4];
    att.override_redirect=True;
    att.background_pixel = palette[0];
    att.event_mask = ButtonPressMask | ExposureMask;
    t_win = XCreateWindow(dd, t_root, 0, scr_height-WINHEIGHT, WINWIDTH, WINHEIGHT,
            0, CopyFromParent, InputOutput, CopyFromParent,
            CWBackPixel | CWOverrideRedirect | CWEventMask, &att);
    window_set_title (dd, t_win,"IconTask",'T'); 
    XClassHint classhints;
    classhints.res_name = r_name;
    classhints.res_class = r_class;
    XSetClassHint(dd,t_win,&classhints);

    strut[0] = 0;
    strut[1] = 0;
    strut[2] = 0;
    strut[3] = WINHEIGHT;
    XChangeProperty(dd, t_win, atom__NET_WM_STRUT, XA_CARDINAL, 32,
                     PropModeReplace,(unsigned char *) strut, 4);
    /* reside on ALL desktops */
    set_prop(t_win, atom__NET_WM_DESKTOP, XA_CARDINAL, 0xFFFFFFFF);
    set_prop(t_win, atom__NET_WM_WINDOW_TYPE, XA_ATOM,
              atom__NET_WM_WINDOW_TYPE_DOCK);
    /* use old gnome hint since sawfish doesn't support _NET_WM_STRUT */
    set_prop(t_win, atom__WIN_HINTS, XA_CARDINAL,
              WIN_HINTS_SKIP_FOCUS | WIN_HINTS_SKIP_WINLIST |
              WIN_HINTS_SKIP_TASKBAR | WIN_HINTS_DO_NOT_COVER);
    /* borderless motif hint */
    bzero(&mwm, sizeof(mwm));
    mwm.flags = MWM_HINTS_DECORATIONS;
    XChangeProperty(dd, t_win, atom__MOTIF_WM_HINTS, atom__MOTIF_WM_HINTS, 32,
                     PropModeReplace,(unsigned char *) &mwm,
                     sizeof(MWMHints) / 4);
    /* make sure the WM obays our window position */
    size_hints.flags = PPosition;
    /*XSetWMNormalHints(dd, win, &size_hints);*/
    XChangeProperty(dd, t_win, XA_WM_NORMAL_HINTS, XA_WM_SIZE_HINTS, 32,
                     PropModeReplace,(unsigned char *) &size_hints,
                     sizeof(XSizeHints) / 4);
    /* make our window unfocusable */
    wmhints.flags = InputHint;
    wmhints.input = False;
    /*XSetWMHints(dd, win, &wmhints);*/
    XChangeProperty(dd, t_win, XA_WM_HINTS, XA_WM_HINTS, 32, PropModeReplace,
                    (unsigned char *) &wmhints, sizeof(XWMHints) / 4);
    XMapWindow(dd, t_win);
  create_hint_win();
}


void reposition_icons()
{
  int x = t_border + ((t_width % t_icon_size) / 2),
      y = t_border + ((t_height % t_icon_size) / 2);
  GSList *it;
  
  for (it = t_icons; it != NULL; it = g_slist_next(it)) {
    TrayWindow *traywin = (TrayWindow*)it->data;
    traywin->x = x;
    traywin->y = y;
    XMoveWindow(dd, traywin->id, x, y);
    XSync(dd, False);
    if (t_wmaker) {
      x += t_icon_size;
      if (x + t_icon_size > t_width) {
        x = t_border;
        y += t_icon_size;
      }
    } else if (t_horizontal)
      x += t_icon_size;
    else
      y += t_icon_size;
  }
}


void fix_geometry()
{
  GSList *it;

  if (t_wmaker) return;
  
  t_width = t_horizontal ? 0 : t_icon_size;
  t_height = t_horizontal ? t_icon_size : 0;
  for (it = t_icons; it != NULL; it = g_slist_next(it)) {
    if (t_horizontal)
      t_width += t_icon_size;
    else
      t_height += t_icon_size;
  }

  tray_size=t_width;
  task_width=WINWIDTH-tray_size;
  XResizeWindow(dd, t_win, WINWIDTH , WINHEIGHT);
  XMoveResizeWindow(dd, tb.win, tray_size+1, 0,task_width,WINHEIGHT);
//  XMapWindow(dd, t_win);
  
}

//tray end*************************************************************

//2012.04.18
static void window_set_title (Display *disp, Window win, /* {{{ */
        const char *title,const char mode) {
    gchar *title_utf8;
    gchar *title_local;

    if (envir_utf8) {
        title_utf8 = (gchar*)g_strdup(title);
        title_local = NULL;
    }
    else {
        if (! (title_utf8 = (gchar*)g_locale_to_utf8(title, -1, NULL, NULL, NULL))) {
            title_utf8 = (gchar*)g_strdup(title);
        }
        title_local = g_strdup(title);
    }
    
    if (mode == 'T' || mode == 'N') {
        /* set name */
        if (title_local) {
            XChangeProperty(disp, win, XA_WM_NAME, XA_STRING, 8, PropModeReplace,
                    (const unsigned char*)title_local, strlen(title_local));
        }
        else {
            XDeleteProperty(disp, win, XA_WM_NAME);
        }
        XChangeProperty(disp, win, XInternAtom(disp, "_NET_WM_NAME", False), 
                XInternAtom(disp, "UTF8_STRING", False), 8, PropModeReplace,
                (const unsigned char*)title_utf8, strlen(title_utf8));
    }

    if (mode == 'T' || mode == 'I') {
        /* set icon name */
        if (title_local) {
            XChangeProperty(disp, win, XA_WM_ICON_NAME, XA_STRING, 8, PropModeReplace,
                    (const unsigned char*)title_local, strlen(title_local));
        }
        else {
            XDeleteProperty(disp, win, XA_WM_ICON_NAME);
        }
        XChangeProperty(disp, win, XInternAtom(disp, "_NET_WM_ICON_NAME", False), 
                XInternAtom(disp, "UTF8_STRING", False), 8, PropModeReplace,
                (const unsigned char*)title_utf8, strlen(title_utf8));
    }
    
    g_free(title_utf8);
    g_free(title_local);
    
}/*}}}*/



void *get_prop_data(Window win, Atom prop, Atom type, int *items)
{
    Atom type_ret;
    int format_ret;
    unsigned long items_ret;
    unsigned long after_ret;
    unsigned char *prop_data;
    prop_data = 0;
    XGetWindowProperty(dd, win, prop, 0, 4096, False,
                        type, &type_ret, &format_ret, &items_ret,
                        &after_ret, &prop_data);

    if(items) {
        *items = items_ret;
    }

    return prop_data;
}

void inline set_foreground(int index)
{
    XSetForeground(dd, fore_gc, palette[index]);
}

void inline fill_rect(int x, int y, int a, int b)
{
    XFillRectangle(dd, tb.win, fore_gc, x, y, a, b);
}

int generic_get_int(Window win, Atom at)
{
    int num = 0;
    unsigned long *data;
    data = (long unsigned int*)get_prop_data(win, at, XA_CARDINAL, 0);

    if(data) {
        num = *data;
        XFree(data);
    }

    return num;
}

int inline find_desktop(Window win)
{
    return generic_get_int(win, atom__NET_WM_DESKTOP);
}

int is_iconified(Window win)
{
    unsigned long *data;
    int ret = 0;
    data = (long unsigned int*)get_prop_data(win, atom_WM_STATE, atom_WM_STATE, 0);

    if(data) {
        if(data[0] == IconicState) {
            ret = 1;
        }

        XFree(data);
    }

    return ret;
}

int inline get_current_desktop(void)
{
    return generic_get_int(root_win, atom__NET_CURRENT_DESKTOP);
}

int inline get_number_of_desktops(void)
{
    return generic_get_int(root_win, atom__NET_NUMBER_OF_DESKTOPS);
}

void add_task(Window win, int focus)
{
    task *tk, *list;

    if(win == t_win) {
        return;
    }

    /* is this window on a different desktop? */
    if(tb.my_desktop != find_desktop(win)) {
        return;
    }

    tk = (task*)calloc(1, sizeof(task));
    tk->win = win;
    tk->focused = focus;

    XTextProperty prop;
    XGetTextProperty(dd, win, &prop, netwmname);
    tk->name = (char *)prop.value;

    tk->iconified = is_iconified(win);
    XSelectInput(dd, win, PropertyChangeMask | FocusChangeMask |
                  StructureNotifyMask);
    /* now append it to our linked list */
    tb.num_tasks++;
    list = tb.task_list;

    if(!list) {
        tb.task_list = tk;
        return;
    }

    while(1) {
        if(!list->next) {
            list->next = tk;
            return;
        }

        list = list->next;
    }
}

void inline gui_sync(void)
{
    XSync(dd, False);
}

void inline set_prop(Window win, Atom at, Atom type, long val)
{
    XChangeProperty(dd, win, at, type, 32,
                     PropModeReplace,(unsigned char *) &val, 1);
}

Window gui_create_taskbar(void)
{
    Window win;
    MWMHints mwm;
    XSizeHints size_hints;
    XWMHints wmhints;
    XSetWindowAttributes att;
    unsigned long strut[4];
    att.override_redirect=True;
    att.background_pixel = palette[0];
    att.event_mask = ButtonPressMask | ExposureMask;
//    win = XCreateWindow(dd, t_win, 100, scr_height-WINHEIGHT, WINWIDTH-100, WINHEIGHT,
    win = XCreateWindow(dd, t_win, 0, 0, WINWIDTH, WINHEIGHT,
            0, CopyFromParent, InputOutput, CopyFromParent,
            CWBackPixel | CWEventMask, &att);
    window_set_title (dd, win,"IconTask",'T'); 
    XClassHint classhints;
    classhints.res_name = r_name;
    classhints.res_class = r_class;
    XSetClassHint(dd,win,&classhints);

    strut[0] = 0;
    strut[1] = 0;
    strut[2] = 0;
    strut[3] = WINHEIGHT;
    XChangeProperty(dd, win, atom__NET_WM_STRUT, XA_CARDINAL, 32,
                     PropModeReplace,(unsigned char *) strut, 4);
    /* reside on ALL desktops */
    set_prop(win, atom__NET_WM_DESKTOP, XA_CARDINAL, 0xFFFFFFFF);
    set_prop(win, atom__NET_WM_WINDOW_TYPE, XA_ATOM,
              atom__NET_WM_WINDOW_TYPE_DOCK);
    /* use old gnome hint since sawfish doesn't support _NET_WM_STRUT */
    set_prop(win, atom__WIN_HINTS, XA_CARDINAL,
              WIN_HINTS_SKIP_FOCUS | WIN_HINTS_SKIP_WINLIST |
              WIN_HINTS_SKIP_TASKBAR | WIN_HINTS_DO_NOT_COVER);
    /* borderless motif hint */
    bzero(&mwm, sizeof(mwm));
    mwm.flags = MWM_HINTS_DECORATIONS;
    XChangeProperty(dd, win, atom__MOTIF_WM_HINTS, atom__MOTIF_WM_HINTS, 32,
                     PropModeReplace,(unsigned char *) &mwm,
                     sizeof(MWMHints) / 4);
    /* make sure the WM obays our window position */
    size_hints.flags = PPosition;
    /*XSetWMNormalHints(dd, win, &size_hints);*/
    XChangeProperty(dd, win, XA_WM_NORMAL_HINTS, XA_WM_SIZE_HINTS, 32,
                     PropModeReplace,(unsigned char *) &size_hints,
                     sizeof(XSizeHints) / 4);
    /* make our window unfocusable */
    wmhints.flags = InputHint;
    wmhints.input = False;
    /*XSetWMHints(dd, win, &wmhints);*/
    XChangeProperty(dd, win, XA_WM_HINTS, XA_WM_HINTS, 32, PropModeReplace,
                    (unsigned char *) &wmhints, sizeof(XWMHints) / 4);
    XMapWindow(dd, win);
    xftdraw = XftDrawCreate(dd, win, DefaultVisual(dd, scr_screen),
                             DefaultColormap(dd, scr_screen));


    XMapWindow(dd, win);
    
//    XReparentWindow(dd, win, t_win, 0, 0);
    return win;
}


void sigchld(int unused)
{
    if(signal(SIGCHLD, sigchld) == SIG_ERR) {
        exit(1);
    }

    while(0 < waitpid(-1, NULL, WNOHANG));
}

void gui_init(void)
{
    XGCValues gcv;
    XColor xcl;
    unsigned int i;
    i = 0;

//    pthread_t status_thread;
//    pthread_create(&status_thread, NULL, statusloop, NULL);

    sigchld(0); // dwm say it can clean up zombie process, seems good

    tag_mask = 0;

    do {
        xcl.red = cols[i].red;
        xcl.green = cols[i].green;
        xcl.blue = cols[i].blue;
        XAllocColor(dd, DefaultColormap(dd, scr_screen), &xcl);
        palette[i] = xcl.pixel;
        i++;
    } while(i < PALETTE_COUNT);

    xfs = XftFontOpenName(dd, scr_screen, XFT_FONT);
    extents = (XGlyphInfo* )malloc(sizeof(XGlyphInfo));

    gcv.graphics_exposures = False;
    text_y = xfs->ascent +((WINHEIGHT -(xfs->ascent + xfs->descent)) / 2);
    fore_gc = XCreateGC(dd, root_win, GCGraphicsExposures, &gcv);
}

void inline draw_bigbox(int x, int width)
{
    set_foreground(4);
    fill_rect(x, 0, width, WINHEIGHT);
}

void inline draw_tinybox(int x, int width)
{
    set_foreground(1);
    fill_rect(x + 2, 2, width, width);
}

void inline default_status(void)
{
    if(stext[0] == '\0') {
    time_t curtime;
    struct timeval tv;

    gettimeofday(&tv, NULL);
    curtime = tv.tv_sec;
    strftime(stext, 256, "%Y-%m-%d", localtime(&curtime));
    }
}

void draw_status(void)
{
    XftColor col;

    default_status();

    int len = strlen(stext);
    XftTextExtentsUtf8(dd, xfs,(const FcChar8 *)stext, len, extents);
	int stext_width = extents->xOff + 1;

    col.color.alpha = 0xffff;
    col.color.red = cols[1].red;
    col.color.green = cols[1].green;
    col.color.blue = cols[1].blue;

    set_foreground(3);
    fill_rect(task_width - stext_width-2, 0, 1, WINHEIGHT);
    XftDrawStringUtf8(xftdraw, &col, xfs, task_width - stext_width, text_y,(XftChar8 *)stext, len);
}

void gui_draw_task(task *tk)
{
    int len;
    int x = tk->pos_x;
    int taskw = tk->width;
    XGlyphInfo ext;
    XftColor col;

    if(!tk->name) {
        return;
    }

    if(tk->focused) {
        draw_bigbox(x, taskw);
    } else {
        set_foreground(6);
        fill_rect(x, 0, taskw, WINHEIGHT);
    }

    register int text_x = x + 2;
    /* check how many chars can fit */
    len = strlen(tk->name);

    while(len > 0) {
        XftTextExtentsUtf8(dd, xfs,(const XftChar8 *)tk->name, len, &ext);
        if(ext.width < taskw -(text_x - x) - 1) {
            break;
        }
        len--;
    }

    col.color.alpha = 0xffff;

    if(tk->iconified) {
        col.color.red = cols[2].red;
        col.color.green = cols[2].green;
        col.color.blue = cols[2].blue;
    } else {
        col.color.red = cols[1].red;
        col.color.green = cols[1].green;
        col.color.blue = cols[1].blue;
    }

    /* draw task's name here */
    XftDrawStringUtf8(xftdraw, &col, xfs, text_x, text_y,(XftChar8 *)tk->name, len);
    set_foreground(3);
    fill_rect(x+taskw-2, 0, 1, WINHEIGHT);
}

void toggle_shade(Window win)
{
    XClientMessageEvent xev;
    xev.type = ClientMessage;
    xev.window = win;
    xev.message_type = atom__NET_WM_STATE;
    xev.format = 32;
    xev.data.l[0] = 2;  /* toggle */
    xev.data.l[1] = atom__NET_WM_STATE_SHADED;
    xev.data.l[2] = 0;
    XSendEvent(dd, root_win, False, SubstructureNotifyMask,(XEvent *) &xev);
}

void switch_desk(int new_desk)
{
    if(get_number_of_desktops() <= new_desk) {
        return;
    }

    XEvent xev;
    long mask = SubstructureRedirectMask | SubstructureNotifyMask;
    xev.xclient.type = ClientMessage;
    xev.xclient.serial = 0;
    xev.xclient.send_event = True;
    xev.xclient.message_type = XInternAtom(dd, "_NET_CURRENT_DESKTOP", False);
    xev.xclient.window = root_win;
    xev.xclient.format = 32;
    xev.xclient.data.l[0] = new_desk;
    xev.xclient.data.l[1] = 0;
    xev.xclient.data.l[2] = 0;
    xev.xclient.data.l[3] = 0;
    xev.xclient.data.l[4] = 0;
    
    XSendEvent(dd, root_win, False, mask, &xev);
//    xev.type = ClientMessage;
//    xev.window = root_win;
//    xev.message_type = atom__NET_CURRENT_DESKTOP;
//    xev.format = 32;
//    xev.data.l[0] = new_desk;
//    XSendEvent(dd, root_win, False, SubstructureNotifyMask,(XEvent *) &xev);
}

void pager_draw_button(int x, int num)
{
    char label[8];
    XftColor col;

    if(num == tb.my_desktop) {
        /* current desktop */
        draw_bigbox(x, PAGER_BUTTON_WIDTH);
    } else {
        set_foreground(6);
        fill_rect(x, 0, PAGER_BUTTON_WIDTH + 1, WINHEIGHT);
    }

    if(((tag_mask >> num) & 1) == 1) {
        draw_tinybox(x, 3);
    }

    int str_length = sizeof(tags_name) / sizeof(tags_name[1]);
    if (num < str_length) {
        strcpy(label, tags_name[num]);
    } else {
        label[0] = '1' + num;
    }

    col.color.alpha = 0xffff;
    col.color.red = cols[1].red;
    col.color.green = cols[1].green;
    col.color.blue = cols[1].blue;

    XftDrawStringUtf8(xftdraw, &col, xfs, x +((PAGER_BUTTON_WIDTH - PAGER_DIGIT_WIDTH) / 3), text_y,(const FcChar8 *)label, strlen(label));
}

void draw_pager(void)
{
    int desks, i;
//    int x = 0;  //2012.04.17
    int x = 3;

    set_foreground(3);
    fill_rect(x-2, 0, 2, WINHEIGHT);
    
    desks = get_number_of_desktops();

    for(i = 0; i < desks; i++) {
        pager_draw_button(x, i);

        if(i > 8) {
            break;
        }

        x += PAGER_BUTTON_WIDTH;
    }
    set_foreground(3);
    fill_rect(x-1, 0, 2, WINHEIGHT);
    pager_size = x;
}

void gui_draw_taskbar(int sig)
{
    if(sig != SIGALRM) {
        return;
    }

    task *tk;
    int x, width, taskw;
    draw_pager();
    width = WINWIDTH -(pager_size);
    x = pager_size + 2;

    if(tb.num_tasks == 0) {
        goto clear;
    }

    taskw = width / tb.num_tasks;

    if(taskw > MAX_TASK_WIDTH) {
        taskw = MAX_TASK_WIDTH;
    }

    tk = tb.task_list;

    while(tk) {
        tk->pos_x = x;
        tk->width = taskw - 1;
        gui_draw_task(tk);
        x += taskw;
        tk = tk->next;
    }

    if(x <(width + pager_size + 2)) {
clear:
        set_foreground(6);
        fill_rect(x, 0, WINWIDTH , WINHEIGHT);
    }
    draw_status();
}

task *find_task(Window win)
{
    task *list = tb.task_list;

    while(list) {
        if(list->win == win) {
            return list;
        }

        list = list->next;
    }

    return 0;
}

void del_task(Window win)
{
    task *next, *prev = 0, *list = tb.task_list;

    while(list) {
        next = list->next;

        if(list->win == win) {
            /* unlink and free this task */
            tb.num_tasks--;

            if(list->mask != None) {
                XFreePixmap(dd, list->mask);
            }

            if(list->name) {
                XFree(list->name);
            }

            free(list);

            if(prev == 0) {
                tb.task_list = next;
            } else {
                prev->next = next;
            }

            return;
        }

        prev = list;
        list = next;
    }
}

void taskbar_read_clientlist(void)
{
    Window *win, focus_win;
    int num, i, rev, desk, new_desk = 0;
    task *list, *next;
    desk = get_current_desktop();

    if(desk != tb.my_desktop) {
        new_desk = 1;
        tb.my_desktop = desk;
    }

    XGetInputFocus(dd, &focus_win, &rev);
    win = (Window*)get_prop_data(root_win, atom__NET_CLIENT_LIST, XA_WINDOW, &num);

    if(!win) {
        return;
    }

    /* remove windows that arn't in the _NET_CLIENT_LIST anymore */
    list = tb.task_list;

    if(list) {
        tag_mask |= 1 << tb.my_desktop;
    } else {
        tag_mask &= ~(1 << tb.my_desktop);
    }

    while(list) {
        list->focused =(focus_win == list->win);
        next = list->next;

        if(!new_desk)
            for(i = num - 1; i >= 0; i--)
                if(list->win == win[i]) {
                    goto dontdel;
                }

        del_task(list->win);
dontdel:
        list = next;
    }

    /* add any new windows */
    for(i = 0; i < num; i++) {
        if(!find_task(win[i])) {
            add_task(win[i],(win[i] == focus_win));
        }
    }

    XFree(win);
}

void handle_press(int x, int y, int button)
{
    task *tk;
//    if(y > 0 && y < WINHEIGHT) {
//        switch_desk(x / PAGER_BUTTON_WIDTH);
//    }
//2012.04.17
    if( x>=0 && y > 0 && y < WINHEIGHT) {
        switch_desk(x / PAGER_BUTTON_WIDTH);
    }

    tk = tb.task_list;

    while(tk) {
        if(x > tk->pos_x && x < tk->pos_x + tk->width) {
            if(button == 3) {  /* right-click */
                toggle_shade(tk->win);
                return;
            }

            if(tk->iconified) {
                tk->iconified = 0;
                tk->focused = 1;
                XMapWindow(dd, tk->win);
            } else {
                if(tk->focused) {
                    tk->iconified = 1;
                    tk->focused = 0;
                    XIconifyWindow(dd, tk->win, scr_screen);
                } else {
                    tk->focused = 1;
                    XRaiseWindow(dd, tk->win);
                    XSetInputFocus(dd, tk->win, RevertToNone, CurrentTime);
                }
            }

            gui_sync();
            gui_draw_task(tk);
        } else {
            if(button == 1 && tk->focused) {
                tk->focused = 0;
                gui_draw_task(tk);
            }
        }

        tk = tk->next;
    }
}

void handle_focusin(Window win)
{
    task *tk;
    tk = tb.task_list;

    while(tk) {
        if(tk->focused) {
            if(tk->win != win) {
                tk->focused = 0;
                gui_draw_task(tk);
            }
        } else {
            if(tk->win == win) {
                tk->focused = 1;
                gui_draw_task(tk);
            }
        }

        tk = tk->next;
    }
}

void handle_propertynotify(Window win, Atom at)
{
    task *tk;

    if(win == root_win) {
        if(at == atom__NET_CLIENT_LIST || at == atom__NET_CURRENT_DESKTOP) {
            taskbar_read_clientlist();
            gui_draw_taskbar(SIGALRM);
        }

        return;
    }

    tk = find_task(win);

    if(!tk) {
        return;
    }

    if(at == XA_WM_NAME) {
        /* window's title changed */
        if(tk->name) {
            XFree(tk->name);
        }

        XTextProperty prop;
        XGetTextProperty(dd, win, &prop, netwmname);
        tk->name = (char *)prop.value;

        gui_draw_task(tk);
    } else if(at == atom_WM_STATE) {
        /* iconified state changed? */
        if(is_iconified(tk->win) != tk->iconified) {
            tk->iconified = !tk->iconified;
            gui_draw_task(tk);
        }
    }
}

void handle_error(Display *d, XErrorEvent *ev)
{
}

int main(int c,char ** v)
{
    XEvent ev;
    fd_set fd;
    int xfd;
    Window cover;
    GSList *it;
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));
    char ch2[1024];
    int n=0;
    char usermenufile[1024];

    dd = XOpenDisplay(NULL);

    if(!dd) {
        return 0;
    }

    scr_screen = DefaultScreen(dd);
    scr_depth = DefaultDepth(dd, scr_screen);
    scr_height = DisplayHeight(dd, scr_screen);
    scr_width = DisplayWidth(dd, scr_screen);
    root_win = RootWindow(dd, scr_screen);

    XSelectInput(dd, root_win, PropertyChangeMask);
    XSetErrorHandler((XErrorHandler) handle_error);
    XInternAtoms(dd, (char**)atom_names, ATOM_COUNT, False, atoms);
    netwmname = XInternAtom(dd, "_NET_WM_NAME", False);

//  char command[1024]=" ";
  FILE *freeNum;

  char rcfile[10]="panel.rc";
  sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
  if (access(usermenufile,0)==-1)
  {
    system("mkdir ~/.icon-DE");
    system("cp /etc/icon-de/panel.rc ~/.icon-DE/");
  }
  freeNum=fopen(usermenufile,"r");
  if ( freeNum==NULL)
  { 
    printf("error on open %s\n",usermenufile); 
    exit(1); 
  }
//  char ch;
  char buffer_rc[1024];

  while ( ! feof(freeNum) )
  {
    fgets(buffer_rc,1024,freeNum);
    for (n=0;n<1024;n++)
      if (buffer_rc[n]=='\n') buffer_rc[n]='\0';
//    printf("%s\n",buffer_rc); 
//    sprintf(command,"");
    if (strcmp(buffer_rc,"")!=0 )
    {
      sprintf(ch2,"%c",buffer_rc[0]);
      if (strcmp(ch2,"#")!=0 ) 
      {
        sprintf(ch2,"%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5]);
        if (strcmp(ch2,"fonts:")==0 )
        {
          for (n=0;n<1024-6;n++)
          {
             buffer_rc[n]=buffer_rc[n+6];
          } 
          for (n=1017;n<1024;n++)
          {
             buffer_rc[n]='\0';
          }
          sprintf(XFT_FONT,"%s",buffer_rc);
        }
        sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
        if (strcmp(ch2,"height:")==0 )
        {
          for (n=0;n<1024-7;n++)
          {
             buffer_rc[n]=buffer_rc[n+7];
          } 
          for (n=1016;n<1024;n++)
          {
             buffer_rc[n]='\0';
          }
          WINHEIGHT = atoi(buffer_rc);
          t_icon_size=WINHEIGHT;
        }
      }   
    }  
  }
  fclose(freeNum);




    gui_init();
    bzero(&tb, sizeof(struct taskbar));

    
//tray begin *******************************    
    struct sigaction act;
    argc = c; argv = v;
  
    act.sa_handler = signal_handler;
    act.sa_flags = 0;
    sigaction(SIGSEGV, &act, NULL);
    sigaction(SIGPIPE, &act, NULL);
    sigaction(SIGFPE, &act, NULL);
    sigaction(SIGTERM, &act, NULL);
    sigaction(SIGINT, &act, NULL);
    sigaction(SIGHUP, &act, NULL);

    parse_cmd_line();
    t_root = RootWindow(dd, DefaultScreen(dd));
    assert(t_root);

    if (t_wmaker)
      t_width = t_height = 64 - t_border * 2;
  
    create_main_window();

  /* set up to find KDE systray icons, and get any that already exist */
    kde_init();

    net_init();

  /* we want to get ConfigureNotify events, and assume our parent's background
     has changed when we do, so we need to refresh ourself to match */
    XSelectInput(dd, t_win, StructureNotifyMask);


//tray end *********************************

    tb.win = gui_create_taskbar();
    xfd = ConnectionNumber(dd);

    gui_draw_taskbar(SIGALRM);
    signal(SIGALRM, gui_draw_taskbar);

    gui_sync();

    int s_ch=0;

    while(1) {
        FD_ZERO(&fd);
        FD_SET(xfd, &fd);
        select(xfd + 1, &fd, 0, 0, 0);

        while(XPending(dd)) {
            XNextEvent(dd, &ev);

            switch(ev.type) {
                case ButtonPress:
                    handle_press(ev.xbutton.x, ev.xbutton.y, ev.xbutton.button);
                    break;
                case Expose:
                    s_ch=1;
                    break;
                case DestroyNotify:
//tray begin ********************                
                    for (it = t_icons; it; it = g_slist_next(it)) {
                        if (((TrayWindow*)it->data)->id == ev.xany.window) {
                            icon_remove(it);
                            break;
                        }
                    }
//tray end *************************        
                    del_task(ev.xdestroywindow.window);
                    break;
                case PropertyNotify:
                    handle_propertynotify(ev.xproperty.window, ev.xproperty.atom);
//tray begin *************                
                    if (ev.xproperty.atom == kde_systray_prop) {
                        XSelectInput(dd, t_win, NoEventMask);
                        kde_update_icons();
                        XSelectInput(dd, t_win, StructureNotifyMask);
                    while (XCheckTypedEvent(dd, PropertyNotify, &ev));
                    }

                    break;
                case FocusIn:
                    handle_focusin(ev.xfocus.window);
                    break;
                case ConfigureNotify:
                    if (ev.xany.window != t_win) {
                    /* find the icon it pertains to and beat it into submission */
                        GSList *it;
  
                        for (it = t_icons; it != NULL; it = g_slist_next(it)) {
                            TrayWindow *traywin =(TrayWindow*) it->data;
                            if (traywin->id == ev.xany.window) {
                                XMoveResizeWindow(dd, traywin->id, traywin->x, traywin->y,
                                t_icon_size, t_icon_size);
                            }
                        }
                    }
        
        /* briefly cover the entire containing window, which causes it and
           all of the icons to refresh their windows. finally, they update
           themselves when the background of the main window's parent changes.
        */
                    cover = XCreateSimpleWindow(dd, t_win, 0, 0,
                                    t_border * 2 + t_width, t_border * 2 + t_height,
                                    0, 0, 0);
                    window_set_title (dd, cover,"IconTask",'T'); 
                    XClassHint classhints;
                    classhints.res_name = r_name;
                    classhints.res_class = r_class;
                    XSetClassHint(dd,cover,&classhints);
                    XMapWindow(dd, cover);
                    XDestroyWindow(dd, cover);
        
                    break;

                case ReparentNotify:
                    if (ev.xany.window == t_win) /* reparented to us */
                    break;
                case UnmapNotify:
                case ClientMessage:
                    if (ev.xclient.message_type == net_opcode_atom &&
                        ev.xclient.format == 32 &&
                        ev.xclient.window == net_sel_win)
                    net_message(&ev.xclient);
        
                default:
                    break;
//tray end *************                
            }
        }
        if (s_ch==1)
        {
            gui_draw_taskbar(SIGALRM);
            signal(SIGALRM, gui_draw_taskbar);
            s_ch=0;
        }    
    }

    free(extents);
    XftFontClose(dd, xfs);
    XFree(dd);
}
