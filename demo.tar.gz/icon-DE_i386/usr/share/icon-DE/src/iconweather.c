//g++ -o ./bin/iconweather ./src/iconweather.c -lImlib2  `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <stdlib.h>
#include <X11/Xlib.h>
#include <X11/Xos.h>
#include <glib-2.0/glib.h>

#include "Imlib2.h"

#include "./other_src/ReplaceStr.c"

Display                        *disp;
Window                            win;
Window                            win3[7][4];
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
int i3;
Imlib_Image                 buffer3;
Imlib_Font                    font3;
char c_date[7][30]={"" "" "" "" "" "" ""};
char c_weather[7][30]={"" "" "" "" "" "" ""};
char c_weather2[7][30]={"" "" "" "" "" "" ""};
char c_tem[7][30]={"" "" "" "" "" "" ""};
char c_wind[7][30]={"" "" "" "" "" "" ""};



void showwin3(int screenX,int screenY)
    
{
    int text_w,text_h;
    int ii;
    imlib_context_set_font(font3);
    imlib_context_set_color(0, 0, 0, 255);
    for (ii=0;ii<7;ii++)
    {
        imlib_get_text_size(c_date[ii], &text_w, &text_h);
//        XRaiseWindow(disp,win3[ii][0]);
        imlib_context_set_drawable(win3[ii][0]); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_date[ii], &text_w, &text_h);
        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
        imlib_context_set_image(buffer3);
        imlib_context_set_drawable(win3[ii][0]); 
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_font(font3);
        imlib_context_set_color(0, 0, 0, 255);
        imlib_text_draw(5,2,c_date[ii]);
        imlib_context_set_image(buffer3);
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_weather2[ii], &text_w, &text_h);
//        XRaiseWindow(disp,win3[ii][1]);
        imlib_context_set_drawable(win3[ii][1]); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_weather2[ii], &text_w, &text_h);
        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
        imlib_context_set_image(buffer3);
        imlib_context_set_drawable(win3[ii][1]); 
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_font(font3);
        imlib_context_set_color(0, 0, 0, 255);
        imlib_text_draw(5,2,c_weather2[ii]);
        imlib_context_set_image(buffer3);
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_tem[ii], &text_w, &text_h);
//        XRaiseWindow(disp,win3[ii][2]);
        imlib_context_set_drawable(win3[ii][2]); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_tem[ii], &text_w, &text_h);
        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
        imlib_context_set_image(buffer3);
        imlib_context_set_drawable(win3[ii][2]); 
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_font(font3);
        imlib_context_set_color(0, 0, 0, 255);
        imlib_text_draw(5,2,c_tem[ii]);
        imlib_context_set_image(buffer3);
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_wind[ii], &text_w, &text_h);
//        XRaiseWindow(disp,win3[ii][3]);
        imlib_context_set_drawable(win3[ii][3]); 
        imlib_context_set_image(buffer3);
        imlib_get_text_size(c_wind[ii], &text_w, &text_h);
        imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
        imlib_context_set_image(buffer3);
        imlib_context_set_drawable(win3[ii][3]); 
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_font(font3);
        imlib_context_set_color(0, 0, 0, 255);
        imlib_text_draw(5,2,c_wind[ii]);
        imlib_context_set_image(buffer3);
        imlib_render_image_on_drawable(0, 0); 
        imlib_context_set_image(buffer3);
    }
}


int main(int argc, char **argv)
{
     Imlib_Image                im_bg1[7];
     Imlib_Image                im_bg2[7];
     Imlib_Image                im_bg3[7];
     XEvent                            ev;
     const char                 *display_name = getenv("DISPLAY");
//     Imlib_Font                    font;
//     Imlib_Image                 buffer1;
//     Imlib_Image                 buffer;
     Imlib_Image                 back;
//     Imlib_Image                 bigback;
     Imlib_Color_Range     range;
     int    text_w, text_h;
     int hide=0;
//     Imlib_Image                temp, temp2;

     if (display_name == NULL)
             display_name = ":0";
     disp = XOpenDisplay(display_name);
     if (disp == NULL)
         {
             fprintf(stderr, "Can't open display %s\n", display_name);
             return 1;
         }
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    int scr_w=XDisplayWidth(disp,screen);
    int scr_h=XDisplayHeight(disp,screen);
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=80;
    int screenHeight;
    screenHeight=160;
    int screenX=10;
    int screenY=10;
    char *picname0;
    char picname1[1024];
    char picname2[1024];
    char picname3[7][1024];
    char command[1024]=" ";
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
    char rcfile[60];
    char *url;

    if ( argc != 7 ){
        printf("usage: iconweather x y width height bak_image url\n");
        return 1;
    }

    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    picname0 = argv[5];
    url=argv[6];

    
    sprintf(command,"wget %s -O %s/.icon-DE/weather-icon/TQYB.WML",url,home);
    system(command);
    FILE *freeNum;
    sprintf(rcfile,"%s/.icon-DE/weather-icon/TQYB.WML",home);
    freeNum=fopen(rcfile,"r");
    if ( freeNum==NULL)
    { 
        printf("error on open %s\n",rcfile); 
        exit(1); 
    }
    char buffer_rc[1024];
    int ii=0;
    int i=0;
    while ( ! feof(freeNum) )
    {
        fgets(buffer_rc,1024,freeNum);
        ii=ii+1;
        if (ii==10)
            break;
    }
    fclose(freeNum);
//    printf("%s \n",buffer_rc);
    ReplaceStr(buffer_rc,"<br/><br/><b>","#");
    ReplaceStr(buffer_rc,"</b><br/>","#");
    ReplaceStr(buffer_rc,"<br/>","#");
    ReplaceStr(buffer_rc,"<b>","");
    ii=0;
    i=0;
    while (1)
    {
         while (1)
         {
             sprintf(c_date[ii],"%s%c",c_date[ii],buffer_rc[i]);
             i=i+1;
             if    (buffer_rc[i]=='#')
             {
                 i=i+1;
                 break;
             }    
         }
         while (1)
         {
             sprintf(c_weather[ii],"%s%c",c_weather[ii],buffer_rc[i]);
             sprintf(c_weather2[ii],"%s%c",c_weather2[ii],buffer_rc[i]);
             i=i+1;
             if    (buffer_rc[i]=='#')
             {
                 i=i+1;
                 break;
             }    
         }
         while (1)
         {
             sprintf(c_tem[ii],"%s%c",c_tem[ii],buffer_rc[i]);
             i=i+1;
             if    (buffer_rc[i]=='#')
             {
                 i=i+1;
                 break;
             }    
         }
         while (1)
         {
             sprintf(c_wind[ii],"%s%c",c_wind[ii],buffer_rc[i]);
             i=i+1;
             if    (buffer_rc[i]=='#')
             {
                 i=i+1;
                 break;
             }    
         }
         ii=ii+1;
         if (ii==7) break;
    }

        
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);


    attr.override_redirect=True;
 //win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,CopyFromParent,InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask|CWBorderPixel|CWSaveUnder|CWColormap|CWBackPixel,&attr);
    win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth*7,screenHeight,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
//     win =    XCreateSimpleWindow(disp, DefaultRootWindow(disp), 0, 0, 100, 100, 0, 0, 0);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);

        /**
        * Start rendering
        */
    XLowerWindow(disp,win);
    XMapWindow(disp, win);
    XMoveWindow(disp,win,screenX,screenY);

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);
//--
    int d1;
    int d2;
    back = imlib_load_image(picname0);
    int is;
    int ih;
    imlib_context_set_image(back);
    imlib_render_image_on_drawable_at_size(-screenX, -screenY,scr_w,scr_h);
//    XResizeWindow(disp, win, is, ih);
//    char c_date[7][30];
//    char c_weather[7][30];
//    char c_tem[7][30];
//    char c_wind[7][30];
    char font_path[1024];
    sprintf(font_path,"%s/.icon-DE/fonts",home);
    imlib_add_path_to_font_path(font_path);
    imlib_add_path_to_font_path("/usr/share/fonts/truetype/wqy/");
    imlib_add_path_to_font_path("/usr/share/fonts/wenquanyi/wqy-zenhei/");
    font3 = imlib_load_font("Vera/9");
    if (font3 == NULL)
        font3 = imlib_load_font("wqy-zenhei.ttc/9");
    char icon_dir[256];
    sprintf(icon_dir,"%s/.icon-DE/weather-icon/",home);
    sprintf(picname1,"%sgood_weather.png",icon_dir);
    if (access(picname1,0)==-1)
    {
        system("mkdir ~/.icon-DE/");
        system("mkdir ~/.icon-DE/weather-icon/");
        system("rm -rf ~/.icon-DE/weather-icon/*.png");
        system("cp -a /usr/share/icon-DE//weather-icon/* ~/.icon-DE/weather-icon/");
    }
    if (access(picname1,0)==-1)
        sprintf(icon_dir,"/usr/share/icon-DE/weather-icon/");
    for (ii=0;ii<7;ii++)
    {
//        printf("%s %s %s %s \n",c_date[ii],c_weather[ii],c_tem[ii],c_wind[ii]);
        if (strstr(c_weather[ii],"晴")!=NULL ) 
            sprintf(picname1,"%sgood_weather.png",icon_dir);
        else
            sprintf(picname1,"%sbad_weather.png",icon_dir);
        if (strstr(c_date[ii],"星期六")!=NULL)
            sprintf(picname1,"%ssaturday.png",icon_dir);
        if (strstr(c_date[ii],"星期日")!=NULL)
            sprintf(picname1,"%ssunday.png",icon_dir);
        
        im_bg1[ii] = imlib_load_image(picname1);
        imlib_context_set_image(im_bg1[ii]);
        is=imlib_image_get_width();
        ih=imlib_image_get_height();
        d1=screenWidth-is;
        d1=d1/2;
        d2=screenHeight-ih;
        d2=d2/2;
        imlib_context_set_blend(1);
        imlib_context_set_image(im_bg1[ii]);
        imlib_render_image_on_drawable_at_size(d1+screenWidth*ii, d2,is,ih );
//        imlib_render_image_on_drawable(d1+screenWidth*ii,d2);


         if (strstr(c_weather[ii],"转中雨")!=NULL)
         {
             sprintf(picname3[ii],"%szhongyu.png",icon_dir);
             ReplaceStr(c_weather[ii],"转中雨","");
         } else if (strstr(c_weather[ii],"转中雪")!=NULL)
         {
             sprintf(picname3[ii],"%szhongxue.png",icon_dir);
             ReplaceStr(c_weather[ii],"转中雪","");
         } else if (strstr(c_weather[ii],"转晴")!=NULL)
         {
             sprintf(picname3[ii],"%sqing.png",icon_dir);
             ReplaceStr(c_weather[ii],"转晴","");
         } else if (strstr(c_weather[ii],"转多云")!=NULL)
         {
             sprintf(picname3[ii],"%sduoyun.png",icon_dir);
             ReplaceStr(c_weather[ii],"转多云","");
         } else if (strstr(c_weather[ii],"转大雨")!=NULL)
         {
             sprintf(picname3[ii],"%sdayu.png",icon_dir);
             ReplaceStr(c_weather[ii],"转大雨","");
         } else if (strstr(c_weather[ii],"转大雪")!=NULL)
         {
             sprintf(picname3[ii],"%sdaxue.png",icon_dir);
             ReplaceStr(c_weather[ii],"转大雪","");
         } else if (strstr(c_weather[ii],"转小雨")!=NULL)
         {
             sprintf(picname3[ii],"%sxiaoyu.png",icon_dir);
             ReplaceStr(c_weather[ii],"转小雨","");
         } else if (strstr(c_weather[ii],"转小雪")!=NULL)
         {
             sprintf(picname3[ii],"%sxiaoxue.png",icon_dir);
             ReplaceStr(c_weather[ii],"转小雪","");
         } else if (strstr(c_weather[ii],"转暴雨")!=NULL)
         {
             sprintf(picname3[ii],"%sbaoyu.png",icon_dir);
             ReplaceStr(c_weather[ii],"转暴雨","");
         } else if (strstr(c_weather[ii],"转暴雪")!=NULL)
         {
             sprintf(picname3[ii],"%sbaoxue.png",icon_dir);
             ReplaceStr(c_weather[ii],"转暴雪","");
         } else if (strstr(c_weather[ii],"转阴")!=NULL)
         {
             sprintf(picname3[ii],"%syin.png",icon_dir);
             ReplaceStr(c_weather[ii],"转阴","");
         } else if (strstr(c_weather[ii],"转雨夹雪")!=NULL)
         {
             sprintf(picname3[ii],"%syujiaxue.png",icon_dir);
             ReplaceStr(c_weather[ii],"转雨夹雪","");
         } else if (strstr(c_weather[ii],"转雷阵雨")!=NULL)
         {
             sprintf(picname3[ii],"%sleizhenyu.png",icon_dir);
             ReplaceStr(c_weather[ii],"转雷阵雨","");
         } else
             sprintf(picname3[ii],"N/A");

//             printf(" %s\n",picname3[ii]);

         if (strcmp(c_weather[ii],"中雨")==0)
             sprintf(picname2,"%szhongyu.png",icon_dir);
         else if (strcmp(c_weather[ii],"中雪")==0)
             sprintf(picname2,"%szhongxue.png",icon_dir);
         else if (strcmp(c_weather[ii],"晴")==0)
             sprintf(picname2,"%sqing.png",icon_dir);
         else if (strcmp(c_weather[ii],"多云")==0)
             sprintf(picname2,"%sduoyun.png",icon_dir);
         else if (strcmp(c_weather[ii],"大雨")==0)
             sprintf(picname2,"%sdayu.png",icon_dir);
         else if (strcmp(c_weather[ii],"大雪")==0)
             sprintf(picname2,"%sdaxue.png",icon_dir);
         else if (strcmp(c_weather[ii],"小雨")==0)
             sprintf(picname2,"%sxiaoyu.png",icon_dir);
         else if (strcmp(c_weather[ii],"小雪")==0)
             sprintf(picname2,"%sxiaoxue.png",icon_dir);
         else if (strcmp(c_weather[ii],"暴雨")==0)
             sprintf(picname2,"%sbaoyu.png",icon_dir);
         else if (strcmp(c_weather[ii],"暴雪")==0)
             sprintf(picname2,"%sbaoxue.png",icon_dir);
         else if (strcmp(c_weather[ii],"阴")==0)
             sprintf(picname2,"%syin.png",icon_dir);
         else if (strcmp(c_weather[ii],"雨夹雪")==0)
             sprintf(picname2,"%syujiaxue.png",icon_dir);
         else if (strcmp(c_weather[ii],"雷阵雨")==0)
             sprintf(picname2,"%sleizhenyu.png",icon_dir);
         else    
             sprintf(picname2,"%sother.png",icon_dir);
        im_bg2[ii] = imlib_load_image(picname2);

//        printf("%s\n",picname2);
             
        imlib_context_set_image(im_bg2[ii]);
        is=imlib_image_get_width()/2;
        ih=imlib_image_get_height()/2;
        d1=screenWidth-is;
        d1=d1/2;
        d2=screenHeight-ih;
        d2=d2/2;
        imlib_context_set_blend(1);
        imlib_context_set_image(im_bg2[ii]);

        if (strstr(picname3[ii],"N/A")==0)
        {
            im_bg3[ii] = imlib_load_image(picname3[ii]);
            imlib_render_image_on_drawable_at_size(d1-20+screenWidth*ii, d2-8,is,ih);
//            imlib_render_image_on_drawable(d1-20+screenWidth*ii,d2-8);

            imlib_context_set_image(im_bg3[ii]);
            imlib_context_set_blend(1);
            imlib_render_image_on_drawable_at_size(d1+20+screenWidth*ii, d2+8,is,ih);
//            imlib_context_set_image(im_bg3[ii]);
//            imlib_render_image_on_drawable(d1+20+screenWidth*ii,d2+8);
        } else {
            imlib_render_image_on_drawable_at_size(d1+screenWidth*ii, d2,is,ih);
//            imlib_render_image_on_drawable(d1+screenWidth*ii,d2);
        }

        XSync(disp, False);

        imlib_context_set_font(font3);
        imlib_context_set_color(0, 0, 0, 255);
//    if (i3==1)
//    {
//        strftime(text, sizeof(text), "%H:%M",localtime(&now_time) );
//        i3=0;
//    } else {
//        strftime(text, sizeof(text), "%H %M",localtime(&now_time) );
//        i3=1;
//    }
        imlib_get_text_size(c_date[ii], &text_w, &text_h);
        win3[ii][0]=XCreateWindow(disp,win,screenWidth*ii,0,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
        XSelectInput(disp, win3[ii][0], ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
//    imlib_free_font();

        imlib_get_text_size(c_weather2[ii], &text_w, &text_h);
        win3[ii][1]=XCreateWindow(disp,win,screenWidth*ii,text_h+2,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
        XSelectInput(disp, win3[ii][1], ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);

        imlib_get_text_size(c_tem[ii], &text_w, &text_h);
        win3[ii][2]=XCreateWindow(disp,win,screenWidth*ii,text_h*2+4,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
        XSelectInput(disp, win3[ii][2], ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);

        imlib_get_text_size(c_wind[ii], &text_w, &text_h);
        win3[ii][3]=XCreateWindow(disp,win,screenWidth*ii,text_h*3+6,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
        XSelectInput(disp, win3[ii][3], ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
        XMapWindow(disp, win3[ii][0]);
        XMapWindow(disp, win3[ii][1]);
        XMapWindow(disp, win3[ii][2]);
        XMapWindow(disp, win3[ii][3]);

    }
    buffer3 = imlib_create_image(1200, 100);    
    showwin3(0,0);

//    XRaiseWindow(disp,win);
    
//    buffer=imlib_create_image_from_drawable( win,0,0,screenWidth*7,screenHeight,1);

    
 
    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    long ticks;

//    time_t now_time;
    struct timeval now, tm,LastTime;
//    now_time=time(0);
    
    gettimeofday(&LastTime, 0);
    
    int s_ch=0;
    while (1)
    {
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case Expose:
                s_ch=1;
                break;
            case MotionNotify:
                break;
            default:
                break;
            case EnterNotify:		
                if (hide==1)
                {
                    XMoveResizeWindow(disp, win, screenX, screenY, screenWidth*7, screenHeight);
                    XRaiseWindow(disp,win);
                    hide=0;
                }    
                break;
            case LeaveNotify:		
                break;
            case ButtonPress:				
                if(ev.xbutton.button==1)
                {
                    break;
                }
                if(ev.xbutton.button==2)
                {
                    break;
                }
                if(ev.xbutton.button==3)
                {
                    break;
                }
                if(ev.xbutton.button==4)
                {
                        break;
                }
                if(ev.xbutton.button==5)
                {
                    break;
                }    
            }
        } else {
                //display 是由 XopenDisplay 返回的 Display *
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
            if (s_ch==1)
            {
                imlib_context_set_drawable(win);
                imlib_context_set_image(back);
                imlib_render_image_on_drawable_at_size(-screenX, -screenY,scr_w,scr_h);
                for (ii=0;ii<7;ii++)
                {
                    imlib_context_set_image(im_bg1[ii]);
                    is=imlib_image_get_width();
                    ih=imlib_image_get_height();
                    d1=screenWidth-is;
                    d1=d1/2;
                    d2=screenHeight-ih;
                    d2=d2/2;
                    imlib_context_set_blend(1);
                    imlib_context_set_image(im_bg1[ii]);
                    imlib_render_image_on_drawable_at_size(d1+screenWidth*ii, d2,is,ih);
//                    imlib_render_image_on_drawable(d1+screenWidth*ii,d2);

                    imlib_context_set_image(im_bg2[ii]);
                    is=imlib_image_get_width()/2;
                    ih=imlib_image_get_height()/2;
                    d1=screenWidth-is;
                    d1=d1/2;
                    d2=screenHeight-ih;
                    d2=d2/2;
                    imlib_context_set_blend(1);
                    imlib_context_set_image(im_bg2[ii]);

                    if (strstr(picname3[ii],"N/A")==0)
                    {
                        imlib_render_image_on_drawable_at_size(d1-20+screenWidth*ii, d2-8,is,ih);
                        imlib_context_set_image(im_bg3[ii]);
                        imlib_context_set_blend(1);
                        imlib_context_set_image(im_bg3[ii]);
                        imlib_render_image_on_drawable_at_size(d1+20+screenWidth*ii, d2+8,is,ih);
                    } else {
                        imlib_render_image_on_drawable_at_size(d1+screenWidth*ii, d2,is,ih);
                    }
                }
                s_ch=0;
                XLowerWindow(disp,win);
                XSync(disp, False);
                showwin3(0,0);
            }

//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=10000)
            {
                gettimeofday(&LastTime, 0);
                hide=1;
                XMoveResizeWindow(disp, win, 0, 0, 10, 10);
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=100000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        } /* End else*/
    }
    return 0;
}


