// g++ -o ./bin/icon-desk ./src/icon-desk.c `pkg-config --cflags --libs glib-2.0` -lX11 -lImlib2 -lXcomposite -lXdamage -lXfixes -lXrender
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <string.h>
#include <errno.h>
#include <X11/Xatom.h>
#include <X11/Xresource.h>
#include <X11/extensions/Xcomposite.h>
#include <X11/extensions/Xdamage.h>
#include <X11/extensions/Xrender.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/poll.h>
#include <sys/stat.h>
#include <glib-2.0/glib.h>
#include "Imlib2.h"

Display *disp;
Screen *scr = NULL;
Atom wmDeleteWindow;
XContext xid_context = 0;
Window root = 0;
Window                            win;
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
int have_error=0;


#define emalloc(a) malloc(a)
#define estrdup(a) strdup(a)
#define erealloc(a,b) realloc(a,b)
#define D(a)


void
gib_imlib_save_image(Imlib_Image im, char *file)
{
   imlib_context_set_image(im);
   imlib_save_image(file);
}

int
gib_imlib_image_get_width(Imlib_Image im)
{
   imlib_context_set_image(im);
   return imlib_image_get_width();
}

int
gib_imlib_image_get_height(Imlib_Image im)
{
   imlib_context_set_image(im);
   return imlib_image_get_height();
}


void
gib_imlib_render_image_part_on_drawable_at_size(Drawable d, Imlib_Image im,
                                                int sx, int sy, int sw,
                                                int sh, int dx, int dy,
                                                int dw, int dh, char dither,
                                                char blend, char alias)
{
   imlib_context_set_image(im);
   imlib_context_set_drawable(d);
   imlib_context_set_anti_alias(alias);
   imlib_context_set_dither(dither);
   imlib_context_set_blend(blend);
   imlib_context_set_angle(0);
   imlib_render_image_part_on_drawable_at_size(sx, sy, sw, sh, dx, dy, dw,
                                               dh);
}


void
gib_imlib_render_image_on_drawable_at_size(Drawable d, Imlib_Image im, int x,
                                           int y, int w, int h, char dither,
                                           char blend, char alias)
{
   imlib_context_set_image(im);
   imlib_context_set_drawable(d);
   imlib_context_set_anti_alias(alias);
   imlib_context_set_dither(dither);
   imlib_context_set_blend(blend);
   imlib_context_set_angle(0);
   imlib_render_image_on_drawable_at_size(x, y, w, h);
}

void
gib_imlib_render_image_on_drawable(Drawable d, Imlib_Image im, int x, int y,
                                   char dither, char blend, char alias)
{
   imlib_context_set_image(im);
   imlib_context_set_drawable(d);
   imlib_context_set_anti_alias(alias);
   imlib_context_set_dither(dither);
   imlib_context_set_blend(blend);
   imlib_context_set_angle(0);
   imlib_render_image_on_drawable(x, y);
}

/* eprintf: print error message and exit */
void eprintf(const char *fmt, ...)
{
    va_list args;

    fflush(stdout);
    fputs(" ERROR: ", stderr);

    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);

    if (fmt[0] != '\0' && fmt[strlen(fmt) - 1] == ':')
        fprintf(stderr, " %s", strerror(errno));
    fputs("\n", stderr);
    exit(2);
}

/* weprintf: print warning message and continue */
void weprintf(const char *fmt, ...)
{
    va_list args;

    fflush(stdout);
    fputs(" WARNING: ", stderr);

    va_start(args, fmt);
    vfprintf(stderr, fmt, args);
    va_end(args);

    if (fmt[0] != '\0' && fmt[strlen(fmt) - 1] == ':')
        fprintf(stderr, " %s", strerror(errno));
    fputs("\n", stderr);
}

/* estrdup: duplicate a string, report if error */
char *_estrdup(const char *s)
{
    char *t;

    if (!s)
        return NULL;

    t = (char *) malloc(strlen(s) + 1);
    if (t == NULL)
        eprintf("estrdup(\"%.20s\") failed:", s);
    strcpy(t, s);
    return t;
}

/* emalloc: malloc and report if error */
void *_emalloc(size_t n)
{
    void *p;

    p = malloc(n);
    if (p == NULL)
        eprintf("malloc of %u bytes failed:", n);
    return p;
}

/* erealloc: realloc and report if error */
void *_erealloc(void *ptr, size_t n)
{
    void *p;

    p = realloc(ptr, n);
    if (p == NULL)
        eprintf("realloc of %p by %u bytes failed:", ptr, n);
    return p;
}

char *estrjoin(const char *separator, ...)
{
    char *string, *s;
    va_list args;
    int len;
    int separator_len;

    if (separator == NULL)
        separator = "";

    separator_len = strlen(separator);
    va_start(args, separator);
    s = va_arg(args, char *);

    if (s) {
        len = strlen(s);
        s = va_arg(args, char *);

        while (s) {
            len += separator_len + strlen(s);
            s = va_arg(args, char *);
        }
        va_end(args);
        string = (char*)malloc(sizeof(char) * (len + 1));

        *string = 0;
        va_start(args, separator);
        s = va_arg(args, char *);

        strcat(string, s);
        s = va_arg(args, char *);

        while (s) {
            strcat(string, separator);
            strcat(string, s);
            s = va_arg(args, char *);
        }
    } else
        string = estrdup("");
    va_end(args);

    return string;
}

/* free the result please */
char *feh_unique_filename(const char *path,const  char *basename)
{
    char *tmpname;
    char num[10];
    char cppid[10];
    static long int i = 1;
    struct stat st;
    pid_t ppid;

    /* Massive paranoia ;) */
    if (i > 999998)
        i = 1;

    ppid = getpid();
    snprintf(cppid, sizeof(cppid), "%06ld", (long) ppid);

    /* make sure file doesn't exist */
    do {
        snprintf(num, sizeof(num), "%06ld", i++);
        tmpname = estrjoin("", path, "feh_", cppid, "_", num, "_", basename, NULL);
    }
    while (stat(tmpname, &st) == 0);
    return(tmpname);
}

/* reads file into a string, but limits o 4095 chars and ensures a \0 */
char *ereadfile(const char *path)
{
    char buffer[4096];
    FILE *fp;
    int count;

    fp = fopen(path, "r");
    if (!fp)
        return NULL;

    count = fread(buffer, sizeof(char), sizeof(buffer) - 1, fp);
    if (buffer[count - 1] == '\n')
        buffer[count - 1] = '\0';
    else
        buffer[count] = '\0';

    fclose(fp);

    return estrdup(buffer);
}


#define WALLPAPER_H


#define IPC_TIMEOUT    ((char *) 1)
#define IPC_FAKE       ((char *) 2)    /* Faked IPC */

#define enl_ipc_sync()  do {                                           \
       char *reply = enl_send_and_wait("nop");                         \
       if ((reply != IPC_FAKE) && (reply != IPC_TIMEOUT))              \
         free(reply);                                                  \
   } while (0)

Window enl_ipc_get_win(void);
void enl_ipc_send(const char *);
char *enl_wait_for_reply(void);
char *enl_ipc_get(const char *);
char *enl_send_and_wait(const char *);
void feh_wm_set_bg(const char *fil, Imlib_Image im, int centered, int scaled,
        int fill, int desktop);
int feh_wm_get_num_desks(void);
signed char feh_wm_get_wm_is_e(void);

Window ipc_win = None;
Window my_ipc_win = None;
Atom ipc_atom = None;
static unsigned char timeout = 0;

static char e17_fake_ipc = 0;
static void feh_wm_set_bg_scaled(Pixmap pmap, Imlib_Image im,
        int x, int y, int w, int h)
{
    gib_imlib_render_image_on_drawable_at_size(pmap, im, x, y, w, h,
            1, 0, 1);
    return;
}

static void feh_wm_set_bg_centered(Pixmap pmap, Imlib_Image im,
        int x, int y, int w, int h)
{
    int offset_x, offset_y;
    offset_x = (w - gib_imlib_image_get_width(im)) >> 1;
    offset_y = (h - gib_imlib_image_get_height(im)) >> 1;

    gib_imlib_render_image_part_on_drawable_at_size(pmap, im,
        ((offset_x < 0) ? -offset_x : 0),
        ((offset_y < 0) ? -offset_y : 0),
        w,
        h,
        x + ((offset_x > 0) ? offset_x : 0),
        y + ((offset_y > 0) ? offset_y : 0),
        w,
        h,
        1, 0, 0);
    return;
}

static void feh_wm_set_bg_filled(Pixmap pmap, Imlib_Image im,
        int x, int y, int w, int h)
{
    int img_w, img_h, cut_x;
    int render_w, render_h, render_x, render_y;
    img_w = gib_imlib_image_get_width(im);
    img_h = gib_imlib_image_get_height(im);

    cut_x = (((img_w * h) > (img_h * w)) ? 1 : 0);

    render_w = (  cut_x ? ((img_h * w) / h) : img_w);
    render_h = ( !cut_x ? ((img_w * h) / w) : img_h);

    render_x = (  cut_x ? ((img_w - render_w) >> 1) : 0);
    render_y = ( !cut_x ? ((img_h - render_h) >> 1) : 0);

    gib_imlib_render_image_part_on_drawable_at_size(pmap, im,
        render_x, render_y,
        render_w, render_h,
        x, y, w, h,
        1, 0, 1);
    return;
}

static void feh_wm_set_bg_maxed(Pixmap pmap, Imlib_Image im,
        int x, int y, int w, int h)
{
    int img_w, img_h, border_x;
    int render_w, render_h, render_x, render_y;
    img_w = gib_imlib_image_get_width(im);
    img_h = gib_imlib_image_get_height(im);

    border_x = (((img_w * h) > (img_h * w)) ? 0 : 1);

    render_w = (  border_x ? ((img_w * h) / img_h) : w);
    render_h = ( !border_x ? ((img_h * w) / img_w) : h);

    render_x = x + (  border_x ? ((w - render_w) >> 1) : 0);
    render_y = y + ( !border_x ? ((h - render_h) >> 1) : 0);

    gib_imlib_render_image_on_drawable_at_size(pmap, im,
        render_x, render_y,
        render_w, render_h,
        1, 0, 1);
    return;
}

void feh_wm_set_bg(const char *fil, Imlib_Image im, int centered, int scaled,
        int filled, int desktop)
{
    char bgname[20];
    int num = (int) rand();
    char bgfil[4096];
    char sendbuf[4096];

    snprintf(bgname, sizeof(bgname), "FEHBG_%d", num);

    if (!fil && im) {
        snprintf(bgfil, sizeof(bgfil), "%s/.%s.png", getenv("HOME"), bgname);
        imlib_context_set_image(im);
        imlib_image_set_format("png");
        gib_imlib_save_image(im, bgfil);
        D(("bg saved as %s\n", bgfil));
        fil = bgfil;
    }

    if (feh_wm_get_wm_is_e() && (enl_ipc_get_win() != None)) {
        snprintf(sendbuf, sizeof(sendbuf), "background %s bg.file %s", bgname, fil);
        enl_ipc_send(sendbuf);

        if (scaled) {
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.solid 0 0 0", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.tile 0", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.xjust 512", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.yjust 512", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.xperc 1024", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.yperc 1024", bgname);
            enl_ipc_send(sendbuf);
        } else if (centered) {
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.solid 0 0 0", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.tile 0", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.xjust 512", bgname);
            enl_ipc_send(sendbuf);
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.yjust 512", bgname);
            enl_ipc_send(sendbuf);
        } else {
            snprintf(sendbuf, sizeof(sendbuf), "background %s bg.tile 1", bgname);
            enl_ipc_send(sendbuf);
        }

        snprintf(sendbuf, sizeof(sendbuf), "use_bg %s %d", bgname, desktop);
        enl_ipc_send(sendbuf);
        enl_ipc_sync();
    } else {
        Atom prop_root, prop_esetroot, type;
        int format;
        unsigned long length, after;
        unsigned char *data_root, *data_esetroot;
        Pixmap pmap_d1, pmap_d2;
        char *fehbg = NULL;
        char *home;
        char filbuf[4096];
        char fehbg_xinerama[] = "--no-xinerama";

        /* local display to set closedownmode on */
        Display *disp2;
        Window root2;
        int depth2;
        XGCValues gcvalues;
        GC gc;
        int in, out, w, h;

        fehbg_xinerama[0] = '\0';

        D(("Falling back to XSetRootWindowPixmap\n"));

        /* Put the filename in filbuf between ' and escape ' in the filename */
        out = 0;

        if (fil ) {
            filbuf[out++] = '\'';

            for (in = 0; fil[in] && out < 4092; in++) {

                if (fil[in] == '\'')
                    filbuf[out++] = '\\';
                filbuf[out++] = fil[in];
            }
            filbuf[out++] = '\'';

        } 


        filbuf[out++] = 0;

        if (scaled) {
            pmap_d1 = XCreatePixmap(disp, root, scr->width, scr->height, depth);

#ifdef HAVE_LIBXINERAMA
            if ( xinerama_screens)
                for (i = 0; i < num_xinerama_screens; i++)
                    feh_wm_set_bg_scaled(pmap_d1, im, use_filelist,
                        xinerama_screens[i].x_org, xinerama_screens[i].y_org,
                        xinerama_screens[i].width, xinerama_screens[i].height);
            else
#endif            /* HAVE_LIBXINERAMA */
                feh_wm_set_bg_scaled(pmap_d1, im,
                    0, 0, scr->width, scr->height);
            fehbg = estrjoin(" ", "feh", fehbg_xinerama, "--bg-scale", filbuf, NULL);
        } else if (centered) {
            XGCValues gcval;
            GC gc;

            D(("centering\n"));

            pmap_d1 = XCreatePixmap(disp, root, scr->width, scr->height, depth);
            gcval.foreground = BlackPixel(disp, DefaultScreen(disp));
            gc = XCreateGC(disp, root, GCForeground, &gcval);
            XFillRectangle(disp, pmap_d1, gc, 0, 0, scr->width, scr->height);

#ifdef HAVE_LIBXINERAMA
            if ( xinerama_screens)
                for (i = 0; i < num_xinerama_screens; i++)
                    feh_wm_set_bg_centered(pmap_d1, im, use_filelist,
                        xinerama_screens[i].x_org, xinerama_screens[i].y_org,
                        xinerama_screens[i].width, xinerama_screens[i].height);
            else
#endif                /* HAVE_LIBXINERAMA */
                feh_wm_set_bg_centered(pmap_d1, im,
                    0, 0, scr->width, scr->height);

            XFreeGC(disp, gc);

            fehbg = estrjoin(" ", "feh", fehbg_xinerama, "--bg-center", filbuf, NULL);

        } else if (filled == 1) {

            pmap_d1 = XCreatePixmap(disp, root, scr->width, scr->height, depth);

#ifdef HAVE_LIBXINERAMA
            if (xinerama_screens)
                for (i = 0; i < num_xinerama_screens; i++)
                    feh_wm_set_bg_filled(pmap_d1, im, use_filelist,
                        xinerama_screens[i].x_org, xinerama_screens[i].y_org,
                        xinerama_screens[i].width, xinerama_screens[i].height);
            else
#endif                /* HAVE_LIBXINERAMA */
                feh_wm_set_bg_filled(pmap_d1, im
                    , 0, 0, scr->width, scr->height);

            fehbg = estrjoin(" ", "feh", fehbg_xinerama, "--bg-fill", filbuf, NULL);

        } else if (filled == 2) {
            XGCValues gcval;

            pmap_d1 = XCreatePixmap(disp, root, scr->width, scr->height, depth);
            gcval.foreground = BlackPixel(disp, DefaultScreen(disp));
            gc = XCreateGC(disp, root, GCForeground, &gcval);
            XFillRectangle(disp, pmap_d1, gc, 0, 0, scr->width, scr->height);

#ifdef HAVE_LIBXINERAMA
            if ( xinerama_screens)
                for (i = 0; i < num_xinerama_screens; i++)
                    feh_wm_set_bg_maxed(pmap_d1, im, use_filelist,
                        xinerama_screens[i].x_org, xinerama_screens[i].y_org,
                        xinerama_screens[i].width, xinerama_screens[i].height);
            else
#endif                /* HAVE_LIBXINERAMA */
                feh_wm_set_bg_maxed(pmap_d1, im,
                    0, 0, scr->width, scr->height);

            XFreeGC(disp, gc);

            fehbg = estrjoin(" ", "feh", fehbg_xinerama, "--bg-max", filbuf, NULL);

        } else {
//            if (use_filelist)
//                feh_wm_load_next(&im);
            w = gib_imlib_image_get_width(im);
            h = gib_imlib_image_get_height(im);
            pmap_d1 = XCreatePixmap(disp, root, w, h, depth);
            gib_imlib_render_image_on_drawable(pmap_d1, im, 0, 0, 1, 0, 0);
            fehbg = estrjoin(" ", "feh --bg-tile", filbuf, NULL);
        }

        if (fehbg ) {
            home = getenv("HOME");
            if (home) {
                FILE *fp;
                char *path;
                path = estrjoin("/", home, ".fehbg", NULL);
                if ((fp = fopen(path, "w")) == NULL) {
                    weprintf("Can't write to %s", path);
                } else {
                    fprintf(fp, "%s\n", fehbg);
                    fclose(fp);
                }
                free(path);
            }
            free(fehbg);
        }

        /* create new display, copy pixmap to new display */
        disp2 = XOpenDisplay(NULL);
        if (!disp2)
            eprintf("Can't reopen X display.");
        root2 = RootWindow(disp2, DefaultScreen(disp2));
        depth2 = DefaultDepth(disp2, DefaultScreen(disp2));
        XSync(disp, False);
        pmap_d2 = XCreatePixmap(disp2, root2, scr->width, scr->height, depth2);
        gcvalues.fill_style = FillTiled;
        gcvalues.tile = pmap_d1;
        gc = XCreateGC(disp2, pmap_d2, GCFillStyle | GCTile, &gcvalues);
        XFillRectangle(disp2, pmap_d2, gc, 0, 0, scr->width, scr->height);
        XFreeGC(disp2, gc);
        XSync(disp2, False);
        XSync(disp, False);
        XFreePixmap(disp, pmap_d1);

        prop_root = XInternAtom(disp2, "_XROOTPMAP_ID", True);
        prop_esetroot = XInternAtom(disp2, "ESETROOT_PMAP_ID", True);

        if (prop_root != None && prop_esetroot != None) {
            XGetWindowProperty(disp2, root2, prop_root, 0L, 1L,
                       False, AnyPropertyType, &type, &format, &length, &after, &data_root);
            if (type == XA_PIXMAP) {
                XGetWindowProperty(disp2, root2,
                           prop_esetroot, 0L, 1L,
                           False, AnyPropertyType,
                           &type, &format, &length, &after, &data_esetroot);
                if (data_root && data_esetroot) {
                    if (type == XA_PIXMAP && *((Pixmap *) data_root) == *((Pixmap *) data_esetroot)) {
                        XKillClient(disp2, *((Pixmap *)
                                     data_root));
                    }
                }
            }
        }
        /* This will locate the property, creating it if it doesn't exist */
        prop_root = XInternAtom(disp2, "_XROOTPMAP_ID", False);
        prop_esetroot = XInternAtom(disp2, "ESETROOT_PMAP_ID", False);

        if (prop_root == None || prop_esetroot == None)
            eprintf("creation of pixmap property failed.");

        XChangeProperty(disp2, root2, prop_root, XA_PIXMAP, 32, PropModeReplace, (unsigned char *) &pmap_d2, 1);
        XChangeProperty(disp2, root2, prop_esetroot, XA_PIXMAP, 32,
                PropModeReplace, (unsigned char *) &pmap_d2, 1);

        XSetWindowBackgroundPixmap(disp2, root2, pmap_d2);
        XClearWindow(disp2, root2);
        XFlush(disp2);
        XSetCloseDownMode(disp2, RetainPermanent);
        XCloseDisplay(disp2);
    }
    return;
}

signed char feh_wm_get_wm_is_e(void)
{
    static signed char e = -1;

    /* check if E is actually running */
    if (e == -1) {
        /* XXX: This only covers E17 prior to 6/22/05 */
        if ((XInternAtom(disp, "ENLIGHTENMENT_COMMS", True) != None)
            && (XInternAtom(disp, "ENLIGHTENMENT_VERSION", True) != None)) {
            D(("Enlightenment detected.\n"));
            e = 1;
        } else {
            D(("Enlightenment not detected.\n"));
            e = 0;
        }
    }
    return(e);
}

Window enl_ipc_get_win(void)
{

    unsigned char *str = NULL;
    Atom prop, prop2, ever;
    unsigned long num, after;
    int format;
    Window dummy_win;
    int dummy_int;
    unsigned int dummy_uint;

    D(("Searching for IPC window.\n"));

    /*
     * Shortcircuit this entire func
     * if we already know it's an e17 fake
     */
    if (e17_fake_ipc)
        return(ipc_win);

            prop = XInternAtom(disp, "ENLIGHTENMENT_COMMS", True);
    if (prop == None) {
        D(("Enlightenment is not running.\n"));
        return(None);
    } else {
        /* XXX: This will only work with E17 prior to 6/22/2005 */
        ever = XInternAtom(disp, "ENLIGHTENMENT_VERSION", True);
        if (ever == None) {
            /* This is an E without ENLIGHTENMENT_VERSION */
            D(("E16 IPC Protocol not supported"));
            return(None);
        }
    }
    XGetWindowProperty(disp, root, prop, 0, 14, False, AnyPropertyType, &prop2, &format, &num, &after, &str);
    if (str) {
        sscanf((char *) str, "%*s %x", (unsigned int *) &ipc_win);
        XFree(str);
    }
    if (ipc_win != None) {
        if (!XGetGeometry
            (disp, ipc_win, &dummy_win, &dummy_int, &dummy_int,
             &dummy_uint, &dummy_uint, &dummy_uint, &dummy_uint)) {
            D((" -> IPC Window property is valid, but the window doesn't exist.\n"));
            ipc_win = None;
        }
        str = NULL;
        if (ipc_win != None) {
            XGetWindowProperty(disp, ipc_win, prop, 0, 14,
                       False, AnyPropertyType, &prop2, &format, &num, &after, &str);
            if (str) {
                XFree(str);
            } else {
                D((" -> IPC Window lacks the proper atom.  I can't talk to fake IPC windows....\n"));
                ipc_win = None;
            }
        }
    }
    if (ipc_win != None) {

        XGetWindowProperty(disp, ipc_win, ever, 0, 14, False,
                   AnyPropertyType, &prop2, &format, &num, &after, &str);
        if (str) {
            /*
             * This is E17's way of telling us it's only pretending
             * as a workaround for a bug related to the way java handles
             * Window Managers.
             * (Only valid after date of this comment)
             * -- richlowe 2005-06-22
             */
            XFree(str);
            D((" -> Found a fake E17 IPC window, ignoring"));
            ipc_win = None;
            e17_fake_ipc = 1;
            return(ipc_win);
        }

        D((" -> IPC Window found and verified as 0x%08x.  Registering feh as an IPC client.\n", (int) ipc_win));
        XSelectInput(disp, ipc_win, StructureNotifyMask | SubstructureNotifyMask);
        enl_ipc_send("set clientname ");
        enl_ipc_send("set version ");
        enl_ipc_send("set email tom@linuxbrit.co.uk");
        enl_ipc_send("set web http://www.linuxbrit.co.uk");
        enl_ipc_send("set info Feh - be pr0n or be dead");
    }
    if (my_ipc_win == None) {
        my_ipc_win = XCreateSimpleWindow(disp, root, -2, -2, 1, 1, 0, 0, 0);
    }
    return(ipc_win);
}

void enl_ipc_send(const char *str)
{

    static char *last_msg = NULL;
    char buff[21];
    register unsigned short i;
    register unsigned char j;
    unsigned short len;
    XEvent ev;

    if (str == NULL) {
        if (last_msg == NULL)
            eprintf("eeek");
        str = last_msg;
        D(("Resending last message \"%s\" to Enlightenment.\n", str));
    } else {
        if (last_msg != NULL) {
            free(last_msg);
        }
        last_msg = estrdup(str);
        D(("Sending \"%s\" to Enlightenment.\n", str));
    }
    if (ipc_win == None) {
        if ((ipc_win = enl_ipc_get_win()) == None) {
            D(("Hrm. Enlightenment doesn't seem to be running. No IPC window, no IPC.\n"));
            return;
        }
    }
    len = strlen(str);
    ipc_atom = XInternAtom(disp, "ENL_MSG", False);
    if (ipc_atom == None) {
        D(("IPC error:  Unable to find/create ENL_MSG atom.\n"));
        return;
    }
    for (; XCheckTypedWindowEvent(disp, my_ipc_win, ClientMessage, &ev););    /* Discard any out-of-sync messages */
    ev.xclient.type = ClientMessage;
    ev.xclient.serial = 0;
    ev.xclient.send_event = True;
    ev.xclient.window = ipc_win;
    ev.xclient.message_type = ipc_atom;
    ev.xclient.format = 8;

    for (i = 0; i < len + 1; i += 12) {
        sprintf(buff, "%8x", (int) my_ipc_win);
        for (j = 0; j < 12; j++) {
            buff[8 + j] = str[i + j];
            if (!str[i + j]) {
                break;
            }
        }
        buff[20] = 0;
        for (j = 0; j < 20; j++) {
            ev.xclient.data.b[j] = buff[j];
        }
        XSendEvent(disp, ipc_win, False, 0, (XEvent *) & ev);
    }
    return;
}

static sighandler_t *enl_ipc_timeout(sighandler_t sig)
{
    timeout = 1;
    return((sighandler_t *) sig);
    sig = 0;
}

char *enl_wait_for_reply(void)
{

    XEvent ev;
    static char msg_buffer[20];
    register unsigned char i;

    alarm(2);
    for (; !XCheckTypedWindowEvent(disp, my_ipc_win, ClientMessage, &ev)
         && !timeout;);
    alarm(0);
    if (ev.xany.type != ClientMessage) {
        return(IPC_TIMEOUT);
    }
    for (i = 0; i < 20; i++) {
        msg_buffer[i] = ev.xclient.data.b[i];
    }
    return(msg_buffer + 8);
}

char *enl_ipc_get(const char *msg_data)
{

    static char *message = NULL;
    static unsigned short len = 0;
    char buff[13], *ret_msg = NULL;
    register unsigned char i;
    unsigned char blen;

    if (msg_data == IPC_TIMEOUT) {
        return(IPC_TIMEOUT);
    }
    for (i = 0; i < 12; i++) {
        buff[i] = msg_data[i];
    }
    buff[12] = 0;
    blen = strlen(buff);
    if (message != NULL) {
        len += blen;
        message = (char *) erealloc(message, len + 1);
        strcat(message, buff);
    } else {
        len = blen;
        message = (char *) emalloc(len + 1);
        strcpy(message, buff);
    }
    if (blen < 12) {
        ret_msg = message;
        message = NULL;
        D(("Received complete reply:  \"%s\"\n", ret_msg));
    }
    return(ret_msg);
}

char *enl_send_and_wait(const char *msg)
{
    char *reply = IPC_TIMEOUT;
    sighandler_t old_alrm;

    /*
     * Shortcut this func and return IPC_FAKE
     * If the IPC Window is the E17 fake
     */
    if (e17_fake_ipc)
        return IPC_FAKE;

    if (ipc_win == None) {
        /* The IPC window is missing.  Wait for it to return or feh to be killed. */
        /* Only called once in the E17 case */
        for (; enl_ipc_get_win() == None;) {
            if (e17_fake_ipc)
                return IPC_FAKE;
            else
                sleep(1);
        }
    }
    old_alrm = (sighandler_t) signal(SIGALRM, (sighandler_t) enl_ipc_timeout);
    for (; reply == IPC_TIMEOUT;) {
        timeout = 0;
        enl_ipc_send(msg);
        for (; !(reply = enl_ipc_get(enl_wait_for_reply())););
        if (reply == IPC_TIMEOUT) {
            /* We timed out.  The IPC window must be AWOL.  Reset and resend message. */
            D(("IPC timed out.  IPC window has gone. Clearing ipc_win.\n"));
            XSelectInput(disp, ipc_win, None);
            ipc_win = None;
        }
    }
    signal(SIGALRM, old_alrm);
    return(reply);
}


/* nothing fancy */
int trans(double d, Window target_win)
{
    #define OPAQUE    0xffffffff
    #define OPACITY    "_NET_WM_WINDOW_OPACITY"
    unsigned int opacity;

    opacity = (unsigned int) (d * OPAQUE);
    XChangeProperty(disp, target_win, XInternAtom(disp, OPACITY, False), 
                XA_CARDINAL, 32, PropModeReplace, 
                (unsigned char *) &opacity, 1L);
    XSync(disp, False);
    return 0;
}


#define random(x) (rand()%x)    



//xcompmgr begin*********************

#if COMPOSITE_MAJOR > 0 || COMPOSITE_MINOR >= 2
#define HAS_NAME_WINDOW_PIXMAP 1
#endif

#define CAN_DO_USABLE 0

typedef enum {
        WINTYPE_DESKTOP,
        WINTYPE_DOCK,
        WINTYPE_TOOLBAR,
        WINTYPE_MENU,
        WINTYPE_UTILITY,
        WINTYPE_SPLASH,
        WINTYPE_DIALOG,
        WINTYPE_NORMAL,
        WINTYPE_DROPDOWN_MENU,
        WINTYPE_POPUP_MENU,
        WINTYPE_TOOLTIP,
        WINTYPE_NOTIFY,
        WINTYPE_COMBO,
        WINTYPE_DND,
        NUM_WINTYPES
} wintype;

typedef struct _ignore {
        struct _ignore    *next;
        unsigned long    sequence;
} ignore;

typedef struct _xcom_win {
        struct _xcom_win        *next;
        Window        id;
        Pixmap        pixmap;
        XWindowAttributes    xcom_a;
        Bool        usable;                /* mapped and all damaged at one point */
        XRectangle        damage_bounds;            /* bounds of damage */
        int            mode;
        int            damaged;
        Damage        damage;
        Picture        picture;
        Picture        alphaPict;
        Picture        shadowPict;
        XserverRegion    borderSize;
        XserverRegion    extents;
        Picture        shadow;
        int            shadow_dx;
        int            shadow_dy;
        int            shadow_width;
        int            shadow_height;
        unsigned int    opacity;
        wintype                         windowType;
        unsigned long    damage_sequence;        /* sequence when damage was created */
        Bool                                destroyed;

        Bool                                need_configure;
        XConfigureEvent         queue_configure;

        /* for drawing translucent windows */
        XserverRegion    borderClip;
        struct _xcom_win        *prev_trans;
} xcom_win;

typedef struct _conv {
        int            size;
        double    *data;
} conv;

typedef struct _fade {
        struct _fade    *next;
        xcom_win            *w;
        double        cur;
        double        finish;
        double        step;
        void        (*callback) (Display *dpy, xcom_win *w);
        Display        *dpy;
} fade;

xcom_win                         *list;
fade        *fades;
Display        *dpy;
int        xcom_scr;
Window        xcom_root;
Picture        rootPicture;
Picture        rootBuffer;
Picture        blackPicture;
Picture        transBlackPicture;
Picture        rootTile;
XserverRegion    allDamage;
Bool        clipChanged;
#if HAS_NAME_WINDOW_PIXMAP
Bool        hasNamePixmap;
#endif
int        root_height, root_width;
ignore        *ignore_head, **ignore_tail = &ignore_head;
int        xfixes_event, xfixes_error;
int        damage_event, damage_error;
int        composite_event, composite_error;
int        render_event, render_error;
Bool        synchronize;
int        composite_opcode;

/* find these once and be done with it */
Atom        opacityAtom;
Atom                        winTypeAtom;
Atom                        winType[NUM_WINTYPES];
double                    winTypeOpacity[NUM_WINTYPES];
Bool                        winTypeShadow[NUM_WINTYPES];
Bool                        winTypeFade[NUM_WINTYPES];

/* opacity property name; sometime soon I'll write up an EWMH spec for it */
#define OPACITY_PROP    "_NET_WM_WINDOW_OPACITY"
#define REGISTER_PROP     "_NET_WM_CM_S"

#define TRANSLUCENT    0xe0000000
#define OPAQUE        0xffffffff

conv                        *gaussianMap;

#define WINDOW_SOLID    0
#define WINDOW_TRANS    1
#define WINDOW_ARGB    2

#define TRANS_OPACITY    0.75

#define DEBUG_REPAINT 0
#define DEBUG_EVENTS 0
#define MONITOR_REPAINT 0

#define SHADOWS        1
#define SHARP_SHADOW    0

typedef enum _compMode {
        CompSimple,        /* looks like a regular X server */
        CompServerShadows,    /* use window alpha for shadow; sharp, but precise */
        CompClientShadows,    /* use window extents for shadow, blurred */
} CompMode;

static void
determine_mode(Display *dpy, xcom_win *w);
        
static double
get_opacity_percent(Display *dpy, xcom_win *w);

static XserverRegion
win_extents (Display *dpy, xcom_win *w);

CompMode        compMode = CompSimple;

int            shadowRadius = 12;
int                 shadowOffsetX = -15;
int                 shadowOffsetY = -15;
double            shadowOpacity = .75;

double    fade_in_step =    0.028;
double    fade_out_step = 0.03;
int    fade_delta =    10;
int    fade_time =    0;
Bool    fadeTrans = False;

Bool    autoRedirect = False;

/* For shadow precomputation */
int                        Gsize = -1;
unsigned char *shadowCorner = NULL;
unsigned char *shadowTop = NULL;

//wmctrl begin********************
#define MAX_PROPERTY_VALUE_LEN 4096
static gboolean envir_utf8;
     
static struct {
        int verbose;
        int force_utf8;
        int show_class;
        int show_pid;
        int show_geometry;
        int match_by_id;
    int match_by_cls;
        int full_window_title_match;
        int wa_desktop_titles_invalid_utf8;
        char *param_window;
        char *param;
} options;


#define p_verbose(...) if (options.verbose) { \
        fprintf(stderr, __VA_ARGS__); \
}

static gchar *get_output_str (gchar *str, gboolean is_utf8) {/*{{{*/
        gchar *out;
     
        if (str == NULL) {
                return NULL;
        }
        
        if (envir_utf8) {
                if (is_utf8) {
                        out = g_strdup(str);
                }
                else {
                        if (! (out = g_locale_to_utf8(str, -1, NULL, NULL, NULL))) {
                                p_verbose("Cannot convert string from locale charset to UTF-8.\n");
                                out = g_strdup(str);
                        }
                }
        }
        else {
                if (is_utf8) {
                        if (! (out = g_locale_from_utf8(str, -1, NULL, NULL, NULL))) {
                                p_verbose("Cannot convert string from UTF-8 to locale charset.\n");
                                out = g_strdup(str);
                        }
                }
                else {
                        out = g_strdup(str);
                }
        }

        return out;
}/*}}}*/

static gchar *get_property (Display *disp, Window win, /*{{{*/
                Atom xa_prop_type, const gchar *prop_name, unsigned long *size) {
        Atom xa_prop_name;
        Atom xa_ret_type;
        int ret_format;
        unsigned long ret_nitems;
        unsigned long ret_bytes_after;
        unsigned long tmp_size;
        unsigned char *ret_prop;
        gchar *ret;
        
        xa_prop_name = XInternAtom(disp, prop_name, False);
        
        /* MAX_PROPERTY_VALUE_LEN / 4 explanation (XGetWindowProperty manpage):
         *
         * long_length = Specifies the length in 32-bit multiples of the
         *                             data to be retrieved.
         */
        if (XGetWindowProperty(disp, win, xa_prop_name, 0, MAX_PROPERTY_VALUE_LEN / 4, False,
                        xa_prop_type, &xa_ret_type, &ret_format,         
                        &ret_nitems, &ret_bytes_after, &ret_prop) != Success) {
                p_verbose("Cannot get %s property.\n", prop_name);
                return NULL;
        }
    
        if (xa_ret_type != xa_prop_type) {
                p_verbose("Invalid type of %s property.\n", prop_name);
                XFree(ret_prop);
                return NULL;
        }

        /* null terminate the result to make string handling easier */
        tmp_size = (ret_format / 8) * ret_nitems;
        ret = (gchar*)g_malloc(tmp_size + 1);
        memcpy(ret, ret_prop, tmp_size);
        ret[tmp_size] = '\0';

        if (size) {
                *size = tmp_size;
        }
        
        XFree(ret_prop);
        return ret;
}/*}}}*/

static gchar *get_wm_name (Display *disp) {/*{{{*/
        Window *sup_window = NULL;
        gchar *wm_name = NULL;
        gboolean name_is_utf8 = TRUE;
        gchar *name_out = NULL;
        if (! (sup_window = (Window *)get_property(disp, DefaultRootWindow(disp),
                                        XA_WINDOW, "_NET_SUPPORTING_WM_CHECK", NULL))) {
                if (! (sup_window = (Window *)get_property(disp, DefaultRootWindow(disp),
                                                XA_CARDINAL, "_WIN_SUPPORTING_WM_CHECK", NULL))) {
                        fputs("Cannot get window manager info properties.\n"
                                    "(_NET_SUPPORTING_WM_CHECK or _WIN_SUPPORTING_WM_CHECK)\n", stderr);
                        sprintf(name_out,"N/A");
                        return name_out;
                }
        }
        /* WM_NAME */
        if (! (wm_name = get_property(disp, *sup_window,
                        XInternAtom(disp, "UTF8_STRING", False), "_NET_WM_NAME", NULL))) {
                name_is_utf8 = FALSE;
                if (! (wm_name = get_property(disp, *sup_window,
                                XA_STRING, "_NET_WM_NAME", NULL))) {
                        p_verbose("Cannot get name of the window manager (_NET_WM_NAME).\n");
                }
        }
        name_out = get_output_str(wm_name, name_is_utf8);
        printf("%s\n",name_out);
        return name_out;
}/*}}}*/
//wmctrl end********************

int
get_time_in_milliseconds ()
{
        struct timeval    tv;

        gettimeofday (&tv, NULL);
        return tv.tv_sec * 1000 + tv.tv_usec / 1000;
}

fade *
find_fade (xcom_win *w)
{
        fade        *f;
        
        for (f = fades; f; f = f->next)
        {
    if (f->w == w)
            return f;
        }
        return 0;
}

void
dequeue_fade (Display *dpy, fade *f)
{
        fade        **prev;

        for (prev = &fades; *prev; prev = &(*prev)->next)
    if (*prev == f)
    {
            *prev = f->next;
            if (f->callback)
        (*f->callback) (dpy, f->w);
            free (f);
            break;
    }
}

void
cleanup_fade (Display *dpy, xcom_win *w)
{
        fade *f = find_fade (w);
        if (f)
    dequeue_fade (dpy, f);
}

void
enqueue_fade (Display *dpy, fade *f)
{
        if (!fades)
    fade_time = get_time_in_milliseconds () + fade_delta;
        f->next = fades;
        fades = f;
}

static void
set_fade (Display *dpy, xcom_win *w, double start, double finish, double step,
        void (*callback) (Display *dpy, xcom_win *w),
        Bool exec_callback, Bool override)
{
        fade        *f;

        f = find_fade (w);
        if (!f)
        {
    f = (fade*)malloc (sizeof (fade));
    f->next = 0;
    f->w = w;
    f->cur = start;
    enqueue_fade (dpy, f);
        }
        else if(!override)
    return;
        else
        {
     if (exec_callback)
             if (f->callback)
        (*f->callback)(dpy, f->w);
        }

        if (finish < 0)
    finish = 0;
        if (finish > 1)
    finish = 1;
        f->finish = finish;
        if (f->cur < finish)
                f->step = step;
        else if (f->cur > finish)
    f->step = -step;
        f->callback = callback;
        w->opacity = f->cur * OPAQUE;
#if 0
        printf ("set_fade start %g step %g\n", f->cur, f->step);
#endif
        determine_mode (dpy, w);
        if (w->shadow)
        {
    XRenderFreePicture (dpy, w->shadow);
    w->shadow = None;

                if (w->extents != None)
                        XFixesDestroyRegion (dpy, w->extents);

                /* rebuild the shadow */
                w->extents = win_extents (dpy, w);
        }

        /* fading windows need to be drawn, mark them as damaged.
             when a window maps, if it tries to fade in but it already at the right
             opacity (map/unmap/map fast) then it will never get drawn without this
             until it repaints */
        w->damaged = 1;
}

int
fade_timeout (void)
{
        int now;
        int    delta;
        if (!fades)
    return -1;
        now = get_time_in_milliseconds();
        delta = fade_time - now;
        if (delta < 0)
    delta = 0;
/*        printf ("timeout %d\n", delta); */
        return delta;
}

void
run_fades (Display *dpy)
{
        int            now = get_time_in_milliseconds();
        fade        *next = fades;
        int            steps;
        Bool        need_dequeue;

#if 0
        printf ("run fades\n");
#endif
        if (fade_time - now > 0)
    return;
        steps = 1 + (now - fade_time) / fade_delta;

        while (next)
        {
    fade *f = next;
    xcom_win *w = f->w;
    next = f->next;
    f->cur += f->step * steps;
                if (f->cur >= 1)
            f->cur = 1;
    else if (f->cur < 0)
            f->cur = 0;
#if 0
    printf ("opacity now %g\n", f->cur);
#endif
    w->opacity = f->cur * OPAQUE;
    need_dequeue = False;
    if (f->step > 0)
    {
            if (f->cur >= f->finish)
            {
        w->opacity = f->finish*OPAQUE;
        need_dequeue = True;
            }
    }
    else
    {
            if (f->cur <= f->finish)
            {
        w->opacity = f->finish*OPAQUE;
        need_dequeue = True;
            }
    }
    determine_mode (dpy, w);
    if (w->shadow)
    {
            XRenderFreePicture (dpy, w->shadow);
            w->shadow = None;

                        if (w->extents != None)
                                XFixesDestroyRegion (dpy, w->extents);

                        /* rebuild the shadow */
            w->extents = win_extents(dpy, w);
    }
    /* Must do this last as it might destroy f->w in callbacks */
    if (need_dequeue)
        dequeue_fade (dpy, f);
        }
        fade_time = now + fade_delta;
}

static double
gaussian (double r, double x, double y)
{
        return ((1 / (sqrt (2 * M_PI * r))) *
            exp ((- (x * x + y * y)) / (2 * r * r)));
}


static conv *
make_gaussian_map (Display *dpy, double r)
{
        conv            *c;
        int                size = ((int) ceil ((r * 3)) + 1) & ~1;
        int                center = size / 2;
        int                x, y;
        double            t;
        double            g;
        
        c = (conv*)malloc (sizeof (conv) + size * size * sizeof (double));
        c->size = size;
        c->data = (double *) (c + 1);
        t = 0.0;
        for (y = 0; y < size; y++)
    for (x = 0; x < size; x++)
    {
            g = gaussian (r, (double) (x - center), (double) (y - center));
            t += g;
            c->data[y * size + x] = g;
    }
/*        printf ("gaussian total %f\n", t); */
        for (y = 0; y < size; y++)
    for (x = 0; x < size; x++)
    {
            c->data[y*size + x] /= t;
    }
        return c;
}

/*
 * A picture will help
 *
 *    -center     0                                width    width+center
 *    -center +-----+-------------------+-----+
 *            |         |                                     |         |
 *            |         |                                     |         |
 *                0 +-----+-------------------+-----+
 *            |         |                                     |         |
 *            |         |                                     |         |
 *            |         |                                     |         |
 *     height +-----+-------------------+-----+
 *            |         |                                     |         |
 * height+    |         |                                     |         |
 *    center    +-----+-------------------+-----+
 */
 
static unsigned char
sum_gaussian (conv *map, double opacity, int x, int y, int width, int height)
{
        int            fx, fy;
        double    *g_data;
        double    *g_line = map->data;
        int            g_size = map->size;
        int            center = g_size / 2;
        int            fx_start, fx_end;
        int            fy_start, fy_end;
        double    v;
        
        /*
         * Compute set of filter values which are "in range",
         * that's the set with:
         *    0 <= x + (fx-center) && x + (fx-center) < width &&
         *    0 <= y + (fy-center) && y + (fy-center) < height
         *
         *    0 <= x + (fx - center)    x + fx - center < width
         *    center - x <= fx    fx < width + center - x
         */

        fx_start = center - x;
        if (fx_start < 0)
    fx_start = 0;
        fx_end = width + center - x;
        if (fx_end > g_size)
    fx_end = g_size;

        fy_start = center - y;
        if (fy_start < 0)
    fy_start = 0;
        fy_end = height + center - y;
        if (fy_end > g_size)
    fy_end = g_size;

        g_line = g_line + fy_start * g_size + fx_start;
        
        v = 0;
        for (fy = fy_start; fy < fy_end; fy++)
        {
    g_data = g_line;
    g_line += g_size;
    
    for (fx = fx_start; fx < fx_end; fx++)
            v += *g_data++;
        }
        if (v > 1)
    v = 1;
        
        return ((unsigned char) (v * opacity * 255.0));
}

/* precompute shadow corners and sides to save time for large windows */
static void
presum_gaussian (conv *map)
{
        int center = map->size/2;
        int opacity, x, y;

        Gsize = map->size;

        if (shadowCorner)
    free ((void *)shadowCorner);
        if (shadowTop)
    free ((void *)shadowTop);

        shadowCorner = (unsigned char *)(malloc ((Gsize + 1) * (Gsize + 1) * 26));
        shadowTop = (unsigned char *)(malloc ((Gsize + 1) * 26));
        
        for (x = 0; x <= Gsize; x++)
        {
    shadowTop[25 * (Gsize + 1) + x] = sum_gaussian (map, 1, x - center, center, Gsize * 2, Gsize * 2);
    for(opacity = 0; opacity < 25; opacity++)
            shadowTop[opacity * (Gsize + 1) + x] = shadowTop[25 * (Gsize + 1) + x] * opacity / 25;
    for(y = 0; y <= x; y++)
    {
            shadowCorner[25 * (Gsize + 1) * (Gsize + 1) + y * (Gsize + 1) + x]
        = sum_gaussian (map, 1, x - center, y - center, Gsize * 2, Gsize * 2);
            shadowCorner[25 * (Gsize + 1) * (Gsize + 1) + x * (Gsize + 1) + y]
        = shadowCorner[25 * (Gsize + 1) * (Gsize + 1) + y * (Gsize + 1) + x];
            for(opacity = 0; opacity < 25; opacity++)
        shadowCorner[opacity * (Gsize + 1) * (Gsize + 1) + y * (Gsize + 1) + x]
                = shadowCorner[opacity * (Gsize + 1) * (Gsize + 1) + x * (Gsize + 1) + y]
                = shadowCorner[25 * (Gsize + 1) * (Gsize + 1) + y * (Gsize + 1) + x] * opacity / 25;
    }
        }
}

static XImage *
make_shadow (Display *dpy, double opacity, int width, int height)
{
        XImage            *ximage;
        unsigned char     *data;
        int                gsize = gaussianMap->size;
        int                ylimit, xlimit;
        int                swidth = width + gsize;
        int                sheight = height + gsize;
        int                center = gsize / 2;
        int                x, y;
        unsigned char     d;
        int                x_diff;
        int                         opacity_int = (int)(opacity * 25);
        data = (unsigned char*)malloc (swidth * sheight * sizeof (unsigned char));
        if (!data)
    return 0;
        ximage = XCreateImage (dpy,
                 DefaultVisual(dpy, DefaultScreen(dpy)),
                 8,
                 ZPixmap,
                 0,
                 (char *) data,
                 swidth, sheight, 8, swidth * sizeof (unsigned char));
        if (!ximage)
        {
    free (data);
    return 0;
        }
        /*
         * Build the gaussian in sections
         */

        /*
         * center (fill the complete data array)
         */
        if (Gsize > 0)
    d = shadowTop[opacity_int * (Gsize + 1) + Gsize];
        else
    d = sum_gaussian (gaussianMap, opacity, center, center, width, height);
        memset(data, d, sheight * swidth);
        
        /*
         * corners
         */
        ylimit = gsize;
        if (ylimit > sheight / 2)
    ylimit = (sheight + 1) / 2;
        xlimit = gsize;
        if (xlimit > swidth / 2)
    xlimit = (swidth + 1) / 2;

        for (y = 0; y < ylimit; y++)
    for (x = 0; x < xlimit; x++)
    {
            if (xlimit == Gsize && ylimit == Gsize)
        d = shadowCorner[opacity_int * (Gsize + 1) * (Gsize + 1) + y * (Gsize + 1) + x];
            else
        d = sum_gaussian (gaussianMap, opacity, x - center, y - center, width, height);
            data[y * swidth + x] = d;
            data[(sheight - y - 1) * swidth + x] = d;
            data[(sheight - y - 1) * swidth + (swidth - x - 1)] = d;
            data[y * swidth + (swidth - x - 1)] = d;
    }

        /*
         * top/bottom
         */
        x_diff = swidth - (gsize * 2);
        if (x_diff > 0 && ylimit > 0)
        {
    for (y = 0; y < ylimit; y++)
    {
            if (ylimit == Gsize)
        d = shadowTop[opacity_int * (Gsize + 1) + y];
            else
        d = sum_gaussian (gaussianMap, opacity, center, y - center, width, height);
            memset (&data[y * swidth + gsize], d, x_diff);
            memset (&data[(sheight - y - 1) * swidth + gsize], d, x_diff);
    }
        }

        /*
         * sides
         */
        
        for (x = 0; x < xlimit; x++)
        {
    if (xlimit == Gsize)
            d = shadowTop[opacity_int * (Gsize + 1) + x];
    else
            d = sum_gaussian (gaussianMap, opacity, x - center, center, width, height);
    for (y = gsize; y < sheight - gsize; y++)
    {
            data[y * swidth + x] = d;
            data[y * swidth + (swidth - x - 1)] = d;
    }
        }

        return ximage;
}

static Picture
shadow_picture (Display *dpy, double opacity, Picture alpha_pict, int width, int height, int *wp, int *hp)
{
        XImage    *shadowImage;
        Pixmap    shadowPixmap;
        Picture shadowPicture;
        GC            gc;
        
        shadowImage = make_shadow (dpy, opacity, width, height);
        if (!shadowImage)
    return None;
        shadowPixmap = XCreatePixmap (dpy, xcom_root, 
                    shadowImage->width,
                    shadowImage->height,
                    8);
        if (!shadowPixmap)
        {
    XDestroyImage (shadowImage);
    return None;
        }

        shadowPicture = XRenderCreatePicture (dpy, shadowPixmap,
                        XRenderFindStandardFormat (dpy, PictStandardA8),
                        0, 0);
        if (!shadowPicture)
        {
    XDestroyImage (shadowImage);
    XFreePixmap (dpy, shadowPixmap);
    return None;
        }

        gc = XCreateGC (dpy, shadowPixmap, 0, 0);
        if (!gc)
        {
    XDestroyImage (shadowImage);
    XFreePixmap (dpy, shadowPixmap);
    XRenderFreePicture (dpy, shadowPicture);
    return None;
        }
        
        XPutImage (dpy, shadowPixmap, gc, shadowImage, 0, 0, 0, 0, 
                 shadowImage->width,
                 shadowImage->height);
        *wp = shadowImage->width;
        *hp = shadowImage->height;
        XFreeGC (dpy, gc);
        XDestroyImage (shadowImage);
        XFreePixmap (dpy, shadowPixmap);
        return shadowPicture;
}

Picture
solid_picture (Display *dpy, Bool argb, double a, double r, double g, double b)
{
        Pixmap            pixmap;
        Picture            picture;
        XRenderPictureAttributes    pa;
        XRenderColor        c;

        pixmap = XCreatePixmap (dpy, xcom_root, 1, 1, argb ? 32 : 8);
        if (!pixmap)
    return None;

        pa.repeat = True;
        picture = XRenderCreatePicture (dpy, pixmap,
                        XRenderFindStandardFormat (dpy, argb ? PictStandardARGB32 : PictStandardA8),
                        CPRepeat,
                        &pa);
        if (!picture)
        {
    XFreePixmap (dpy, pixmap);
    return None;
        }

        c.alpha = a * 0xffff;
        c.red = r * 0xffff;
        c.green = g * 0xffff;
        c.blue = b * 0xffff;
        XRenderFillRectangle (dpy, PictOpSrc, picture, &c, 0, 0, 1, 1);
        XFreePixmap (dpy, pixmap);
        return picture;
}

void
discard_ignore (Display *dpy, unsigned long sequence)
{
        while (ignore_head)
        {
    if ((long) (sequence - ignore_head->sequence) > 0)
    {
            ignore    *next = ignore_head->next;
            free (ignore_head);
            ignore_head = next;
            if (!ignore_head)
        ignore_tail = &ignore_head;
    }
    else
            break;
        }
}

void
set_ignore (Display *dpy, unsigned long sequence)
{
        ignore    *i = (ignore*)malloc (sizeof (ignore));
        if (!i)
    return;
        i->sequence = sequence;
        i->next = 0;
        *ignore_tail = i;
        ignore_tail = &i->next;
}

int
should_ignore (Display *dpy, unsigned long sequence)
{
        discard_ignore (dpy, sequence);
        return ignore_head && ignore_head->sequence == sequence;
}

static xcom_win *
find_win (Display *dpy, Window id)
{
        xcom_win    *w;

        for (w = list; w; w = w->next)
    if (w->id == id && !w->destroyed)
            return w;
        return 0;
}

static const char *backgroundProps[] = {
        "_XROOTPMAP_ID",
        "_XSETROOT_ID",
        0,
};
        
static Picture
root_tile (Display *dpy)
{
        Picture            picture;
        Atom            actual_type;
        Pixmap            pixmap;
        int                actual_format;
        unsigned long     nitems;
        unsigned long     bytes_after;
        unsigned char     *prop;
        Bool            fill;
        XRenderPictureAttributes    pa;
        int                p;

        pixmap = None;
        for (p = 0; backgroundProps[p]; p++)
        {
    if (XGetWindowProperty (dpy, xcom_root, XInternAtom (dpy, backgroundProps[p], False),
                0, 4, False, AnyPropertyType,
                &actual_type, &actual_format, &nitems, &bytes_after, &prop) == Success &&
            actual_type == XInternAtom (dpy, "PIXMAP", False) && actual_format == 32 && nitems == 1)
    {
            memcpy (&pixmap, prop, 4);
            XFree (prop);
            fill = False;
            break;
    }
        }
        if (!pixmap)
        {
    pixmap = XCreatePixmap (dpy, xcom_root, 1, 1, DefaultDepth (dpy, xcom_scr));
    fill = True;
        }
        pa.repeat = True;
        picture = XRenderCreatePicture (dpy, pixmap,
                        XRenderFindVisualFormat (dpy,
                                     DefaultVisual (dpy, xcom_scr)),
                        CPRepeat, &pa);
        if (fill)
        {
    XRenderColor        c;
    
    c.red = c.green = c.blue = 0x8080;
    c.alpha = 0xffff;
    XRenderFillRectangle (dpy, PictOpSrc, picture, &c, 
                        0, 0, 1, 1);
        }
        return picture;
}

static void
paint_root (Display *dpy)
{
        if (!rootTile)
    rootTile = root_tile (dpy);
        
        XRenderComposite (dpy, PictOpSrc,
                    rootTile, None, rootBuffer,
                    0, 0, 0, 0, 0, 0, root_width, root_height);
}

static XserverRegion
win_extents (Display *dpy, xcom_win *w)
{
        XRectangle            r;
        
        r.x = w->xcom_a.x;
        r.y = w->xcom_a.y;
        r.width = w->xcom_a.width + w->xcom_a.border_width * 2;
        r.height = w->xcom_a.height + w->xcom_a.border_width * 2;
        if (winTypeShadow[w->windowType])
        {
    if (compMode == CompServerShadows || w->mode != WINDOW_ARGB)
    {
            XRectangle    sr;

            if (compMode == CompServerShadows)
            {
        w->shadow_dx = shadowOffsetX;
        w->shadow_dy = shadowOffsetY;
        w->shadow_width = w->xcom_a.width;
        w->shadow_height = w->xcom_a.height;
            }
            else
            {
        w->shadow_dx = shadowOffsetX;
        w->shadow_dy = shadowOffsetY;
        if (!w->shadow)
        {
                double    opacity = shadowOpacity;
                if (w->mode == WINDOW_TRANS)
            opacity = opacity * ((double)w->opacity)/((double)OPAQUE);
                w->shadow = shadow_picture (dpy, opacity, w->alphaPict,
                        w->xcom_a.width + w->xcom_a.border_width * 2,
                        w->xcom_a.height + w->xcom_a.border_width * 2,
                        &w->shadow_width, &w->shadow_height);
        }
            }
            sr.x = w->xcom_a.x + w->shadow_dx;
            sr.y = w->xcom_a.y + w->shadow_dy;
            sr.width = w->shadow_width;
            sr.height = w->shadow_height;
            if (sr.x < r.x)
            {
        r.width = (r.x + r.width) - sr.x;
        r.x = sr.x;
            }
            if (sr.y < r.y)
            {
        r.height = (r.y + r.height) - sr.y;
        r.y = sr.y;
            }
            if (sr.x + sr.width > r.x + r.width)
        r.width = sr.x + sr.width - r.x;
            if (sr.y + sr.height > r.y + r.height)
        r.height = sr.y + sr.height - r.y;
    }
        }
        return XFixesCreateRegion (dpy, &r, 1);
}

static XserverRegion
border_size (Display *dpy, xcom_win *w)
{
        XserverRegion     border;
        /*
         * if window doesn't exist anymore,    this will generate an error
         * as well as not generate a region.    Perhaps a better XFixes
         * architecture would be to have a request that copies instead
         * of creates, that way you'd just end up with an empty region
         * instead of an invalid XID.
         */
        set_ignore (dpy, NextRequest (dpy));
        border = XFixesCreateRegionFromWindow (dpy, w->id, WindowRegionBounding);
        /* translate this */
        set_ignore (dpy, NextRequest (dpy));
        XFixesTranslateRegion (dpy, border,
                 w->xcom_a.x + w->xcom_a.border_width,
                 w->xcom_a.y + w->xcom_a.border_width);
        return border;
}

static void
paint_all (Display *dpy, XserverRegion region)
{
        xcom_win    *w;
        xcom_win    *t = 0;
        
        if (!region)
        {
    XRectangle    r;
    r.x = 0;
    r.y = 0;
    r.width = root_width;
    r.height = root_height;
    region = XFixesCreateRegion (dpy, &r, 1);
        }
#if MONITOR_REPAINT
        rootBuffer = rootPicture;
#else
        if (!rootBuffer)
        {
    Pixmap    rootPixmap = XCreatePixmap (dpy, xcom_root, root_width, root_height,
                            DefaultDepth (dpy, xcom_scr));
    rootBuffer = XRenderCreatePicture (dpy, rootPixmap,
                         XRenderFindVisualFormat (dpy,
                                        DefaultVisual (dpy, xcom_scr)),
                         0, 0);
    XFreePixmap (dpy, rootPixmap);
        }
#endif
        XFixesSetPictureClipRegion (dpy, rootPicture, 0, 0, region);
#if MONITOR_REPAINT
        XRenderComposite (dpy, PictOpSrc, blackPicture, None, rootPicture,
                    0, 0, 0, 0, 0, 0, root_width, root_height);
#endif
#if DEBUG_REPAINT
        printf ("paint:");
#endif
        for (w = list; w; w = w->next)
        {
#if CAN_DO_USABLE
    if (!w->usable)
            continue;
#endif
    /* never painted, ignore it */
    if (!w->damaged)
            continue;
    /* if invisible, ignore it */
    if (w->xcom_a.x + w->xcom_a.width < 1 || w->xcom_a.y + w->xcom_a.height < 1
            || w->xcom_a.x >= root_width || w->xcom_a.y >= root_height)
            continue;
    if (!w->picture)
    {
            XRenderPictureAttributes    pa;
            XRenderPictFormat        *format;
            Drawable            draw = w->id;
            
#if HAS_NAME_WINDOW_PIXMAP
            if (hasNamePixmap && !w->pixmap) {
                                set_ignore (dpy, NextRequest (dpy));
                                w->pixmap = XCompositeNameWindowPixmap (dpy, w->id);
                        }
            if (w->pixmap)
        draw = w->pixmap;
#endif
            format = XRenderFindVisualFormat (dpy, w->xcom_a.visual);
            pa.subwindow_mode = IncludeInferiors;
            w->picture = XRenderCreatePicture (dpy, draw,
                                 format,
                                 CPSubwindowMode,
                                 &pa);
    }
#if DEBUG_REPAINT
    printf (" 0x%x", w->id);
#endif
    if (clipChanged)
    {
            if (w->borderSize)
            {
        set_ignore (dpy, NextRequest (dpy));
        XFixesDestroyRegion (dpy, w->borderSize);
        w->borderSize = None;
            }
            if (w->extents)
            {
        XFixesDestroyRegion (dpy, w->extents);
        w->extents = None;
            }
            if (w->borderClip)
            {
        XFixesDestroyRegion (dpy, w->borderClip);
        w->borderClip = None;
            }
    }
    if (!w->borderSize)
            w->borderSize = border_size (dpy, w);
    if (!w->extents)
            w->extents = win_extents (dpy, w);
    if (w->mode == WINDOW_SOLID)
    {
            int    x, y, wid, hei;
#if HAS_NAME_WINDOW_PIXMAP
            x = w->xcom_a.x;
            y = w->xcom_a.y;
            wid = w->xcom_a.width + w->xcom_a.border_width * 2;
            hei = w->xcom_a.height + w->xcom_a.border_width * 2;
#else
            x = w->xcom_a.x + w->xcom_a.border_width;
            y = w->xcom_a.y + w->xcom_a.border_width;
            wid = w->xcom_a.width;
            hei = w->xcom_a.height;
#endif
            XFixesSetPictureClipRegion (dpy, rootBuffer, 0, 0, region);
            set_ignore (dpy, NextRequest (dpy));
            XFixesSubtractRegion (dpy, region, region, w->borderSize);
            set_ignore (dpy, NextRequest (dpy));
            XRenderComposite (dpy, PictOpSrc, w->picture, None, rootBuffer,
                        0, 0, 0, 0, 
                        x, y, wid, hei);
    }
    if (!w->borderClip)
    {
            w->borderClip = XFixesCreateRegion (dpy, 0, 0);
            XFixesCopyRegion (dpy, w->borderClip, region);
    }
    w->prev_trans = t;
    t = w;
        }
#if DEBUG_REPAINT
        printf ("\n");
        fflush (stdout);
#endif
        XFixesSetPictureClipRegion (dpy, rootBuffer, 0, 0, region);
        paint_root (dpy);
        for (w = t; w; w = w->prev_trans)
        {
    XFixesSetPictureClipRegion (dpy, rootBuffer, 0, 0, w->borderClip);
                if (winTypeShadow[w->windowType]) {
                        switch (compMode) {
                        case CompSimple:
                                break;
                        case CompServerShadows:
                                set_ignore (dpy, NextRequest (dpy));
                                if (w->opacity != OPAQUE && !w->shadowPict)
                                        w->shadowPict = solid_picture (dpy, True,
                                                                                                     (double) w->opacity / OPAQUE * 0.3,
                                                                                                     0, 0, 0);
                                XRenderComposite (dpy, PictOpOver,
                                                                    w->shadowPict ? w->shadowPict : transBlackPicture,
                                                                    w->picture, rootBuffer,
                                                                    0, 0, 0, 0,
                                                                    w->xcom_a.x + w->shadow_dx,
                                                                    w->xcom_a.y + w->shadow_dy,
                                                                    w->shadow_width, w->shadow_height);
                                break;
                        case CompClientShadows:
        XRenderComposite (dpy, PictOpOver, blackPicture, w->shadow, rootBuffer,
                    0, 0, 0, 0,
                    w->xcom_a.x + w->shadow_dx,
                    w->xcom_a.y + w->shadow_dy,
                    w->shadow_width, w->shadow_height);
                                break;
                        }
                }
    if (w->opacity != OPAQUE && !w->alphaPict)
            w->alphaPict = solid_picture (dpy, False, 
                        (double) w->opacity / OPAQUE, 0, 0, 0);
    if (w->mode == WINDOW_TRANS)
    {
            int    x, y, wid, hei;
#if HAS_NAME_WINDOW_PIXMAP
            x = w->xcom_a.x;
            y = w->xcom_a.y;
            wid = w->xcom_a.width + w->xcom_a.border_width * 2;
            hei = w->xcom_a.height + w->xcom_a.border_width * 2;
#else
            x = w->xcom_a.x + w->xcom_a.border_width;
            y = w->xcom_a.y + w->xcom_a.border_width;
            wid = w->xcom_a.width;
            hei = w->xcom_a.height;
#endif
            set_ignore (dpy, NextRequest (dpy));
            XRenderComposite (dpy, PictOpOver, w->picture, w->alphaPict, rootBuffer,
                        0, 0, 0, 0, 
                        x, y, wid, hei);
    }
    else if (w->mode == WINDOW_ARGB)
    {
            int    x, y, wid, hei;
#if HAS_NAME_WINDOW_PIXMAP
            x = w->xcom_a.x;
            y = w->xcom_a.y;
            wid = w->xcom_a.width + w->xcom_a.border_width * 2;
            hei = w->xcom_a.height + w->xcom_a.border_width * 2;
#else
            x = w->xcom_a.x + w->xcom_a.border_width;
            y = w->xcom_a.y + w->xcom_a.border_width;
            wid = w->xcom_a.width;
            hei = w->xcom_a.height;
#endif
            set_ignore (dpy, NextRequest (dpy));
            XRenderComposite (dpy, PictOpOver, w->picture, w->alphaPict, rootBuffer,
                        0, 0, 0, 0, 
                        x, y, wid, hei);
    }
    XFixesDestroyRegion (dpy, w->borderClip);
    w->borderClip = None;
        }
        XFixesDestroyRegion (dpy, region);
        if (rootBuffer != rootPicture)
        {
    XFixesSetPictureClipRegion (dpy, rootBuffer, 0, 0, None);
    XRenderComposite (dpy, PictOpSrc, rootBuffer, None, rootPicture,
                0, 0, 0, 0, 0, 0, root_width, root_height);
        }
}

static void
add_damage (Display *dpy, XserverRegion damage)
{
        if (allDamage)
        {
    XFixesUnionRegion (dpy, allDamage, allDamage, damage);
    XFixesDestroyRegion (dpy, damage);
        }
        else
    allDamage = damage;
}

static void
repair_win (Display *dpy, xcom_win *w)
{
        XserverRegion     parts;

        if (!w->damaged)
        {
    parts = win_extents (dpy, w);
    set_ignore (dpy, NextRequest (dpy));
    XDamageSubtract (dpy, w->damage, None, None);
        }
        else
        {
    XserverRegion    o;
    parts = XFixesCreateRegion (dpy, 0, 0);
    set_ignore (dpy, NextRequest (dpy));
    XDamageSubtract (dpy, w->damage, None, parts);
    XFixesTranslateRegion (dpy, parts,
                         w->xcom_a.x + w->xcom_a.border_width,
                         w->xcom_a.y + w->xcom_a.border_width);
    if (compMode == CompServerShadows)
    {
            o = XFixesCreateRegion (dpy, 0, 0);
            XFixesCopyRegion (dpy, o, parts);
            XFixesTranslateRegion (dpy, o, w->shadow_dx, w->shadow_dy);
            XFixesUnionRegion (dpy, parts, parts, o);
            XFixesDestroyRegion (dpy, o);
    }
        }
        add_damage (dpy, parts);
        w->damaged = 1;
}
/*
static const char*
wintype_name(wintype type)
{
        const char *t;
        switch (type) {
        case WINTYPE_DESKTOP: t = "desktop"; break;
        case WINTYPE_DOCK:        t = "dock"; break;
        case WINTYPE_TOOLBAR: t = "toolbar"; break;
        case WINTYPE_MENU:        t = "menu"; break;
        case WINTYPE_UTILITY: t = "utility"; break;
        case WINTYPE_SPLASH:    t = "slash"; break;
        case WINTYPE_DIALOG:    t = "dialog"; break;
        case WINTYPE_NORMAL:    t = "normal"; break;
        case WINTYPE_DROPDOWN_MENU: t = "dropdown"; break;
        case WINTYPE_POPUP_MENU: t = "popup"; break;
        case WINTYPE_TOOLTIP: t = "tooltip"; break;
        case WINTYPE_NOTIFY:    t = "notification"; break;
        case WINTYPE_COMBO:     t = "combo"; break;
        case WINTYPE_DND:         t = "dnd"; break;
        default:                            t = "unknown"; break;
        }
        return t;
}
*/
static wintype
get_wintype_prop(Display * dpy, Window w)
{
        Atom actual;
        wintype ret;
        int format;
        unsigned long n, left, off;
        unsigned char *data;

        ret = (wintype)-1;
        off = 0;

        do {
                set_ignore (dpy, NextRequest (dpy));
                int result = XGetWindowProperty (dpy, w, winTypeAtom, off, 1L, False,
                                                                                 XA_ATOM, &actual, &format,
                                                                                 &n, &left, &data);

                if (result != Success)
                        break;
                if (data != None)
                {
                        int i;

                        for (i = 0; i < NUM_WINTYPES; ++i) {
                                Atom a;
                                memcpy (&a, data, sizeof (Atom));
                                if (a == winType[i]) {
                                        /* known type */
                                        ret =(wintype) i;
                                        break;
                                }
                        }

                        XFree ( (void *) data);
                }

                ++off;
        } while (left >= 4 && ret == (wintype)-1);

        return ret;
}

static wintype
determine_wintype (Display *dpy, Window w, Window top)
{
        Window             root_return, parent_return;
        Window            *children = NULL;
        unsigned int nchildren, i;
        wintype            type;

        type = get_wintype_prop (dpy, w);
        if (type != (wintype)-1)
    return type;

        set_ignore (dpy, NextRequest (dpy));
        if (!XQueryTree (dpy, w, &root_return, &parent_return, &children,
                    &nchildren))
        {
    /* XQueryTree failed. */
    if (children)
            XFree ((void *)children);
    return (wintype)-1;
        }

        for (i = 0;i < nchildren;i++)
        {
    type = determine_wintype (dpy, children[i], top);
    if (type != (wintype)-1)
            return type;
        }

        if (children)
    XFree ((void *)children);

        if (w != top)
                return (wintype)-1;
        else
                return WINTYPE_NORMAL;
}

static unsigned int
get_opacity_prop (Display *dpy, xcom_win *w, unsigned int def);

static void
configure_win (Display *dpy, XConfigureEvent *ce);

static void
map_win (Display *dpy, Window id, unsigned long sequence, Bool fade)
{
        xcom_win        *w = find_win (dpy, id);

        if (!w)
    return;

        w->xcom_a.map_state = IsViewable;

        w->windowType = determine_wintype (dpy, w->id, w->id);
#if 0
        printf("window 0x%x type %s\n", w->id, wintype_name(w->windowType));
#endif

        /* select before reading the property so that no property changes are lost */
        XSelectInput (dpy, id, PropertyChangeMask);
        w->opacity = get_opacity_prop (dpy, w, OPAQUE);

        determine_mode (dpy, w);

#if CAN_DO_USABLE
        w->damage_bounds.x = w->damage_bounds.y = 0;
        w->damage_bounds.width = w->damage_bounds.height = 0;
#endif
        w->damaged = 0;

        if (fade && winTypeFade[w->windowType])
    set_fade (dpy, w, 0, get_opacity_percent (dpy, w), fade_in_step, 0, True, True);

        /* if any configure events happened while the window was unmapped, then
             configure the window to its correct place */
        if (w->need_configure)
                configure_win (dpy, &w->queue_configure);
}

static void
finish_unmap_win (Display *dpy, xcom_win *w)
{
        w->damaged = 0;
#if CAN_DO_USABLE
        w->usable = False;
#endif
        if (w->extents != None)
        {
    add_damage (dpy, w->extents);        /* destroys region */
    w->extents = None;
        }
        
#if HAS_NAME_WINDOW_PIXMAP
        if (w->pixmap)
        {
    XFreePixmap (dpy, w->pixmap);
    w->pixmap = None;
        }
#endif

        if (w->picture)
        {
    set_ignore (dpy, NextRequest (dpy));
    XRenderFreePicture (dpy, w->picture);
    w->picture = None;
        }

        if (w->borderSize)
        {
    set_ignore (dpy, NextRequest (dpy));
            XFixesDestroyRegion (dpy, w->borderSize);
            w->borderSize = None;
        }
        if (w->shadow)
        {
    XRenderFreePicture (dpy, w->shadow);
    w->shadow = None;
        }
        if (w->borderClip)
        {
    XFixesDestroyRegion (dpy, w->borderClip);
    w->borderClip = None;
        }

        clipChanged = True;
}

#if HAS_NAME_WINDOW_PIXMAP
static void
unmap_callback (Display *dpy, xcom_win *w)
{
        finish_unmap_win (dpy, w);
}
#endif

static void
unmap_win (Display *dpy, Window id, Bool fade)
{
        xcom_win *w = find_win (dpy, id);
        if (!w)
    return;
        w->xcom_a.map_state = IsUnmapped;

        /* don't care about properties anymore */
        set_ignore (dpy, NextRequest (dpy));
        XSelectInput(dpy, w->id, 0);

#if HAS_NAME_WINDOW_PIXMAP
        if (w->pixmap && fade && winTypeFade[w->windowType])
    set_fade (dpy, w, w->opacity*1.0/OPAQUE, 0.0, fade_out_step, unmap_callback, False, True);
        else
#endif
    finish_unmap_win (dpy, w);
}

/* Get the opacity prop from window
     not found: default
     otherwise the value
 */
static unsigned int
get_opacity_prop(Display *dpy, xcom_win *w, unsigned int def)
{
        Atom actual;
        int format;
        unsigned long n, left;

        unsigned char *data;
        int result = XGetWindowProperty(dpy, w->id, opacityAtom, 0L, 1L, False, 
                     XA_CARDINAL, &actual, &format, 
                        &n, &left, &data);
        if (result == Success && data != NULL)
        {
    unsigned int i;
    memcpy (&i, data, sizeof (unsigned int));
    XFree( (void *) data);
    return i;
        }
        return def;
}

/* Get the opacity property from the window in a percent format
     not found: default
     otherwise: the value
*/
static double
get_opacity_percent(Display *dpy, xcom_win *w)
{
        double def = winTypeOpacity[w->windowType];
        unsigned int opacity = get_opacity_prop (dpy, w, (unsigned int)(OPAQUE*def));

        return opacity*1.0/OPAQUE;
}

static void
determine_mode(Display *dpy, xcom_win *w)
{
        int mode;
        XRenderPictFormat *format;

        /* if trans prop == -1 fall back on    previous tests*/

        if (w->alphaPict)
        {
    XRenderFreePicture (dpy, w->alphaPict);
    w->alphaPict = None;
        }
        if (w->shadowPict)
        {
    XRenderFreePicture (dpy, w->shadowPict);
    w->shadowPict = None;
        }
        if (w->xcom_a.c_class == InputOnly)
        {
    format = 0;
        }
        else
        {
    format = XRenderFindVisualFormat (dpy, w->xcom_a.visual);
        }

        if (format && format->type == PictTypeDirect && format->direct.alphaMask)
        {
    mode = WINDOW_ARGB;
        }
        else if (w->opacity != OPAQUE)
        {
    mode = WINDOW_TRANS;
        }
        else
        {
    mode = WINDOW_SOLID;
        }
        w->mode = mode;
        if (w->extents)
        {
    XserverRegion damage;
    damage = XFixesCreateRegion (dpy, 0, 0);
    XFixesCopyRegion (dpy, damage, w->extents);
    add_damage (dpy, damage);
        }
}

static void
add_win (Display *dpy, Window id, Window prev)
{
        xcom_win                *xcom_new = (xcom_win*)malloc (sizeof (xcom_win));
        xcom_win                **p;
        
        if (!xcom_new)
    return;
        if (prev)
        {
    for (p = &list; *p; p = &(*p)->next)
            if ((*p)->id == prev && !(*p)->destroyed)
        break;
        }
        else
    p = &list;
        xcom_new->id = id;
        set_ignore (dpy, NextRequest (dpy));
        if (!XGetWindowAttributes (dpy, id, &xcom_new->xcom_a))
        {
    free (xcom_new);
    return;
        }
        xcom_new->damaged = 0;
#if CAN_DO_USABLE
        xcom_new->usable = False;
#endif
#if HAS_NAME_WINDOW_PIXMAP
        xcom_new->pixmap = None;
#endif
        xcom_new->picture = None;
        if (xcom_new->xcom_a.c_class == InputOnly)
        {
    xcom_new->damage_sequence = 0;
    xcom_new->damage = None;
        }
        else
        {
    xcom_new->damage_sequence = NextRequest (dpy);
                set_ignore (dpy, NextRequest (dpy));
    xcom_new->damage = XDamageCreate (dpy, id, XDamageReportNonEmpty);
        }
        xcom_new->alphaPict = None;
        xcom_new->shadowPict = None;
        xcom_new->borderSize = None;
        xcom_new->extents = None;
        xcom_new->shadow = None;
        xcom_new->shadow_dx = 0;
        xcom_new->shadow_dy = 0;
        xcom_new->shadow_width = 0;
        xcom_new->shadow_height = 0;
        xcom_new->opacity = OPAQUE;
        xcom_new->destroyed = False;
        xcom_new->need_configure = False;

        xcom_new->borderClip = None;
        xcom_new->prev_trans = 0;

        xcom_new->next = *p;
        *p = xcom_new;
        if (xcom_new->xcom_a.map_state == IsViewable)
    map_win (dpy, id, xcom_new->damage_sequence - 1, True);
}

void
restack_win (Display *dpy, xcom_win *w, Window new_above)
{
        Window    old_above;
        
        if (w->next)
    old_above = w->next->id;
        else
    old_above = None;
        if (old_above != new_above)
        {
    xcom_win **prev;

    /* unhook */
    for (prev = &list; *prev; prev = &(*prev)->next)
            if ((*prev) == w)
        break;
    *prev = w->next;
    
    /* rehook */
    for (prev = &list; *prev; prev = &(*prev)->next)
    {
            if ((*prev)->id == new_above && !(*prev)->destroyed)
        break;
    }
    w->next = *prev;
    *prev = w;
        }
}

static void
configure_win (Display *dpy, XConfigureEvent *ce)
{
        xcom_win                *w = find_win (dpy, ce->window);
        XserverRegion     damage = None;
        
        if (!w)
        {
    if (ce->window == xcom_root)
    {
            if (rootBuffer)
            {
        XRenderFreePicture (dpy, rootBuffer);
        rootBuffer = None;
            }
            root_width = ce->width;
            root_height = ce->height;
    }
    return;
        }

        if (w->xcom_a.map_state == IsUnmapped) {
                /* save the configure event for when the window maps */
                w->need_configure = True;
                w->queue_configure = *ce;
        }
        else {
                w->need_configure = False;

#if CAN_DO_USABLE
                if (w->usable)
#endif
                {
                        damage = XFixesCreateRegion (dpy, 0, 0);
                        if (w->extents != None)
                                XFixesCopyRegion (dpy, damage, w->extents);
                }

                w->xcom_a.x = ce->x;
                w->xcom_a.y = ce->y;
                if (w->xcom_a.width != ce->width || w->xcom_a.height != ce->height)
                {
#if HAS_NAME_WINDOW_PIXMAP
                        if (w->pixmap)
                        {
                                XFreePixmap (dpy, w->pixmap);
                                w->pixmap = None;
                                if (w->picture)
                                {
                                        XRenderFreePicture (dpy, w->picture);
                                        w->picture = None;
                                }
                        }
#endif
                        if (w->shadow)
                        {
                                XRenderFreePicture (dpy, w->shadow);
                                w->shadow = None;
                        }
                }
                w->xcom_a.width = ce->width;
                w->xcom_a.height = ce->height;
                w->xcom_a.border_width = ce->border_width;
                if (w->xcom_a.map_state != IsUnmapped && damage)
                {
                        XserverRegion    extents = win_extents (dpy, w);
                        XFixesUnionRegion (dpy, damage, damage, extents);
                        XFixesDestroyRegion (dpy, extents);
                        add_damage (dpy, damage);
                }

                clipChanged = True;
        }

        w->xcom_a.override_redirect = ce->override_redirect;
        restack_win (dpy, w, ce->above);
}

static void
circulate_win (Display *dpy, XCirculateEvent *ce)
{
        xcom_win            *w = find_win (dpy, ce->window);
        Window    new_above;

        if (!w)
    return;

        if (ce->place == PlaceOnTop)
    new_above = list->id;
        else
    new_above = None;
        restack_win (dpy, w, new_above);
        clipChanged = True;
}

static void
finish_destroy_win (Display *dpy, Window id)
{
        xcom_win    **prev, *w;

        for (prev = &list; (w = *prev); prev = &w->next)
    if (w->id == id && w->destroyed)
    {
                        finish_unmap_win (dpy, w);
            *prev = w->next;
            if (w->alphaPict)
            {
        XRenderFreePicture (dpy, w->alphaPict);
        w->alphaPict = None;
            }
            if (w->shadowPict)
            {
        XRenderFreePicture (dpy, w->shadowPict);
        w->shadowPict = None;
            }
            if (w->damage != None)
            {
        set_ignore (dpy, NextRequest (dpy));
        XDamageDestroy (dpy, w->damage);
        w->damage = None;
            }

            cleanup_fade (dpy, w);
            free (w);
            break;
    }
}

#if HAS_NAME_WINDOW_PIXMAP
static void
destroy_callback (Display *dpy, xcom_win *w)
{
        finish_destroy_win (dpy, w->id);
}
#endif

static void
destroy_win (Display *dpy, Window id, Bool fade)
{
        xcom_win *w = find_win (dpy, id);

        if (w) w->destroyed = True;

#if HAS_NAME_WINDOW_PIXMAP
        if (w && w->pixmap && fade && winTypeFade[w->windowType])
    set_fade (dpy, w, w->opacity*1.0/OPAQUE, 0.0, fade_out_step,
                                    destroy_callback, False, True);
        else
#endif
        {
    finish_destroy_win (dpy, id);
        }
}

/*
static void
dump_win (xcom_win *w)
{
        printf ("\t%08lx: %d x %d + %d + %d (%d)\n", w->id,
            w->xcom_a.width, w->xcom_a.height, w->xcom_a.x, w->xcom_a.y, w->xcom_a.border_width);
}


static void
dump_wins (void)
{
        xcom_win    *w;

        printf ("windows:\n");
        for (w = list; w; w = w->next)
    dump_win (w);
}
*/

static void
damage_win (Display *dpy, XDamageNotifyEvent *de)
{
        xcom_win    *w = find_win (dpy, de->drawable);

        if (!w)
    return;
#if CAN_DO_USABLE
        if (!w->usable)
        {
    if (w->damage_bounds.width == 0 || w->damage_bounds.height == 0)
    {
            w->damage_bounds = de->area;
    }
    else
    {
            if (de->area.x < w->damage_bounds.x)
            {
        w->damage_bounds.width += (w->damage_bounds.x - de->area.x);
        w->damage_bounds.x = de->area.x;
            }
            if (de->area.y < w->damage_bounds.y)
            {
        w->damage_bounds.height += (w->damage_bounds.y - de->area.y);
        w->damage_bounds.y = de->area.y;
            }
            if (de->area.x + de->area.width > w->damage_bounds.x + w->damage_bounds.width)
        w->damage_bounds.width = de->area.x + de->area.width - w->damage_bounds.x;
            if (de->area.y + de->area.height > w->damage_bounds.y + w->damage_bounds.height)
        w->damage_bounds.height = de->area.y + de->area.height - w->damage_bounds.y;
    }
#if 0
    printf ("unusable damage %d, %d: %d x %d bounds %d, %d: %d x %d\n",
        de->area.x,
        de->area.y,
        de->area.width,
        de->area.height,
        w->damage_bounds.x,
        w->damage_bounds.y,
        w->damage_bounds.width,
        w->damage_bounds.height);
#endif
    if (w->damage_bounds.x <= 0 && 
            w->damage_bounds.y <= 0 &&
            w->xcom_a.width <= w->damage_bounds.x + w->damage_bounds.width &&
            w->xcom_a.height <= w->damage_bounds.y + w->damage_bounds.height)
    {
            clipChanged = True;
            if (winTypeFade[w->windowType])
        set_fade (dpy, w, 0, get_opacity_percent (dpy, w), fade_in_step, 0, True, True);
            w->usable = True;
    }
        }
        if (w->usable)
#endif
    repair_win (dpy, w);
}

static int
error (Display *dpy, XErrorEvent *ev)
{
//    int            o;
//        const char        *name = 0;
        
    if (should_ignore (dpy, ev->serial))
        return 0;
        
    if (ev->request_code == composite_opcode &&
        ev->minor_code == X_CompositeRedirectSubwindows)
    {
        fprintf (stderr, "Another composite manager is already running\n");
        have_error=1;
//    exit (1);
    }
        
//    o = ev->error_code - xfixes_error;
/*    switch (o) {
        case BadRegion: name = "BadRegion";    break;
        default: break;
        }
        o = ev->error_code - damage_error;
        switch (o) {
        case BadDamage: name = "BadDamage";    break;
        default: break;
        }
        o = ev->error_code - render_error;
        switch (o) {
        case BadPictFormat: name ="BadPictFormat"; break;
        case BadPicture: name ="BadPicture"; break;
        case BadPictOp: name ="BadPictOp"; break;
        case BadGlyphSet: name ="BadGlyphSet"; break;
        case BadGlyph: name ="BadGlyph"; break;
        default: break;
        }
*/    
    printf ("error %d request %d minor %d serial %lu\n",
        ev->error_code, ev->request_code, ev->minor_code, ev->serial);

/*        abort ();            this is just annoying to most people */
    return 0;
}

static void
expose_root (Display *dpy, Window root, XRectangle *rects, int nrects)
{
        XserverRegion    region = XFixesCreateRegion (dpy, rects, nrects);
        
        add_damage (dpy, region);
}

#if DEBUG_EVENTS
static int
ev_serial (XEvent *ev)
{
        if (ev->type & 0x7f != KeymapNotify)
    return ev->xany.serial;
        return NextRequest (ev->xany.display);
}

static char *
ev_name (XEvent *ev)
{
        static char    buf[128];
        switch (ev->type & 0x7f) {
        case Expose:
    return "Expose";
        case MapNotify:
    return "Map";
        case UnmapNotify:
    return "Unmap";
        case ReparentNotify:
    return "Reparent";
        case CirculateNotify:
    return "Circulate";
        default:
            if (ev->type == damage_event + XDamageNotify)
            return "Damage";
    sprintf (buf, "Event %d", ev->type);
    return buf;
        }
}

static Window
ev_window (XEvent *ev)
{
        switch (ev->type) {
        case Expose:
    return ev->xexpose.window;
        case MapNotify:
    return ev->xmap.window;
        case UnmapNotify:
    return ev->xunmap.window;
        case ReparentNotify:
    return ev->xreparent.window;
        case CirculateNotify:
    return ev->xcirculate.window;
        default:
            if (ev->type == damage_event + XDamageNotify)
            return ((XDamageNotifyEvent *) ev)->drawable;
    return 0;
        }
}
#endif

void
usage (char *program)
{
        fprintf (stderr, "%s v1.1.3\n", program);
        fprintf (stderr, "usage: %s [options]\n", program);
        fprintf (stderr, "Options\n");
        fprintf (stderr, "     -d display\n            Specifies which display should be managed.\n");
        fprintf (stderr, "     -r radius\n            Specifies the blur radius for client-side shadows. (default 12)\n");
        fprintf (stderr, "     -o opacity\n            Specifies the translucency for client-side shadows. (default .75)\n");
        fprintf (stderr, "     -l left-offset\n            Specifies the left offset for shadows. (default -15)\n");
        fprintf (stderr, "     -t top-offset\n            Specifies the top offset for shadows. (default -15)\n");
        fprintf (stderr, "     -I fade-in-step\n            Specifies the opacity change between steps while fading in. (default 0.028)\n");
        fprintf (stderr, "     -O fade-out-step\n            Specifies the opacity change between steps while fading out. (default 0.03)\n");
        fprintf (stderr, "     -D fade-delta-time\n            Specifies the time between steps in a fade in milliseconds. (default 10)\n");
        fprintf (stderr, "     -m opacity\n            Specifies the opacity for menus. (default 1.0)\n");
        fprintf (stderr, "     -a\n            Use automatic server-side compositing. Faster, but no special effects.\n");
        fprintf (stderr, "     -c\n            Draw client-side shadows with fuzzy edges.\n");
        fprintf (stderr, "     -C\n            Avoid drawing shadows on dock/panel windows.\n");
        fprintf (stderr, "     -f\n            Fade windows in/out when opening/closing.\n");
        fprintf (stderr, "     -F\n            Fade windows during opacity changes.\n");
        fprintf (stderr, "     -n\n            Normal client-side compositing with transparency support\n");
        fprintf (stderr, "     -s\n            Draw server-side shadows with sharp edges.\n");
        fprintf (stderr, "     -S\n            Enable synchronous operation (for debugging).\n");
        exit (1);
}

static void
register_cm (int xcom_scr)
{
        Window w;
        Atom a;
        char *buf;
        int len, s;

        if (xcom_scr < 0) return;

        w = XCreateSimpleWindow (dpy, RootWindow (dpy, 0), 0, 0, 1, 1, 0, None,
                     None);

        Xutf8SetWMProperties (dpy, w, "xcompmgr", "xcompmgr", NULL, 0, NULL, NULL,
                NULL);

        len = strlen(REGISTER_PROP) + 2;
        s = xcom_scr;
        while (s >= 10) {
                ++len;
                s /= 10;
        }
        buf =(char*) malloc(len);
        snprintf(buf, len, REGISTER_PROP"%d", xcom_scr);

        a = XInternAtom (dpy, buf, False);
        free(buf);

        XSetSelectionOwner (dpy, a, w, 0);
}

//xcompmgr end *****************************


int main(int argc, char **argv)
{
    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
    Imlib_Image                 back;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }
    char home[1024];
    gchar *wm_names;
    sprintf(home,"%s",getenv("HOME"));
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }

    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));

     /**
        * Start rendering
        */
//xcompmgr begin***************************
    Window        root_return, parent_return;
    Window        *children;
    unsigned int    nchildren;
    unsigned int            i;
    XRenderPictureAttributes    pa;
    XRectangle        *expose_rects = 0;
    int            size_expose = 0;
    int            n_expose = 0;
    struct pollfd     ufd;
    int            p;
    int            composite_major, composite_minor;
    char        *display = 0;
    Bool            noDockShadow = False;
    dpy = XOpenDisplay (display);
    if (!dpy)
    {
        fprintf (stderr, "Can't open display\n");
        exit (1);
    }
    wm_names=get_wm_name(disp);
    have_error=0;
    if ((strcmp(wm_names,"Compiz")!=0 ) and (strcmp(wm_names,"Mutter")!=0 ))
    {
        for (i = 0; i < NUM_WINTYPES; ++i) {
            winTypeFade[i] = False;
            winTypeShadow[i] = False;
            winTypeOpacity[i] = 1.0;
        }

        /* don't bother to draw a shadow for the desktop */
        winTypeShadow[WINTYPE_DESKTOP] = False;
        
        compMode = CompClientShadows;
        for (i = 0; i < NUM_WINTYPES; ++i)
                winTypeShadow[i] = True;
        winTypeShadow[WINTYPE_DESKTOP] = False;
        shadowRadius = 5;
        shadowOffsetX = -5;
        shadowOffsetY = -5;
        shadowOpacity = 0.55;
        if (noDockShadow)
                winTypeShadow[WINTYPE_DOCK] = False;
        
        XSetErrorHandler (error);
        if (synchronize)
        XSynchronize (dpy, 1);
        xcom_scr = DefaultScreen (dpy);
        xcom_root = RootWindow (dpy, xcom_scr);

        if (!XRenderQueryExtension (dpy, &render_event, &render_error))
        {
            fprintf (stderr, "No render extension\n");
            exit (1);
        }
        if (!XQueryExtension (dpy, COMPOSITE_NAME, &composite_opcode,
                &composite_event, &composite_error))
        {
            fprintf (stderr, "No composite extension\n");
            exit (1);
        }
        XCompositeQueryVersion (dpy, &composite_major, &composite_minor);
#if HAS_NAME_WINDOW_PIXMAP
        if (composite_major > 0 || composite_minor >= 2)
            hasNamePixmap = True;
#endif

        if (!XDamageQueryExtension (dpy, &damage_event, &damage_error))
        {
            fprintf (stderr, "No damage extension\n");
            exit (1);
        }
        if (!XFixesQueryExtension (dpy, &xfixes_event, &xfixes_error))
        {
            fprintf (stderr, "No XFixes extension\n");
            exit (1);
        }

        register_cm(xcom_scr);

        /* get atoms */
        opacityAtom = XInternAtom (dpy, OPACITY_PROP, False);
        winTypeAtom = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE", False);
        winType[WINTYPE_DESKTOP] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_DESKTOP", False);
        winType[WINTYPE_DOCK] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_DOCK", False);
        winType[WINTYPE_TOOLBAR] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_TOOLBAR", False);
        winType[WINTYPE_MENU] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_MENU", False);
        winType[WINTYPE_UTILITY] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_UTILITY", False);
        winType[WINTYPE_SPLASH] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_SPLASH", False);
        winType[WINTYPE_DIALOG] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_DIALOG", False);
        winType[WINTYPE_NORMAL] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_NORMAL", False);
        winType[WINTYPE_DROPDOWN_MENU] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_DROPDOWN_MENU", False);
        winType[WINTYPE_POPUP_MENU] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_POPUP_MENU", False);
        winType[WINTYPE_TOOLTIP] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_TOOLTIP", False);
        winType[WINTYPE_NOTIFY] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_NOTIFICATION", False);
        winType[WINTYPE_COMBO] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_COMBO", False);
        winType[WINTYPE_DND] = XInternAtom (dpy, "_NET_WM_WINDOW_TYPE_DND", False);

        pa.subwindow_mode = IncludeInferiors;

        if (compMode == CompClientShadows)
        {
            gaussianMap = make_gaussian_map(dpy, shadowRadius);
            presum_gaussian (gaussianMap);
        }

        root_width = DisplayWidth (dpy, xcom_scr);
        root_height = DisplayHeight (dpy, xcom_scr);

        rootPicture = XRenderCreatePicture (dpy, xcom_root, 
                    XRenderFindVisualFormat (dpy,
                    DefaultVisual (dpy, xcom_scr)),
                    CPSubwindowMode,
                    &pa);
        blackPicture = solid_picture (dpy, True, 1, 0, 0, 0);
        if (compMode == CompServerShadows)
            transBlackPicture = solid_picture (dpy, True, 0.3, 0, 0, 0);
        allDamage = None;
        clipChanged = True;
        XGrabServer (dpy);
        if (autoRedirect)
            XCompositeRedirectSubwindows (dpy, xcom_root, CompositeRedirectAutomatic);
        else
        {
            XCompositeRedirectSubwindows (dpy, xcom_root, CompositeRedirectManual);
            XSelectInput (dpy, xcom_root, 
                    SubstructureNotifyMask|
                    ExposureMask|
                    StructureNotifyMask|
                    PropertyChangeMask);
            XQueryTree (dpy, xcom_root, &root_return, &parent_return, &children, &nchildren);
            for (i = 0; i < nchildren; i++)
                add_win (dpy, children[i], i ? children[i-1] : None);
            XFree (children);
        }
        XUngrabServer (dpy);
        ufd.fd = ConnectionNumber (dpy);
        ufd.events = POLLIN;
        if (!autoRedirect)
            paint_all (dpy, None);
    }    
//xcompmgr end ***********************************************

//--
//    char back_pic[1280];
//    sprintf(back_pic,"%s/.icon-DE/pics/background.png",home);
    
    char usermenufile[1024];
    char weather_xywh[60];
    char weather_url[1024];
    char command[1024]=" ";
    FILE *freeNum;
    int w_count=0; 
    char w_file[1024];
    char rcfile[10]="desk.rc";
    sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
    if (access(usermenufile,0)==-1)
    {
        system("mkdir ~/.icon-DE");
        system("cp /etc/icon-de/desk.rc ~/.icon-DE/");
    }
    freeNum=fopen(usermenufile,"r");
    if ( freeNum==NULL)
    { 
        printf("error on open %s\n",usermenufile); 
        exit(1); 
    }
    char ch2[1024];
    char buffer_rc[1024];
    int n=0;
    int m=0;
    int centered=0;
    int scaled=1;
    int filled=0;
    int time_for_change=10;
    unsigned int l_id=0;
    while ( ! feof(freeNum) )
    {
        fgets(buffer_rc,1024,freeNum);
        l_id=l_id+1;
        for (n=0;n<1024;n++)
            if (buffer_rc[n]=='\n') buffer_rc[n]='\0';

        if (strcmp(buffer_rc,"")!=0 )
        {
            sprintf(ch2,"%c",buffer_rc[0]);
            if (strcmp(ch2,"#")!=0 ) 
            {
                sprintf(ch2,"%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4]);
                if (strcmp(ch2,"icon:")==0 )
                {
                    for (n=0;n<1019;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+5];
                    } 
                    for (n=1018;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(command,"iconrun4 %s %d &",buffer_rc,l_id);
                    system(command);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
                if (strcmp(ch2,"scaled:")==0 )
                {
                    for (n=0;n<1024-7;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+7];
                    } 
                    for (n=1016;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    scaled=atoi(buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6]);
                if (strcmp(ch2,"filled:")==0 )
                {
                    for (n=0;n<1024-7;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+7];
                    } 
                    for (n=1016;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    filled=atoi(buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8]);
                if (strcmp(ch2,"centered:")==0 )
                {
                    for (n=0;n<1024-9;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+9];
                    } 
                    for (n=1014;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    centered=atoi(buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12],buffer_rc[13],buffer_rc[14],buffer_rc[15]);
                if (strcmp(ch2,"time_for_change:")==0 )
                {
                    for (n=0;n<1024-16;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+16];
                    } 
                    for (n=1007;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    time_for_change=atoi(buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11],buffer_rc[12]);
                if (strcmp(ch2,"weather_xywh:")==0 )
                {
                    for (n=0;n<1024-13;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+13];
                    } 
                    for (n=1010;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(weather_xywh,"%s",buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10],buffer_rc[11]);
                if (strcmp(ch2,"weather_url:")==0 )
                {
                    for (n=0;n<1024-12;n++)
                    {
                         buffer_rc[n]=buffer_rc[n+12];
                    } 
                    for (n=1010;n<1024;n++)
                    {
                         buffer_rc[n]='\0';
                    }
                    sprintf(weather_url,"%s",buffer_rc);
                }    
                sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10]);
                if (strcmp(ch2,"wallpapers:")==0 )
                {
                    w_count=w_count+1;
                }    
            } 
        }
    }
    fclose(freeNum);
    n=0;
    imlib_add_path_to_font_path(".");
    imlib_add_path_to_font_path("/share/feh/fonts");
    disp = XOpenDisplay(NULL);
    if (!disp)
        eprintf("Can't open X display. It *is* running, yeah?");
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
    root = RootWindow(disp, DefaultScreen(disp));
    scr = ScreenOfDisplay(disp, DefaultScreen(disp));
    xid_context = XUniqueContext();

#ifdef HAVE_LIBXINERAMA
    init_xinerama();
#endif                /* HAVE_LIBXINERAMA */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_color_modifier(NULL);
    imlib_context_set_progress_function(NULL);
    imlib_context_set_operation(IMLIB_OP_COPY);
    wmDeleteWindow = XInternAtom(disp, "WM_DELETE_WINDOW", False);

    /* Initialise random numbers */
    srand(getpid() * time(NULL) % ((unsigned int) -1));
    if (w_count>0)
    {
        m=0;
        while (1)
        {
            srand((int)time(0)); 
            i=random(w_count);
            sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
            freeNum=fopen(usermenufile,"r");
            if ( freeNum==NULL)
            { 
                printf("error on open %s\n",usermenufile); 
                exit(1); 
            }
            l_id=0;
            while ( ! feof(freeNum) )
            {
                fgets(buffer_rc,1024,freeNum);
                for (n=0;n<1024;n++)
                    if (buffer_rc[n]=='\n') buffer_rc[n]='\0';

                if (strcmp(buffer_rc,"")!=0 )
                {
                    sprintf(ch2,"%c",buffer_rc[0]);
                    if (strcmp(ch2,"#")!=0 ) 
                    {
                        sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10]);
                        if (strcmp(ch2,"wallpapers:")==0 )
                        {
                            l_id=l_id+1;
                            if (l_id==i)
                            {
                                for (n=0;n<1024-11;n++)
                                {
                                     buffer_rc[n]=buffer_rc[n+11];
                                } 
                                for (n=1011;n<1024;n++)
                                {
                                     buffer_rc[n]='\0';
                                }
                                sprintf(w_file,"%s",buffer_rc);
                            }
                        }    
                    } 
                }
            }
            fclose(freeNum);
            freeNum=fopen(w_file,"r");
            if ( freeNum==NULL)
                printf("error on open %s\n",w_file); 
            else
            {
                fclose(freeNum);
                break;    
            }
            m=m+1;
            if (m>=10 )
                break;
        }
        back = imlib_load_image(w_file);
        feh_wm_set_bg("", back, centered, scaled, filled, 0) ;
    }
    system("killall iconweather 2>/dev/null");
    sprintf(command,"iconweather %s %s %s &",weather_xywh,w_file,weather_url);
    system(command);

    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    long ticks;

//    time_t now_time;
    timeval now, tm,LastTime2;
//    now_time=time(0);

    
    gettimeofday(&LastTime2, 0);


//xcompmge begin*******
    for (;;)
    {
    /*    dump_wins (); */
        if ( (XPending(dpy)) and (QLength (dpy)) and (strcmp(wm_names,"Compiz")!=0 ) and (strcmp(wm_names,"Mutter")!=0 ) and (have_error!=1))
        {
            if (autoRedirect)
                XFlush (dpy);
            if (!QLength (dpy))
            {
                if (poll (&ufd, 1, fade_timeout()) == 0)
                {
                    run_fades (dpy);
                    break;
                 }
            }
            XNextEvent (dpy, &ev);
            if ((ev.type & 0x7f) != KeymapNotify)
                discard_ignore (dpy, ev.xany.serial);
#if DEBUG_EVENTS
            printf ("event %10.10s serial 0x%08x window 0x%08x\n",
            ev_name(&ev), ev_serial (&ev), ev_window (&ev));
#endif
            if (!autoRedirect) switch (ev.type) {
            case CreateNotify:
                add_win (dpy, ev.xcreatewindow.window, 0);
                break;
            case ConfigureNotify:
                configure_win (dpy, &ev.xconfigure);
                break;
            case DestroyNotify:
                destroy_win (dpy, ev.xdestroywindow.window, True);
                break;
            case MapNotify:
                map_win (dpy, ev.xmap.window, ev.xmap.serial, True);
                break;
            case UnmapNotify:
                unmap_win (dpy, ev.xunmap.window, True);
                break;
            case ReparentNotify:
                if (ev.xreparent.parent == xcom_root)
                    add_win (dpy, ev.xreparent.window, 0);
                else
                    destroy_win (dpy, ev.xreparent.window, True);
                break;
            case CirculateNotify:
                circulate_win (dpy, &ev.xcirculate);
                break;
            case Expose:
                if (ev.xexpose.window == xcom_root)
                {
                    int more = ev.xexpose.count + 1;
                    if (n_expose == size_expose)
                    {
                        if (expose_rects)
                        {
                            expose_rects = (XRectangle*)realloc (expose_rects, 
                                (size_expose + more) * 
                                sizeof (XRectangle));
                            size_expose += more;
                        }
                        else
                        {
                            expose_rects = (XRectangle*)malloc (more * sizeof (XRectangle));
                            size_expose = more;
                        }
                    }
                    expose_rects[n_expose].x = ev.xexpose.x;
                    expose_rects[n_expose].y = ev.xexpose.y;
                    expose_rects[n_expose].width = ev.xexpose.width;
                    expose_rects[n_expose].height = ev.xexpose.height;
                    n_expose++;
                    if (ev.xexpose.count == 0)
                    {
                        expose_root (dpy, xcom_root, expose_rects, n_expose);
                        n_expose = 0;
                    }
                }
                break;
            case PropertyNotify:
                for (p = 0; backgroundProps[p]; p++)
                {
                    if (ev.xproperty.atom == XInternAtom (dpy, backgroundProps[p], False))
                    {
                        if (rootTile)
                        {
                            XClearArea (dpy, xcom_root, 0, 0, 0, 0, True);
                            XRenderFreePicture (dpy, rootTile);
                            rootTile = None;
                            break;
                        }
                    }
                }
        /* check if Trans property was changed */
                if (ev.xproperty.atom == opacityAtom)
                {
                /* reset mode and redraw window */
                    xcom_win * w = find_win(dpy, ev.xproperty.window);
                    if (w)
                    {
                        if (fadeTrans)
                            set_fade (dpy, w, w->opacity*1.0/OPAQUE, get_opacity_percent (dpy, w),
                                fade_out_step, 0, True, False);
                        else
                        {
                            w->opacity = get_opacity_prop(dpy, w, OPAQUE);
                            determine_mode(dpy, w);
                            if (w->shadow)
                            {
                                XRenderFreePicture (dpy, w->shadow);
                                w->shadow = None;
                                if (w->extents != None)
                                    XFixesDestroyRegion (dpy, w->extents);

                                                                /* rebuild the shadow */
                                w->extents = win_extents (dpy, w);
                            }
                        }
                    }
                }
                break;
            default:
                if (ev.type == damage_event + XDamageNotify)
                    damage_win (dpy, (XDamageNotifyEvent *) &ev);
                break;
            }
        } else {
            if ((allDamage && !autoRedirect) and (strcmp(wm_names,"Compiz")!=0 ) and (strcmp(wm_names,"Mutter")!=0 ) and (have_error!=1))
            {
                static int    paint;
                paint_all (dpy, allDamage);
                paint++;
                XSync (dpy, False);
                allDamage = None;
                clipChanged = False;
            }
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
            ticks=(now.tv_sec-LastTime2.tv_sec)*1000+(now.tv_usec-LastTime2.tv_usec)/1000;
            if (ticks>=1000*60*time_for_change)
            {
                if (w_count>0)
                {
                    m=0;
                    while (1)
                    {
                        srand((int)time(0)); 
                        i=random(w_count);
                        sprintf(usermenufile,"%s/.icon-DE/%s",home,rcfile);
                        freeNum=fopen(usermenufile,"r");
                        if ( freeNum==NULL)
                        { 
                            printf("error on open %s\n",usermenufile); 
                            exit(1); 
                        }
                        l_id=0;
                        while ( ! feof(freeNum) )
                        {
                            fgets(buffer_rc,1024,freeNum);
                            for (n=0;n<1024;n++)
                                if (buffer_rc[n]=='\n') buffer_rc[n]='\0';

                            if (strcmp(buffer_rc,"")!=0 )
                            {
                                sprintf(ch2,"%c",buffer_rc[0]);
                                if (strcmp(ch2,"#")!=0 ) 
                                {
                                    sprintf(ch2,"%c%c%c%c%c%c%c%c%c%c%c",buffer_rc[0],buffer_rc[1],buffer_rc[2],buffer_rc[3],buffer_rc[4],buffer_rc[5],buffer_rc[6],buffer_rc[7],buffer_rc[8],buffer_rc[9],buffer_rc[10]);
                                    if (strcmp(ch2,"wallpapers:")==0 )
                                    {
                                        l_id=l_id+1;
                                        if (l_id==i)
                                        {
                                            for (n=0;n<1024-11;n++)
                                            {
                                                 buffer_rc[n]=buffer_rc[n+11];
                                            } 
                                            for (n=1011;n<1024;n++)
                                            {
                                                 buffer_rc[n]='\0';
                                            }
                                            sprintf(w_file,"%s",buffer_rc);
                                        }
                                    }    
                                } 
                            }
                        }
                        fclose(freeNum);
                        freeNum=fopen(w_file,"r");
                        if ( freeNum==NULL)
                            printf("error on open %s\n",w_file); 
                        else
                        {
                            fclose(freeNum);
                            break;    
                        }
                        m=m+1;
                        if (m>=10 )
                            break;
                    }
                    back = imlib_load_image(w_file);
                    feh_wm_set_bg("", back, centered, scaled, filled, 0) ;
                }
                system("killall iconweather 2>/dev/null");
                sprintf(command,"iconweather %s %s %s &",weather_xywh,w_file,weather_url);
                system(command);
                gettimeofday(&LastTime2, 0);
            }
            tm.tv_sec=0l;
            tm.tv_usec=20000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        }
    }
}
//xcompmgr end*************

