//g++ -o ./iconrun4 ./iconrun4.c -lImlib2
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <cstdio>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>

using namespace std;

#include "Imlib2.h"

Display                        *disp;
Window                          win;
Window                          win2;
Visual                         *vis;
Colormap                        cm;
int                             depth;
XSetWindowAttributes attr;
char *appToRun;
int mytoggle = 0;
char home[1024];

Atom XA_TARGETS;
Atom XA_multiple;
Atom XA_image_bmp;
Atom XA_image_jpg;
Atom XA_image_tiff;
Atom XA_image_png;
Atom XA_text_uri_list;
Atom XA_text_uri;
Atom XA_text_plain;
Atom XA_text;

Atom XA_XdndSelection;
Atom XA_XdndAware;
Atom XA_XdndEnter;
Atom XA_XdndLeave;
Atom XA_XdndTypeList;
Atom XA_XdndPosition;
Atom XA_XdndActionCopy;
Atom XA_XdndStatus;
Atom XA_XdndDrop;
Atom XA_XdndFinished;


#include "./other_src/find_icon.c"


#define UNAWARE 0
#define UNRECEPTIVE 1
#define CAN_DROP 2

//Utility function for getting the atom name as a string.
string GetAtomName(Display* disp, Atom a)
{
    if(a == None)
        return "None";
    else
        return XGetAtomName(disp, a);
}



//Construct a list of targets and place them in the specified property This
//consists of all datatypes we know of as well as TARGETS and MULTIPLE. Reading
//this property tell the application wishing to paste which datatypes we offer.
void set_targets_property(Display* disp, Window w, map<Atom, string>& typed_data, Atom property)
{

    vector<Atom> targets; targets.push_back(XA_TARGETS);
    targets.push_back(XA_multiple);


    for(map<Atom,string>::const_iterator i=typed_data.begin(); i != typed_data.end(); i++)
        targets.push_back(i->first);

        
//    cout << "Offering: ";
    for(unsigned int i=0; i < targets.size(); i++)
//        cout << GetAtomName(disp, targets[i]) << "  ";
//    cout << endl;

    //Fill up this property with a list of targets.
    XChangeProperty(disp, w, property, XA_ATOM, 32, PropModeReplace, 
                    (unsigned char*)&targets[0], targets.size());
}



//This function essentially performs the paste operation: by converting the
//stored data in to a format acceptable to the destination and replying
//with an acknowledgement.
void process_selection_request(XEvent e, map<Atom, string>& typed_data)
{

    if(e.type != SelectionRequest)
        return;

    //Extract the relavent data
//    Window owner     = e.xselectionrequest.owner;
    Atom selection   = e.xselectionrequest.selection;
    Atom target      = e.xselectionrequest.target;
    Atom property    = e.xselectionrequest.property;
    Window requestor = e.xselectionrequest.requestor;
    Time timestamp   = e.xselectionrequest.time;
    Display* disp    = e.xselection.display;

//    cout << "A selection request has arrived!\n";
//    cout << hex << "Owner = 0x" << owner << endl;
//    cout << "Selection atom = " << GetAtomName(disp, selection) << endl;    
//    cout << "Target atom    = " << GetAtomName(disp, target)    << endl;    
//    cout << "Property atom  = " << GetAtomName(disp, property) << endl;    
//    cout << hex << "Requestor = 0x" << requestor << dec << endl;
//    cout << "Timestamp = " << timestamp << endl;
    

    //X should only send requests for the selections since we own.
    //since we own exaclty one, we don't need to check it.

    //Replies to the application requesting a pasting are XEvenst
    //sent via XSendEvent
    XEvent s;

    //Start by constructing a refusal request.
    s.xselection.type = SelectionNotify;
    //s.xselection.serial     - filled in by server
    //s.xselection.send_event - filled in by server
    //s.xselection.display    - filled in by server
    s.xselection.requestor = requestor;
    s.xselection.selection = selection;
    s.xselection.target    = target;
    s.xselection.property  = None;   //This means refusal
    s.xselection.time      = timestamp;



    if(target ==XA_TARGETS)
    {
//        cout << "Replying with a target list.\n";
        set_targets_property(disp, requestor, typed_data, property);
        s.xselection.property = property;
    }
    else if(typed_data.count(target))
    {
        //We're asked to convert to one the formate we know about
//        cout << "Replying with which ever data I have" << endl;

        //Fill up the property with the URI.
        s.xselection.property = property;
        XChangeProperty(disp, requestor, property, target, 8, PropModeReplace, 
                        reinterpret_cast<const unsigned char*>(typed_data[target].c_str()), typed_data[target].size());
    }
    else if(target == XA_multiple)
    {
        //In this case, the property has been filled up with a list
        //of atom pairs. The pairs being (target, property). The 
        //processing should continue as if whole bunch of
        //SelectionRequest events had been received with the 
        //targets and properties specified.

        //The ICCCM is rather ambiguous and confusing on this particular point,
        //and I've never encountered a program which requests this (I can't 
        //test it), so I haven't implemented it.

//        cout << "MULTIPLE is not implemented. It should be, according to the ICCCM, but\n"
//             << "I've never encountered it, so I can't test it.\n";
    }
    else
    {    
        //We've been asked to converto to something we don't know 
        //about.
//        cout << "No valid conversion. Replying with refusal.\n";
    }
    
    //Reply
    XSendEvent(disp, e.xselectionrequest.requestor, True, 0, &s);
//    cout << endl;
}


//Find the applications top level window under the mouse.
Window find_app_window(Display* disp, Window w)
{
    //Drill down the windows under the mouse, looking for
    //the window with the XdndAware property.

    int nprops, i=0;
    Atom* a;

    if(w == 0)
        return 0;

    //Search for the WM_STATE property
    a = XListProperties(disp, w, &nprops);
    for(i=0; i < nprops; i++)
        if(a[i] == XA_XdndAware)
            break;

    if(nprops)
        XFree(a);

    if(i != nprops)
        return w;
    
    //Drill down one more level.
    Window child, wtmp;
    int tmp;
    unsigned int utmp;
    XQueryPointer(disp, w, &wtmp, &child, &tmp, &tmp, &tmp, &tmp, &utmp);

    return find_app_window(disp, child);
}

void exposelist(void);

int main(int argc, char **argv)
{
     int                                 w, h;
     Imlib_Image                im_bg = NULL;
     XEvent                            ev;
     const char                 *display_name = getenv("DISPLAY");
     Imlib_Font                    font;
     char                                text[4096];
     Imlib_Image                 buffer;
     Imlib_Image                 back;
//     Imlib_Image                 bigback;
     Imlib_Color_Range     range;
     int hide=0;
     int    text_w, text_h;

     if (display_name == NULL)
             display_name = ":0";
     disp = XOpenDisplay(display_name);
     if (disp == NULL)
         {
             fprintf(stderr, "Can't open display %s\n", display_name);
             return 1;
         }
    sprintf(home,"%s",getenv("HOME"));

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=64;
    int screenHeight;
    screenHeight=64;
    int screenX=10;
    int screenY=10;
    char *picname;
    char *title;
    int l_id;
    int i;
//----arguments x y width height lower/raise(0/1) picture appToRun
    if ( argc == 1 ){
        printf("usage: iconrun4 x y width height image applicationToRun tag l_id\n");
        return 1;
    }
    if ( argc != 9 ){
        return 1;
    }

    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    picname = argv[5];
    appToRun = argv[6];
    title = argv[7];
    sscanf(argv[8], "%d", &l_id);

    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
                         /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
                         /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);


    attr.override_redirect=True;
 
//win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,CopyFromParent,InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask|CWBorderPixel|CWSaveUnder|CWColormap|CWBackPixel,&attr);
    win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);


//     win =    XCreateSimpleWindow(disp, DefaultRootWindow(disp), 0, 0, 100, 100, 0, 0, 0);

    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);

    XMapWindow(disp, win);
    XRaiseWindow(disp,win);

     /**
        * Start rendering
        */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
    w=screenWidth;
    h=screenHeight;
    char back_pic[1280];
    sprintf(back_pic,"%s/.icon-DE/pics/desk_icon_back.png",home);
    if (access(back_pic,0)==-1)
        sprintf(back_pic,"/usr/share/icon-DE/pics/desk_icon_back.png");
    back = imlib_load_image(back_pic);
    imlib_context_set_image(back);
    buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);

    im_bg = imlib_load_image(find_icon_file(picname));
    if (im_bg == NULL)
        im_bg = imlib_load_image("/usr/share/icon-DE/iconcache/face-smile.png");


    imlib_context_set_image(im_bg);
    int is=imlib_image_get_width();
    int ih=imlib_image_get_height();
    int d1=screenWidth-is;
    d1=d1/2;
    int d2=screenHeight-ih;
    d2=d2/2;


    imlib_context_set_image(im_bg);
    imlib_context_set_blend(1);

    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);
    imlib_render_image_on_drawable_at_size(d1-1, d2-1,is+2,ih+2);
//    bigback=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);

    imlib_render_image_on_drawable(d1, d2);
//    back=imlib_create_image_from_drawable( 0,0,0,w,h,1);
    char font_path[1024];
    sprintf(font_path,"%s/.icon-DE/fonts",home);
    imlib_add_path_to_font_path(font_path);
    imlib_add_path_to_font_path("/usr/share/fonts/truetype/wqy/");
    imlib_add_path_to_font_path("/usr/share/fonts/wenquanyi/wqy-zenhei/");
    font = imlib_load_font("Vera/8");
    if (font == NULL)
        font = imlib_load_font("wqy-zenhei.ttc/8");
    imlib_context_set_font(font);
    imlib_context_set_color(0, 0, 0, 255);
    sprintf(text,"%s",title);
    imlib_get_text_size(text, &text_w, &text_h);
    buffer = imlib_create_image(text_w*2, text_h*2);    

    attr.override_redirect=True;
 
    win2=XCreateWindow(disp,win,0,0,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
    XMapWindow(disp, win2);
//    XRaiseWindow(disp,win2);
    imlib_context_set_drawable(win2); 
     
    //                     imlib_context_set_image(buffer);

                         /* draw the range */
    imlib_context_set_image(buffer);
    imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,
                                                                                                     -45.0);
                         /* free it */
                //         imlib_free_color_range();

    imlib_context_set_image(buffer);
    
    imlib_render_image_on_drawable(0, 0); 


    imlib_context_set_image(buffer);
    imlib_context_set_font(font);
    imlib_context_set_color(0, 0, 0, 255);
    imlib_text_draw(5,2,text);

                         /* set the buffer image as our current image */
    imlib_context_set_image(buffer);

    imlib_context_set_drawable(win2); 
    imlib_render_image_on_drawable(0, 0); 


    imlib_context_set_image(buffer);
    imlib_free_image();
    imlib_context_set_font(font);
    imlib_free_font();

    imlib_context_set_image(im_bg);
    imlib_context_set_drawable(win);

    XResizeWindow(disp, win, w, h);
    XSync(disp, False);
    
    
//    Atom selection  = XA_PRIMARY;
    XA_TARGETS = XInternAtom(disp, "TARGETS", False);
    XA_multiple = XInternAtom(disp, "MULTIPLE", False);
    XA_image_bmp = XInternAtom(disp, "image/bmp", False);
    XA_image_jpg = XInternAtom(disp, "image/jpeg", False);
    XA_image_tiff = XInternAtom(disp, "image/tiff", False);
    XA_image_png = XInternAtom(disp, "image/png", False);
    XA_text_uri_list = XInternAtom(disp, "text/uri-list", False);
    XA_text_uri= XInternAtom(disp, "text/uri", False);
    XA_text_plain = XInternAtom(disp, "text/plain", False);
    XA_text = XInternAtom(disp, "TEXT", False);
    XA_XdndSelection = XInternAtom(disp, "XdndSelection", False);
    XA_XdndAware = XInternAtom(disp, "XdndAware", False);
    XA_XdndEnter = XInternAtom(disp, "XdndEnter", False);
    XA_XdndLeave = XInternAtom(disp, "XdndLeave", False);
    XA_XdndTypeList = XInternAtom(disp, "XdndTypeList", False);
    XA_XdndPosition = XInternAtom(disp, "XdndPosition", False);
    XA_XdndActionCopy = XInternAtom(disp, "XdndActionCopy", False);
    XA_XdndStatus = XInternAtom(disp, "XdndStatus", False);
    XA_XdndDrop = XInternAtom(disp, "XdndDrop", False);
    XA_XdndFinished = XInternAtom(disp, "XdndFinished", False);
    map<Atom, string> typed_data; string url;
    
/*    typed_data[XA_image_bmp] = read_whole_file("r0x0r.bmp", url);
    typed_data[XA_image_jpg] = read_whole_file("r0x0r.jpg", url);
    typed_data[XA_image_tiff] = read_whole_file("r0x0r.tiff", url);
    typed_data[XA_image_png] = read_whole_file("r0x0r.png", url);
*/
    url = "file://" + url;

    typed_data[XA_text_uri_list] = url;
    typed_data[XA_text_uri] = url;
    typed_data[XA_text_plain] = url;
    typed_data[XA_text] = url;
    typed_data[XA_STRING] = url;

    set_targets_property(disp, win, typed_data, XA_XdndTypeList);

    XFlush(disp);
    
    int dragging=0;                   //Are we currently dragging
    Window previous_window=0;          //Window found by the last MotionNotify event.
    int previous_version = -1;         //XDnD version of previous_window
    int status=UNAWARE;               
    Window root=RootWindow(disp, screen);
    int have_press=0;
    int have_release=0;

    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    long ticks;
    long ticks2;
//    Atom prop;

//    time_t now_time;
    struct timeval now, tm,LastTime,LastTime2;
//    now_time=time(0);
    gettimeofday(&LastTime, 0);
    gettimeofday(&LastTime2, 0);
    int s_ch=0;

    Cursor grab_bad =XCreateFontCursor(disp, XC_gobbler);
    Cursor grab_maybe =XCreateFontCursor(disp, XC_circle);
    Cursor grab_good =XCreateFontCursor(disp, XC_sb_down_arrow);

    while (1)
    {
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case SelectionClear:
//                cout  << "SelectionClear event received. Quitting.\n";
                break;
            case SelectionRequest:
                process_selection_request(ev, typed_data);
                break;
            case MotionNotify:
                if (dragging == 1)
                {
                    Window window=0;
//                    Atom atmp;
                    int version=-1;
//                    int fmt;
//                    unsigned long nitems, bytes_remaining;
                    unsigned char *data = 0;
                    window = find_app_window(disp, root);
                    if(window == previous_window)
                        version = previous_version;
                    else
                    {
                        version = data[0];
                    }

                    if(status == UNAWARE && version != -1)
                        status = UNRECEPTIVE;
                    else if(version == -1)
                        status = UNAWARE;
                    if(status == UNAWARE)
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_bad, CurrentTime);
                    else if(status == UNRECEPTIVE)
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_maybe, CurrentTime);
                    else
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_good, CurrentTime);

                    

                    if(window != previous_window && previous_version != -1)
                    {
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = previous_window;
                        m.message_type = XA_XdndLeave;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = 0;
                        m.data.l[2] = 0;
                        m.data.l[3] = 0;
                        m.data.l[4] = 0;

                        XSendEvent(disp, previous_window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);
                    }

                    if(window != previous_window && version != -1)
                    {    
                        map<Atom, string>::const_iterator i = typed_data.begin();

                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = window;
                        m.message_type = XA_XdndEnter;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = min(5, version) << 24  |  (typed_data.size() > 3);
                        m.data.l[2] = typed_data.size() > 0 ? i++->first : 0;
                        m.data.l[3] = typed_data.size() > 1 ? i++->first : 0;
                        m.data.l[4] = typed_data.size() > 2 ? i->first : 0;

                        XSendEvent(disp, window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);
                    }

                    if(version != -1)
                    {
                        //Send an XdndPosition event.
                        //
                        // We're being abusive, and ignoring the 
                        // rectangle of silence.


                        int x, y, tmp;
                        unsigned int utmp;
                        Window wtmp;

                        XQueryPointer(disp, window, &wtmp, &wtmp, &tmp, &tmp, &x, &y, &utmp);


                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = window;
                        m.message_type = XA_XdndPosition;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = 0;
                        m.data.l[2] = (x <<16) | y;
                        m.data.l[3] = CurrentTime; //Our data is not time dependent, so send a generic timestamp;
                        m.data.l[4] = XA_XdndActionCopy;

//                        cerr << "Sending XdndPosition" << endl
//                             << "    x      = " << x << endl
//                             << "    y      = " << y << endl
//                             << "    Time   = " << m.data.l[3] << endl
//                             << "    Action = " << GetAtomName(disp, m.data.l[4]) << endl;

                        XSendEvent(disp, window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);

                    }

                    previous_window = window;    
                    previous_version = version;
//                    cout << endl;
                    Window        QueryRoot, QueryChild;
                    int           AbsoluteX, AbsoluteY;
                    int           RelativeX, RelativeY;
                    unsigned int    ModKeyMask;
                    
                    XQueryPointer(disp, root,
                        &QueryRoot, &QueryChild,
                        &AbsoluteX, &AbsoluteY,
                        &RelativeX, &RelativeY,
                        &ModKeyMask);
                    XMoveWindow(disp,win,AbsoluteX-10 , AbsoluteY-10);
                    if (AbsoluteX<=5)
                    {
                        screenX=0;
                        screenY=AbsoluteY;
                    }
                    else if (AbsoluteX<screenWidth)
                    {
                        screenX=AbsoluteX-(int)(screenWidth/3);
                        screenY=AbsoluteY;
                    }
                    else
                    {
                        screenX=AbsoluteX;
                        screenY=AbsoluteY;
                    }
                    
                }
                break;
            case LeaveNotify:		
                break;
            case ButtonPress:
                if(ev.xbutton.button==1)
                {
                    gettimeofday(&LastTime, 0);
                    have_press=1;
                    have_release=0;
                    dragging=0;
                }
                break;
            case ButtonRelease:
                if(ev.xbutton.button==1)
                {
                    if (dragging==1)
                    {
//                      cout << "Mouse button was released.\n";


                        if(status == CAN_DROP)
                        {
//                          cout << "Perform drop:\n";

                            XClientMessageEvent m;
                            memset(&m, sizeof(m), 0);
                            m.type = ClientMessage;
                            m.display = ev.xclient.display;
                            m.window = previous_window;
                            m.message_type = XA_XdndDrop;
                            m.format=32;
                            m.data.l[0] = win;
                            m.data.l[1] = 0;
                            m.data.l[2] = CurrentTime; //Our data is not time dependent, so send a generic timestamp;
                            m.data.l[3] = 0;
                            m.data.l[4] = 0;

                            XSendEvent(disp, previous_window, False, NoEventMask, (XEvent*)&m);
                            XFlush(disp);
                        }
                        XUngrabPointer(disp, CurrentTime);
                        dragging=0;
                        status=UNAWARE;
                        previous_window=None;
                        previous_version=-1;
//                        cout << endl;
                        char submenue[1024];
                        char c_cmd[1024];
                        char f_buffer[4096];
//                        int l_end;
                        FILE * fp=NULL;
                        FILE * fp2=NULL;
//                        int g_id;
                        sprintf(submenue,"%s/.icon-DE/desk.rc",home);
                        if (access(submenue,0)!=-1)
                        {
                            
                            sprintf(c_cmd,"cp -f %s %s~",submenue,submenue);
                            printf("%s\n",c_cmd);
                            system(c_cmd);
                            sprintf(submenue,"%s/.icon-DE/desk.rc~",home);
                            fp=fopen(submenue,"r");
                            sprintf(c_cmd,"icon:%d %d %d %d %s %s %s\n",screenX,screenY,screenWidth,screenHeight,picname,appToRun,title);
                            printf("icon:%d %d %d %d %s %s %s\n",screenX,screenY,screenWidth,screenHeight,picname,appToRun,title);

                            if (fp==NULL)
                            {
                                printf("not open 1\n");
                            }
                            else
                            {
                                sprintf(submenue,"%s/.icon-DE/desk.rc",home);
                                fp2=fopen(submenue,"w");
                                i=0;
                                while ( ! feof(fp) )
                                {
                                    if (i==l_id)
                                        fputs(c_cmd,fp2);
                                    else
                                        fputs(f_buffer,fp2);
                                    fgets(f_buffer,4096,fp);
                                    i=i+1;
                                    printf("%s",f_buffer);
                                }
                            }
                            fclose(fp);
                            fclose(fp2);
                        }
                        /* if we click anywhere in the window, exit */
                    }
                    else
                        exposelist();
                    have_release=1;
                    have_press=0;
                }
                break;
            case ClientMessage:
                if (ev.xclient.message_type == XA_XdndStatus)
                {
                cout  << "XDnDStatus event received:" << endl
                      << "    Target window           = 0x" << hex << ev.xclient.data.l[0] << dec << endl
                      << "    Will accept             = " << (ev.xclient.data.l[1] & 1)  << endl
                      << "    No rectangle of silence = " << (ev.xclient.data.l[1] & 2)  << endl
                      << "    Rectangle of silence x  = " << (ev.xclient.data.l[2] >> 16)    << endl
                      << "    Rectangle of silence y  = " << (ev.xclient.data.l[2] & 0xffff)    << endl
                      << "    Rectangle of silence w  = " << (ev.xclient.data.l[3] >> 16)    << endl
                      << "    Rectangle of silence h  = " << (ev.xclient.data.l[3] & 0xffff)    << endl
                      << "    Action                  = " << GetAtomName(disp, ev.xclient.data.l[4]) << endl;

                
                if( (ev.xclient.data.l[1] & 1) == 0 &&  ev.xclient.data.l[4] != None)
                {
                    cout << "Action is given, even though the target won't accept a drop.\n";
                }


                if(dragging)
                {
                    if((ev.xclient.data.l[1]&1) && status != UNAWARE)
                        status = CAN_DROP;

                    if(!(ev.xclient.data.l[1]&1) && status != UNAWARE)
                        status = UNRECEPTIVE;
                }

                if(!dragging)
                    cout << "Message received, but dragging is not active!\n";

                if(status == UNAWARE)
                    cout << "Message received, but we're not in an aware window!\n";

                cout << endl;
                }
                else if( ev.xclient.message_type == XA_XdndFinished)
                {
                    //Check for these messages. Since out data is static, we don't need to do anything.
                    cout  << "XDnDFinished event received:" << endl
                          << "    Target window           = 0x" << hex << ev.xclient.data.l[0] << dec << endl
                          << "    Was successful          = " << (ev.xclient.data.l[1] & 1)  << endl
                          << "    Action                  = " << GetAtomName(disp, ev.xclient.data.l[2]) << endl;
                    
                    cout  << "No action performed.\n\n";
                }
                
                break;
            case EnterNotify:
                if ((hide==1) and (dragging==0))
                {
                    XMoveResizeWindow(disp, win, screenX, screenY, screenWidth, screenHeight);
                    hide=0;
                }    
                break;
            case Expose:
                s_ch=1;
                break;
            default:
                break;
            }
        } else {
                //display 是由 XopenDisplay 返回的 Display *
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
            if (s_ch==1)
            {
                w=screenWidth;
                h=screenHeight;
                imlib_context_set_image(back);
                buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);

                im_bg = imlib_load_image(find_icon_file(picname));
                if (im_bg == NULL)
                    im_bg = imlib_load_image("/usr/share/icon-DE/iconcache/face-smile.png");


                imlib_context_set_image(im_bg);
                is=imlib_image_get_width();
                ih=imlib_image_get_height();
                d1=screenWidth-is;
                d1=d1/2;
                d2=screenHeight-ih;
                d2=d2/2;


                imlib_context_set_image(im_bg);
                imlib_context_set_blend(1);

                imlib_context_set_image(back);
                imlib_render_image_on_drawable(0, 0);
                imlib_context_set_image(im_bg);
                imlib_render_image_on_drawable_at_size(d1-1, d2-1,is+2,ih+2);
//                bigback=imlib_create_image_from_drawable( 0,0,0,w,h,1);

                imlib_context_set_image(back);
                imlib_render_image_on_drawable(0, 0);
                imlib_context_set_image(im_bg);

                imlib_render_image_on_drawable(d1, d2);
//                back=imlib_create_image_from_drawable( 0,0,0,w,h,1);

                font = imlib_load_font("Vera/8");
                if (font == NULL)
                    font = imlib_load_font("wqy-zenhei.ttc/8");
                imlib_context_set_font(font);
                imlib_context_set_color(0, 0, 0, 255);
                sprintf(text,"%s",title);
                imlib_get_text_size(text, &text_w, &text_h);
                buffer = imlib_create_image(text_w*2, text_h*2);                

                attr.override_redirect=True;
 
//                win2=XCreateWindow(disp,win,0,0,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
//                XMapWindow(disp, win2);
//                XRaiseWindow(disp,win2);
                imlib_context_set_drawable(win2); 
                 
                //                                                                     imlib_context_set_image(buffer);

                                     /* draw the range */
                imlib_context_set_image(buffer);
                imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,
                                                                                                                 -45.0);
                         /* free it */
                //         imlib_free_color_range();

                imlib_context_set_image(buffer);
                
                imlib_render_image_on_drawable(0, 0); 


                imlib_context_set_image(buffer);
                imlib_context_set_font(font);
                imlib_context_set_color(0, 0, 0, 255);
                imlib_text_draw(5,2,text);

                                                 /* set the buffer image as our current image */
                imlib_context_set_image(buffer);

                imlib_context_set_drawable(win2); 
                imlib_render_image_on_drawable(0, 0); 


                imlib_context_set_image(buffer);
                imlib_free_image();
                imlib_context_set_font(font);
                imlib_free_font();

                imlib_context_set_image(im_bg);
                imlib_context_set_drawable(win);

//                XResizeWindow(disp, win, w, h);
                XRaiseWindow(disp,win);
                XSync(disp, False);
                s_ch=0;
            }

//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=1000)
            {
                if ((have_press==1) and (have_release==0))
                {
                    if(XGrabPointer(disp, win, True, Button1MotionMask | ButtonReleaseMask, GrabModeAsync, GrabModeAsync, root, grab_good, CurrentTime) == GrabSuccess)
                    {
                        dragging=1;
                        printf("dragging\n");
                        XSetSelectionOwner(disp, XA_XdndSelection, win, CurrentTime);
                    }    
                }
                else
                    dragging=0;
                gettimeofday(&LastTime, 0);
            }
            ticks2=(now.tv_sec-LastTime2.tv_sec)*1000+(now.tv_usec-LastTime2.tv_usec)/1000;
            if ((ticks2>=10000) and (hide==0))
            {
                if (dragging==0)
                {
                    hide=1;
                    XMoveResizeWindow(disp, win, 0, 0, 10, 10);
                }
                gettimeofday(&LastTime2, 0);
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=100000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        } /* End else*/
    }
    return 0;
}

void exposelist(void){
    //printf("exposelist\n");
    char app[2000];
    sprintf(app,"%s &",appToRun);
    system(app);
}
