// g++ -o ./iconrun3 ./iconrun3.c    -lImlib2 -lX11 -lXmu `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <map>
#include <vector>
#include <cstdio>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include <X11/Xmu/WinUtil.h>
#include <X11/cursorfont.h>
#include <glib-2.0/glib.h>

using namespace std;

#include "Imlib2.h"


Display                        *disp;
Window                            win,win4;
Window                            win2;
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
char *appToRun;
int mytoggle = 0;
int bord=0;
double trans_wind=0.85;
char *title;
char *skip;
char home[1024];

Atom XA_TARGETS;
Atom XA_multiple;
Atom XA_image_bmp;
Atom XA_image_jpg;
Atom XA_image_tiff;
Atom XA_image_png;
Atom XA_text_uri_list;
Atom XA_text_uri;
Atom XA_text_plain;
Atom XA_text;

Atom XA_XdndSelection;
Atom XA_XdndAware;
Atom XA_XdndEnter;
Atom XA_XdndLeave;
Atom XA_XdndTypeList;
Atom XA_XdndPosition;
Atom XA_XdndActionCopy;
Atom XA_XdndStatus;
Atom XA_XdndDrop;
Atom XA_XdndFinished;

#include "./other_src/wm_ctrl.c"
#include "./other_src/find_icon.c"

#define UNAWARE 0
#define UNRECEPTIVE 1
#define CAN_DROP 2

//Utility function for getting the atom name as a string.
string GetAtomName(Display* disp, Atom a)
{
    if(a == None)
        return "None";
    else
        return XGetAtomName(disp, a);
}



//Construct a list of targets and place them in the specified property This
//consists of all datatypes we know of as well as TARGETS and MULTIPLE. Reading
//this property tell the application wishing to paste which datatypes we offer.
void set_targets_property(Display* disp, Window w, map<Atom, string>& typed_data, Atom property)
{

    vector<Atom> targets; targets.push_back(XA_TARGETS);
    targets.push_back(XA_multiple);


    for(map<Atom,string>::const_iterator i=typed_data.begin(); i != typed_data.end(); i++)
        targets.push_back(i->first);

        
//    cout << "Offering: ";
    for(unsigned int i=0; i < targets.size(); i++)
//        cout << GetAtomName(disp, targets[i]) << "  ";
//    cout << endl;

    //Fill up this property with a list of targets.
    XChangeProperty(disp, w, property, XA_ATOM, 32, PropModeReplace, 
                    (unsigned char*)&targets[0], targets.size());
}



//This function essentially performs the paste operation: by converting the
//stored data in to a format acceptable to the destination and replying
//with an acknowledgement.
void process_selection_request(XEvent e, map<Atom, string>& typed_data)
{

    if(e.type != SelectionRequest)
        return;

    //Extract the relavent data
//    Window owner     = e.xselectionrequest.owner;
    Atom selection   = e.xselectionrequest.selection;
    Atom target      = e.xselectionrequest.target;
    Atom property    = e.xselectionrequest.property;
    Window requestor = e.xselectionrequest.requestor;
    Time timestamp   = e.xselectionrequest.time;
    Display* disp    = e.xselection.display;

//    cout << "A selection request has arrived!\n";
//    cout << hex << "Owner = 0x" << owner << endl;
//    cout << "Selection atom = " << GetAtomName(disp, selection) << endl;    
//    cout << "Target atom    = " << GetAtomName(disp, target)    << endl;    
//    cout << "Property atom  = " << GetAtomName(disp, property) << endl;    
//    cout << hex << "Requestor = 0x" << requestor << dec << endl;
//    cout << "Timestamp = " << timestamp << endl;
    

    //X should only send requests for the selections since we own.
    //since we own exaclty one, we don't need to check it.

    //Replies to the application requesting a pasting are XEvenst
    //sent via XSendEvent
    XEvent s;

    //Start by constructing a refusal request.
    s.xselection.type = SelectionNotify;
    //s.xselection.serial     - filled in by server
    //s.xselection.send_event - filled in by server
    //s.xselection.display    - filled in by server
    s.xselection.requestor = requestor;
    s.xselection.selection = selection;
    s.xselection.target    = target;
    s.xselection.property  = None;   //This means refusal
    s.xselection.time      = timestamp;



    if(target ==XA_TARGETS)
    {
//        cout << "Replying with a target list.\n";
        set_targets_property(disp, requestor, typed_data, property);
        s.xselection.property = property;
    }
    else if(typed_data.count(target))
    {
        //We're asked to convert to one the formate we know about
//        cout << "Replying with which ever data I have" << endl;

        //Fill up the property with the URI.
        s.xselection.property = property;
        XChangeProperty(disp, requestor, property, target, 8, PropModeReplace, 
                        reinterpret_cast<const unsigned char*>(typed_data[target].c_str()), typed_data[target].size());
    }
    else if(target == XA_multiple)
    {
        //In this case, the property has been filled up with a list
        //of atom pairs. The pairs being (target, property). The 
        //processing should continue as if whole bunch of
        //SelectionRequest events had been received with the 
        //targets and properties specified.

        //The ICCCM is rather ambiguous and confusing on this particular point,
        //and I've never encountered a program which requests this (I can't 
        //test it), so I haven't implemented it.

//        cout << "MULTIPLE is not implemented. It should be, according to the ICCCM, but\n"
//             << "I've never encountered it, so I can't test it.\n";
    }
    else
    {    
        //We've been asked to converto to something we don't know 
        //about.
//        cout << "No valid conversion. Replying with refusal.\n";
    }
    
    //Reply
    XSendEvent(disp, e.xselectionrequest.requestor, True, 0, &s);
//    cout << endl;
}


//Find the applications top level window under the mouse.
Window find_app_window(Display* disp, Window w)
{
    //Drill down the windows under the mouse, looking for
    //the window with the XdndAware property.

    int nprops, i=0;
    Atom* a;

    if(w == 0)
        return 0;

    //Search for the WM_STATE property
    a = XListProperties(disp, w, &nprops);
    for(i=0; i < nprops; i++)
        if(a[i] == XA_XdndAware)
            break;

    if(nprops)
        XFree(a);

    if(i != nprops)
        return w;
    
    //Drill down one more level.
    Window child, wtmp;
    int tmp;
    unsigned int utmp;
    XQueryPointer(disp, w, &wtmp, &child, &tmp, &tmp, &tmp, &tmp, &utmp);

    return find_app_window(disp, child);
}

void exposelist(void);

int main(int argc, char **argv)
{
    int                                 w, h, x, y;
    Imlib_Image                im_bg = NULL;
    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
    Imlib_Font                    font;
    char                                text[4096];
    char *skip;
    Imlib_Image                 buffer,buffer4;
    Imlib_Image                 back;
    Imlib_Image                 bigback;
    Imlib_Color_Range     range;
    int    text_w, text_h;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=64;
    int screenHeight;
    screenHeight=64;
    int screenX=10;
    int screenY=10;
    int lowerraise=0;
    char *picname;
    char *tag;
    int xl=0;
    int yl=0;
    int mytoggle = 0;
    int MouseMoveOpenSubIcon=0;
    char *win_move;

    double trans_icon=0.65;
    unsigned long l_id;
    
    sprintf(home,"%s",getenv("HOME"));
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
    
    char submenue[1000];
    Window                            cur_win_id;

//----arguments x y width height lower/raise(0/1) picture appToRun
    if ( argc == 1 ){
        printf("usage: iconrun3 x y width height lower/raise(0/1) MouseMoveOpenSubIcon(0/1) image applicationToRun tag title windows_class_for_skip    windows_move_to(x,y,w,h) no_title(0/1) trans_icon trans_wind l_id\n");
        return 1;
    }
    if ( argc != 17 ){
        return 1;
    }
    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    sscanf(argv[5], "%d", &lowerraise);
    sscanf(argv[6], "%d", &MouseMoveOpenSubIcon);
    picname = argv[7];
    appToRun = argv[8];
    tag = argv[9];
    title = argv[10];
    skip = argv[11];
    win_move=argv[12];
    sscanf(argv[13], "%d", &bord);
    trans_icon = atof (argv[14]);
    trans_wind = atof (argv[15]);
    sscanf(argv[16], "%ld", &l_id);
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);

    attr.override_redirect=True;
 //win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,CopyFromParent,InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask|CWBorderPixel|CWSaveUnder|CWColormap|CWBackPixel,&attr);
    win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth,screenHeight,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
//     win =    XCreateSimpleWindow(disp, DefaultRootWindow(disp), 0, 0, 100, 100, 0, 0, 0);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    if(lowerraise==0)
        XLowerWindow(disp,win);
    if(lowerraise==1)
        XRaiseWindow(disp,win);
    trans(trans_icon,win);
     /**
        * Start rendering
        */
    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
    w=screenWidth;
    h=screenHeight;
    char back_pic[1280],mouse_pic[1280];
    sprintf(back_pic,"%s/.icon-DE/pics/background.png",home);
    if (access(back_pic,0)==-1)
        sprintf(back_pic,"/usr/share/icon-DE/pics/background.png");
    back = imlib_load_image(back_pic);
    imlib_context_set_image(back);
    buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);
    im_bg = imlib_load_image(find_icon_file(picname));
    if (im_bg == NULL)
        im_bg = imlib_load_image("/usr/share/icon-DE/iconcache/face-smile.png");
    XMapWindow(disp, win);
    imlib_context_set_image(im_bg);

    int is=imlib_image_get_width();
    int ih=imlib_image_get_height();
    int d1=screenWidth-is;
    d1=d1/2;
    int d2=screenHeight-ih;
    d2=d2/2;
    imlib_context_set_image(im_bg);
    imlib_context_set_blend(1);
    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);
    imlib_render_image_on_drawable_at_size(d1-1, d2-1,is+2,ih+2);
    bigback=imlib_create_image_from_drawable( 0,0,0,w,h,1);
    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    imlib_context_set_image(im_bg);
    imlib_render_image_on_drawable(d1, d2);
    back=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    char font_path[1024];
    sprintf(font_path,"%s/.icon-DE/fonts",home);
    imlib_add_path_to_font_path(font_path);
    imlib_add_path_to_font_path("/usr/share/fonts/truetype/wqy/");
    imlib_add_path_to_font_path("/usr/share/fonts/wenquanyi/wqy-zenhei/");

    XResizeWindow(disp, win, w, h);
    XSync(disp, False);
    x = -9999;
    y = -9999;
    x = -screenWidth/2;
    y = -screenHeight/2;
    int can_close,cur_times;
    unsigned long i;
    can_close=0;
    cur_times=0;
    int tra=0;
    
    
//    Atom selection  = XA_PRIMARY;
    XA_TARGETS = XInternAtom(disp, "TARGETS", False);
    XA_multiple = XInternAtom(disp, "MULTIPLE", False);
    XA_image_bmp = XInternAtom(disp, "image/bmp", False);
    XA_image_jpg = XInternAtom(disp, "image/jpeg", False);
    XA_image_tiff = XInternAtom(disp, "image/tiff", False);
    XA_image_png = XInternAtom(disp, "image/png", False);
    XA_text_uri_list = XInternAtom(disp, "text/uri-list", False);
    XA_text_uri= XInternAtom(disp, "text/uri", False);
    XA_text_plain = XInternAtom(disp, "text/plain", False);
    XA_text = XInternAtom(disp, "TEXT", False);
    XA_XdndSelection = XInternAtom(disp, "XdndSelection", False);
    XA_XdndAware = XInternAtom(disp, "XdndAware", False);
    XA_XdndEnter = XInternAtom(disp, "XdndEnter", False);
    XA_XdndLeave = XInternAtom(disp, "XdndLeave", False);
    XA_XdndTypeList = XInternAtom(disp, "XdndTypeList", False);
    XA_XdndPosition = XInternAtom(disp, "XdndPosition", False);
    XA_XdndActionCopy = XInternAtom(disp, "XdndActionCopy", False);
    XA_XdndStatus = XInternAtom(disp, "XdndStatus", False);
    XA_XdndDrop = XInternAtom(disp, "XdndDrop", False);
    XA_XdndFinished = XInternAtom(disp, "XdndFinished", False);
    map<Atom, string> typed_data; string url;
    
/*    typed_data[XA_image_bmp] = read_whole_file("r0x0r.bmp", url);
    typed_data[XA_image_jpg] = read_whole_file("r0x0r.jpg", url);
    typed_data[XA_image_tiff] = read_whole_file("r0x0r.tiff", url);
    typed_data[XA_image_png] = read_whole_file("r0x0r.png", url);
*/
    url = "file://" + url;

    typed_data[XA_text_uri_list] = url;
    typed_data[XA_text_uri] = url;
    typed_data[XA_text_plain] = url;
    typed_data[XA_text] = url;
    typed_data[XA_STRING] = url;

    set_targets_property(disp, win, typed_data, XA_XdndTypeList);

    XFlush(disp);
    
    bool dragging=0,m_mouse=0;                   //Are we currently dragging
    Window previous_window=0;          //Window found by the last MotionNotify event.
    int previous_version = -1;         //XDnD version of previous_window
    int status=UNAWARE;               
    Window root=RootWindow(disp, screen);
    int have_press=0;
    int have_release=0;
    int m_button=0;

    int xfd = ConnectionNumber(disp);
    long ticks;
    fd_set rfds;
//    time_t now_time;
    struct timeval now, tm,LastTime;
//    now_time=time(0);

    Cursor grab_bad =XCreateFontCursor(disp, XC_gobbler);
    Cursor grab_maybe =XCreateFontCursor(disp, XC_circle);
    Cursor grab_good =XCreateFontCursor(disp, XC_sb_down_arrow);
    int o_x=screenX;
    int o_y=screenY;
    int fx;

    while (1)
    {
        Imlib_Image                temp, temp2;
        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case SelectionClear:
//                cout  << "SelectionClear event received. Quitting.\n";
                break;
            case SelectionRequest:
                process_selection_request(ev, typed_data);
                break;
            case MotionNotify:
                if (dragging == 1)
                {
                    Window window=0;
                    int version=-1;
//                    unsigned char *data = 0;
                    window = find_app_window(disp, root);
                    if(window == previous_window)
                        version = previous_version;
//                    else
//                    {
//                        version = data[0];
//                    }
                    if(status == UNAWARE && version != -1)
                        status = UNRECEPTIVE;
                    else if(version == -1)
                        status = UNAWARE;
                    //Update the pointer state.
                    if(status == UNAWARE)
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_bad, CurrentTime);
                    else if(status == UNRECEPTIVE)
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_maybe, CurrentTime);
                    else
                        XChangeActivePointerGrab(disp, Button1MotionMask | ButtonReleaseMask, grab_good, CurrentTime);
                    if(window != previous_window && previous_version != -1)
                    {
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = previous_window;
                        m.message_type = XA_XdndLeave;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = 0;
                        m.data.l[2] = 0;
                        m.data.l[3] = 0;
                        m.data.l[4] = 0;

                        XSendEvent(disp, previous_window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);
                    }
                    if(window != previous_window && version != -1)
                    {    
                        map<Atom, string>::const_iterator i = typed_data.begin();
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = window;
                        m.message_type = XA_XdndEnter;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = min(5, version) << 24  |  (typed_data.size() > 3);
                        m.data.l[2] = typed_data.size() > 0 ? i++->first : 0;
                        m.data.l[3] = typed_data.size() > 1 ? i++->first : 0;
                        m.data.l[4] = typed_data.size() > 2 ? i->first : 0;
                        XSendEvent(disp, window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);
                    }
                    if(version != -1)
                    {
                        int x, y, tmp;
                        unsigned int utmp;
                        Window wtmp;
                        XQueryPointer(disp, window, &wtmp, &wtmp, &tmp, &tmp, &x, &y, &utmp);
                        XClientMessageEvent m;
                        memset(&m, sizeof(m), 0);
                        m.type = ClientMessage;
                        m.display = ev.xclient.display;
                        m.window = window;
                        m.message_type = XA_XdndPosition;
                        m.format=32;
                        m.data.l[0] = win;
                        m.data.l[1] = 0;
                        m.data.l[2] = (x <<16) | y;
                        m.data.l[3] = CurrentTime; //Our data is not time dependent, so send a generic timestamp;
                        m.data.l[4] = XA_XdndActionCopy;
                        XSendEvent(disp, window, False, NoEventMask, (XEvent*)&m);
                        XFlush(disp);

                    }
                    previous_window = window;    
                    previous_version = version;
                    Window        QueryRoot, QueryChild;
                    int           AbsoluteX, AbsoluteY;
                    int           RelativeX, RelativeY;
                    unsigned int    ModKeyMask;
                    
                    XQueryPointer(disp, root,
                        &QueryRoot, &QueryChild,
                        &AbsoluteX, &AbsoluteY,
                        &RelativeX, &RelativeY,
                        &ModKeyMask);
                    XMoveWindow(disp,win,AbsoluteX-10 , AbsoluteY-10);
                    if (AbsoluteX<=5)
                    {
                        screenX=0;
                        screenY=AbsoluteY;
                    }
                    else if (AbsoluteX<screenWidth)
                    {
                        screenX=AbsoluteX-(int)(screenWidth/3);
                        screenY=AbsoluteY;
                    }
                    else
                    {
                        screenX=AbsoluteX;
                        screenY=AbsoluteY;
                    }
                }
                break;
            case ButtonPress:
                if(ev.xbutton.button==1)
                {
                    gettimeofday(&LastTime, 0);
                    have_press=1;
                    have_release=0;
                    dragging=0;
                }
                break;
            case ButtonRelease:
                 if(ev.xbutton.button==1)
                 {
                    have_release=1;
                    have_press=0;
                    m_button=0;
                    if (dragging)
                    {
//                      cout << "Mouse button was released.\n";


                        if(status == CAN_DROP)
                        {
//                          cout << "Perform drop:\n";

                            XClientMessageEvent m;
                            memset(&m, sizeof(m), 0);
                            m.type = ClientMessage;
                            m.display = ev.xclient.display;
                            m.window = previous_window;
                            m.message_type = XA_XdndDrop;
                            m.format=32;
                            m.data.l[0] = win;
                            m.data.l[1] = 0;
                            m.data.l[2] = CurrentTime; //Our data is not time dependent, so send a generic timestamp;
                            m.data.l[3] = 0;
                            m.data.l[4] = 0;

                            XSendEvent(disp, previous_window, False, NoEventMask, (XEvent*)&m);
                            XFlush(disp);
                        }
                        XUngrabPointer(disp, CurrentTime);
                        dragging=0;
                        /*     3
                         *    /\
                         *     |
                         * 1<-- -->2
                         *     |
                         *    \/
                         *    4     
                         * 1 左移 
                         * 2 右移 
                         * 3 到上一个group（如果有） 
                         * 4 到下一个group（如果有）
                         * 5(拽到屏幕左边缘) 删除
                         */
                        printf("%d %d\n",screenX,screenY);
                        if ( screenX<=5)
                            fx=5;
                        else
                        {
                            int ll=screenX-o_x;
                            int hh=screenY-o_y;
                            if ((abs(ll)<=10) and (abs(hh)<=10))
                                fx=0;
                            else if (abs(ll)-abs(hh)>=0)
                            {
                                if (ll>0)
                                    fx=2;
                                else
                                    fx=1;
                            }
                            else
                            {
                                if (hh>0)
                                    fx=4;
                                else
                                    fx=3;
                            }
                        }
//                        printf("fx: %d %D\n",fx,l_id);
                        status=UNAWARE;
                        previous_window=None;
                        previous_version=-1;
//                        cout << endl;
                        char submenue[1024];
                        char c_cmd[1024];
                        char f_buffer[4096];
                        char f_buffer2[4096];
                        char l11[12];
                        int l_end;
                        FILE * fp=NULL;
                        FILE * fp2=NULL;
                        unsigned long g_id;
                        sprintf(submenue,"%s/.icon-DE/wharf.rc",home);
                        if (access(submenue,0)!=-1)
                        {
                            
                            sprintf(c_cmd,"cp -f %s %s~",submenue,submenue);
//                            printf("%s\n",c_cmd);
                            system(c_cmd);
                            sprintf(submenue,"%s/.icon-DE/wharf.rc~",home);
                            fp=fopen(submenue,"r");
                            if (fp==NULL)
                            {
                                printf("not open 1\n");
                            }
                            else
                            {
                                if (fx==3)
                                {
                                    sprintf(submenue,"%s/.icon-DE/wharf.rc",home);
                                    sprintf(c_cmd,"cp -f %s %s~~",submenue,submenue);
                                    printf("%s\n",c_cmd);
                                    system(c_cmd);
                                    sleep(2);
                                    FILE *fp3;
                                    unsigned long ii;
                                    sprintf(submenue,"%s/.icon-DE/wharf.rc~~",home);
                                    fp3=fopen(submenue,"r");
                                    if (fp3==NULL)
                                    {
                                        printf("not open 3\n");
                                        break;
                                    }
                                    else
                                    {
                                        fgets(f_buffer2,4096,fp3);
                                        ii=1;
                                        g_id=1;
                                        while ( ! feof(fp3) )
                                        {
                                            sprintf(l11,"%c%c%c%c%c",f_buffer2[0],f_buffer2[1],f_buffer2[2],f_buffer2[3],f_buffer2[4]);
                                            if (strcmp(l11,"group")==0 )
                                                g_id=ii;
                                            if (ii==l_id)
                                                break;
                                            fgets(f_buffer2,4096,fp3);
                                            ii=ii+1;
                                            printf("g_id: %ld %ld %s\n",g_id,ii,f_buffer2);
                                        }
                                    }
                                    fclose(fp3);
                                    sprintf(c_cmd,"rm -rf %s",submenue);
//                                    printf("%s\n",c_cmd);
                                    printf("g_id: %ld \n",g_id);
                                    system(c_cmd);
                                }
                                sprintf(submenue,"%s/.icon-DE/wharf.rc",home);
                                fp2=fopen(submenue,"w");
                                fgets(f_buffer,4096,fp);
                                i=1;
                                l_end=0;
                                while ( ! feof(fp) )
                                {
                                    if (fx==1)
                                    {
                                        if (i==l_id-1)
                                        {
                                            if ( ! feof(fp) )
                                            {
                                                fgets(f_buffer2,4096,fp);
                                                i=i+1;
                                                sprintf(l11,"%c%c%c%c%c",f_buffer2[0],f_buffer2[1],f_buffer2[2],f_buffer2[3],f_buffer2[4]);
                                                if (strcmp(l11,"group")==0 )
                                                {
                                                    fputs(f_buffer,fp2);
                                                    fputs(f_buffer2,fp2);
                                                }
                                                else
                                                {
                                                    fputs(f_buffer2,fp2);
                                                    fputs(f_buffer,fp2);
                                                }
                                            }
                                            else
                                                fputs(f_buffer,fp2);
                                        }    
                                        else
                                            fputs(f_buffer,fp2);
                                    }
                                    else if  (fx==2)
                                    {
                                        if (i==l_id)
                                        {
                                            if ( ! feof(fp) )
                                            {
                                                fgets(f_buffer2,4096,fp);
                                                i=i+1;
                                                sprintf(l11,"%c%c%c%c%c",f_buffer2[0],f_buffer2[1],f_buffer2[2],f_buffer2[3],f_buffer2[4]);
                                                if (strcmp(l11,"group")==0 )
                                                {
                                                    fputs(f_buffer,fp2);
                                                    fputs(f_buffer2,fp2);
                                                }
                                                else
                                                {
                                                    fputs(f_buffer2,fp2);
                                                    fputs(f_buffer,fp2);
                                                }
                                            }
                                            else
                                                fputs(f_buffer,fp2);
                                        }    
                                        else
                                            fputs(f_buffer,fp2);
                                    }
                                    else if  (fx==3)
                                    {
                                        if (i!=l_id)
                                            fputs(f_buffer,fp2);
                                        if (i==g_id-1)
                                            fputs(f_buffer2,fp2);
                                    }
                                    else if  (fx==4)
                                    {
                                        if (i==l_id-1)
                                        {
                                            fputs(f_buffer,fp2);
                                            if ( ! feof(fp) )
                                            {
                                                fgets(f_buffer2,4096,fp);
                                                i=i+1;
                                                l_end=1;
                                            }
                                        }    
                                        else
                                        {
                                            sprintf(l11,"%c%c%c%c%c",f_buffer[0],f_buffer[1],f_buffer[2],f_buffer[3],f_buffer[4]);
                                            if ((l_end==1) and (strcmp(l11,"group")==0 ))
                                            {
                                                fputs(f_buffer,fp2);
                                                fputs(f_buffer2,fp2);
                                                l_end=0;
                                            }
                                            else
                                                fputs(f_buffer,fp2);
                                        } 
                                    }
                                    else //删除
                                    {
                                        if (i!=l_id )
                                            fputs(f_buffer,fp2);
                                    }
                                    fgets(f_buffer,4096,fp);
                                    i=i+1;
                                }
                            }
                            fclose(fp);
                            fclose(fp2);
                            sprintf(submenue,"icon-wharf RESET");
                            system(submenue);
                        }
                        break;
//                        
                        /* if we click anywhere in the window, exit */
                    }
                    else if ( m_mouse == 0 )
                    {
                        exposelist();
                        if (MouseMoveOpenSubIcon==1) 
                             system("killall iconrun2 2>/dev/null");
                        system("killall iconrun3 2>/dev/null");
                    }
                    else
                    {
                        x = ev.xmotion.x;
                        y = ev.xmotion.y;
                        if ((x>=100) and (x<=138) and (y>=96) and (y<=130))
                        {
                            imlib_context_set_drawable(win4);
                            imlib_context_set_image(buffer4);
                            imlib_render_image_on_drawable(0, 0);
                            imlib_free_image();
                            XDestroyWindow(disp,win4);
                            XSync(disp, False);
                            XFlush(disp); 
                            imlib_context_set_image(im_bg);
                            imlib_context_set_drawable(win);
                            m_button=0;
                            m_mouse=0;
                        }
                        if ((x>=54) and (x<=90) and (y>=8) and (y<=43))
                            m_button=4;
                        if ((x>=54) and (x<=90) and (y>=53) and (y<=86))
                            m_button=2;
                        if ((x>=54) and (x<=90) and (y>=96) and (y<=129))
                            m_button=5;
                        if ((x>=100) and (x<=138) and (y>=8) and (y<=86))
                            m_button=3;
                    }
                }
                if ((ev.xbutton.button==2) or (m_button==2))
                {
                    if (get_active_window(disp)!=0)
                    {
                        if (tra==0)
                        {
                            sprintf(submenue , "icon-trans %f 1" , trans_wind);
                            system(submenue);    
                            tra=1;
                        } else {
                            sprintf(submenue , "icon-trans 1 1");
                            system(submenue);    
                            tra=0;
                        } 
                    }
                    break;
                 }
                 if ((ev.xbutton.button==3) or (m_button==3))
                 {
                     if (MouseMoveOpenSubIcon==1) 
                         system("killall iconrun2 2>/dev/null");
                     system("killall iconrun3 2>/dev/null");
//                                                                     exit(0);
                     break;
                 }
                if ((ev.xbutton.button==4) or (m_button==4))
                {
                    cur_times=cur_times+1;
                    if ((can_close==1) or (cur_times>=3))
                    {
                        if (MouseMoveOpenSubIcon==1)
                            system("killall iconrun2 2>/dev/null");    
                        system("killall iconrun3 2>/dev/null");    
                    }
                    list_windows(disp,skip);
                    if (get_active_window(disp)==0)
                    {
                        for (i=0;i<win_count;i++)
                        {
                            if (win_pid_list[i]!=0) 
                            if (get_window_title(disp,win_pid_list[i])!=NULL)
                            if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                            {
                                action_window(disp,win_pid_list[i],'a');
                                can_close=0;
                            }    
                        }     
                    } else {
                        if (strstr(get_window_title(disp,get_active_window(disp)),title)==NULL)
                        {
                            init_window(get_active_window(disp));
                            for (i=0;i<win_count;i++)
                            {
                                if (win_pid_list[i]!=0) 
                                if (get_window_title(disp,win_pid_list[i])!=NULL)
                                if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                {
                                    action_window(disp,win_pid_list[i],'a');
                                    can_close=0;
                                }    
                            }     
                        }    else {
                            if (get_active_window(disp)!=0)
                            {
                                cur_win_id=get_active_window(disp);
                                init_window(cur_win_id);
                                window_move_resize(disp,cur_win_id,win_move);
                            }
                        }
                    }    
                    break;
                }
                if ((ev.xbutton.button==5) or (m_button==5))
                {
                    cur_times=cur_times+1;
                    if ((can_close==1) or (cur_times>=3))
                    {
                        if (MouseMoveOpenSubIcon==1)
                            system("killall iconrun2 2>/dev/null");    
                        system("killall iconrun3 2>/dev/null");    
                    }
                    list_windows(disp,skip);
                    if (get_active_window(disp)==0)
                    {
                        for (i=0;i<win_count;i++)
                        {
                            if (win_pid_list[i]!=0) 
                            if (get_window_title(disp,win_pid_list[i])!=NULL)
                            if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                            {
                                action_window(disp,win_pid_list[i],'a');
                                can_close=0;
                            }    
                        }     
                    } else {
                        if (strstr(get_window_title(disp,get_active_window(disp)),title)==NULL)
                        {
                            init_window(get_active_window(disp));
                            for (i=0;i<win_count;i++)
                            {
                                if (win_pid_list[i]!=0) 
                                if (get_window_title(disp,win_pid_list[i])!=NULL)
                                    if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                                    {
                                        action_window(disp,win_pid_list[i],'a');
                                        can_close=0;
                                    }    
                                }     
                            }    else {
                            if (get_active_window(disp)!=0)
                            {
                                cur_win_id=get_active_window(disp);
                                init_window(cur_win_id);
                                window_move_resize(disp,cur_win_id,win_move);
                            }
                        }
                    }    
                    break;
                }
            case ClientMessage:
                if (ev.xclient.message_type == XA_XdndStatus)
                {
//                cout  << "XDnDStatus event received:" << endl
//                      << "    Target window           = 0x" << hex << ev.xclient.data.l[0] << dec << endl
//                      << "    Will accept             = " << (ev.xclient.data.l[1] & 1)  << endl
//                      << "    No rectangle of silence = " << (ev.xclient.data.l[1] & 2)  << endl
//                      << "    Rectangle of silence x  = " << (ev.xclient.data.l[2] >> 16)    << endl
//                      << "    Rectangle of silence y  = " << (ev.xclient.data.l[2] & 0xffff)    << endl
//                      << "    Rectangle of silence w  = " << (ev.xclient.data.l[3] >> 16)    << endl
//                      << "    Rectangle of silence h  = " << (ev.xclient.data.l[3] & 0xffff)    << endl
//                      << "    Action                  = " << GetAtomName(disp, ev.xclient.data.l[4]) << endl;

                
                if( (ev.xclient.data.l[1] & 1) == 0 &&  ev.xclient.data.l[4] != None)
                {
                    cout << "Action is given, even though the target won't accept a drop.\n";
                }


                if(dragging)
                {
                    if((ev.xclient.data.l[1]&1) && status != UNAWARE)
                        status = CAN_DROP;

                    if(!(ev.xclient.data.l[1]&1) && status != UNAWARE)
                        status = UNRECEPTIVE;
                }

                if(!dragging)
                    cout << "Message received, but dragging is not active!\n";

                if(status == UNAWARE)
                    cout << "Message received, but we're not in an aware window!\n";

                cout << endl;
                }
                else if( ev.xclient.message_type == XA_XdndFinished)
                {
                    //Check for these messages. Since out data is static, we don't need to do anything.
                    cout  << "XDnDFinished event received:" << endl
                          << "    Target window           = 0x" << hex << ev.xclient.data.l[0] << dec << endl
                          << "    Was successful          = " << (ev.xclient.data.l[1] & 1)  << endl
                          << "    Action                  = " << GetAtomName(disp, ev.xclient.data.l[2]) << endl;
                    
                    cout  << "No action performed.\n\n";
                }
                
                break;
             case EnterNotify:        
                 x = ev.xmotion.x;
                 y = ev.xmotion.y;
                 mytoggle = 1;
                 buffer = imlib_create_image(1000, 30);    
                 font = imlib_load_font("Vera/8");
                 if (font == NULL)
                     font = imlib_load_font("wqy-zenhei.ttc/8");
                 imlib_context_set_font(font);
                 imlib_context_set_color(0, 0, 0, 255);
                 sprintf(text,"%s",tag);
                 imlib_get_text_size(text, &text_w, &text_h);
                 win2=XCreateWindow(disp,DefaultRootWindow(disp),screenX+10,screenY-20,text_w+10,text_h+4,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                 XRaiseWindow(disp,win2);
                 XMapWindow(disp, win2);
                 imlib_context_set_drawable(win2); 
         //                     imlib_context_set_image(buffer);

                         /* draw the range */
                 imlib_context_set_image(buffer);
                 imlib_image_fill_color_range_rectangle(0,0, text_w*4, text_h*2,-45.0);
                         /* free it */
                //         imlib_free_color_range();
                 imlib_context_set_image(buffer);
                 imlib_render_image_on_drawable(0, 0); 
                 imlib_context_set_image(buffer);
                 imlib_context_set_font(font);
                 imlib_context_set_color(0, 0, 0, 255);
                 imlib_text_draw(5,2,text);
                 /* set the buffer image as our current image */
                 imlib_context_set_image(buffer);
                 imlib_context_set_drawable(win2); 
                 imlib_render_image_on_drawable(0, 0); 
                 imlib_context_set_image(buffer);
                 imlib_free_image();
                 imlib_context_set_font(font);
                 imlib_free_font();

                 imlib_context_set_image(im_bg);
                 imlib_context_set_drawable(win);
                 break;
             case LeaveNotify:        
                 x = -screenWidth/2;
                 y = -screenHeight/2;    
                 mytoggle = 0;
                 XDestroyWindow(disp,win2);
                 break;
             case Expose:
                break;

             default:
                 break;
             }

         }
         else {
        //display 是由 XopenDisplay 返回的 Display *
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
//LastTime 是 timeval 类型的变量,保存上次时间
//ticks 的单位是毫秒 millisecond
            ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
            if (ticks>=3000)
            {
                if ((have_press==1) and (have_release==0))
                {
                    if(XGrabPointer(disp, win, True, Button1MotionMask | ButtonReleaseMask, GrabModeAsync, GrabModeAsync, root, grab_good, CurrentTime) == GrabSuccess)
                    {
/*                        imlib_context_set_drawable(win4);
                        imlib_context_set_image(buffer4);
                        imlib_render_image_on_drawable(0, 0);
                        imlib_free_image();
                        XDestroyWindow(disp,win4);
                        XSync(disp, False);
                        XFlush(disp); 
                        imlib_context_set_image(im_bg);
                        imlib_context_set_drawable(win); */
                        dragging=1;
                        printf("dragging\n");
                        XSetSelectionOwner(disp, XA_XdndSelection, win, CurrentTime);
                        m_mouse=0;
                        m_button=0;
                    }    
                }
                else
                    dragging=0;
                gettimeofday(&LastTime, 0);
            } else if (ticks>=800)
            {
                if ((have_press==1) and (dragging!=1) and (have_release==0) and (m_mouse==0))
                {
                    win4=XCreateWindow(disp,DefaultRootWindow(disp),screenX+screenWidth,screenY+screenHeight,153,193,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
                    XSelectInput(disp, win4, ButtonPressMask | ButtonReleaseMask );
                    XMapWindow(disp, win4);
                    imlib_context_set_drawable(win4); 
                    sprintf(mouse_pic,"%s/.icon-DE/iconcache/mouse.png",home);
                    if (access(mouse_pic,0)==-1)
                    {
                        system("cp /usr/share/icon-DE/iconcache/mouse.png ~/.icon-DE/iconcache/mouse.png");
                        sprintf(mouse_pic,"/usr/share/icon-DE/iconcache/mouse.png");
                    }
                    buffer4 = imlib_load_image(mouse_pic);
                    imlib_context_set_image(buffer4);
                    imlib_render_image_on_drawable(0, 0);
                    m_mouse=1;
                    imlib_context_set_image(im_bg);
                    imlib_context_set_drawable(win);
/*
                    imlib_context_set_image(back);
                    imlib_render_image_on_drawable(0, 0);
                    imlib_free_image();
                    imlib_context_set_font(font);
                    imlib_free_font();
*/
                }
            }
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=100000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
            if (m_mouse==1)
            {
                imlib_context_set_drawable(win4); 
                imlib_context_set_image(buffer4);
                imlib_render_image_on_drawable(0, 0);
                imlib_context_set_image(back);
                imlib_context_set_drawable(win); 
            }

            imlib_context_set_blend(1);
            if(mytoggle == 1)
            {
                imlib_context_set_image(bigback);
                xl=x-24;
                yl=y-24;
            }else{
                imlib_context_set_image(back);
                xl=x-10;
                yl=y-10;
            }

            temp = imlib_clone_image();
            imlib_context_set_image(temp);
            char bump[]="bump_map_point(x=[],y=[],map=""blend.jpg);";
            imlib_apply_filter
            (bump, &xl, &yl);
            imlib_context_set_image(back);
            imlib_render_image_on_drawable(0, 0);
            temp2 = im_bg;
            im_bg = temp;
            imlib_context_set_image(im_bg);
            imlib_context_set_blend(1);
            imlib_render_image_on_drawable(0, 0);
            im_bg = temp2;
            imlib_context_set_image(temp);
            imlib_free_image();
        } /* End else*/
     }
     return 0;
}

void exposelist(void){
    //printf("exposelist\n");
    char app[2000];
    if ((bord==1) or (trans_wind<1))
    {
        sprintf(app , "icon-bord \"%s\" \"%s\" %d %f &" ,title,skip,bord,trans_wind);
        system(app);    
    }
    sprintf(app,"%s &",appToRun);
    system(app);
}
