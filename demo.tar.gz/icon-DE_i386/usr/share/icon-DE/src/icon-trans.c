// g++ -o ./icon-trans ./icon-trans.c `pkg-config --cflags --libs glib-2.0` -lXcomposite -lXdamage -lXfixes -lXrender 

#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include <X11/Xutil.h>
#include <X11/cursorfont.h>

char program_name[] = "icon-trans";
Display *dpy;                                                 /* The current display */
int screen;                                                     /* The current screen */

#define MAX_PROPERTY_VALUE_LEN 4096

Window target_win;

void Fatal_Error(char *msg, ...)
{
	va_list args;
	fflush(stdout);
	fflush(stderr);
	fprintf(stderr, "%s: error: ", program_name);
	va_start(args, msg);
	fprintf(stderr, msg, args);
	va_end(args);
	fprintf(stderr, "\n");
	exit(1);
}

/* returns the highest parent of child that is not the root-window */
Window get_top_window(Display *dpy,Window child) {
		Window parent;
		Window root;
		Window *child_list;
        char error[]="Can't query window tree.";
		unsigned int num_children;
		
	 	if (!XQueryTree(dpy, child, &root, &parent, &child_list,
				    &num_children))
    	    Fatal_Error(error);
		if(parent==root) return child;
		
		while(parent!=root) {
			child = parent;
	 		if (!XQueryTree(dpy, child, &root, &parent, &child_list,
				    &num_children))
			Fatal_Error(error);

		}
		return child;
}

/* returns the actual window */
Window get_actual_window(Display *dpy)
{
        int i;
        Window w;

        XGetInputFocus(dpy, &w, &i);
        return get_top_window(dpy, w);
}


Window Select_Window()
{
    int status;
    Cursor cursor;
    XEvent event;
    Window target_win = None, root = RootWindow(dpy,screen);
    int buttons = 0;
    char error[]="Can't grab the mouse.";

    /* Make the target cursor */
    cursor = XCreateFontCursor(dpy, XC_crosshair);

    /* Grab the pointer using target cursor, letting it room all over */
    status = XGrabPointer(dpy, root, False,
			ButtonPressMask|ButtonReleaseMask, GrabModeSync,
			GrabModeAsync, root, cursor, CurrentTime);
    if (status != GrabSuccess) Fatal_Error(error);

    /* Let the user select a window... */
    while ((target_win == None) || (buttons != 0)) {
        /* allow one more event */
        XAllowEvents(dpy, SyncPointer, CurrentTime);
        XWindowEvent(dpy, root, ButtonPressMask|ButtonReleaseMask, &event);
        switch (event.type) {
        case ButtonPress:
            if (target_win == None) {
	target_win = event.xbutton.subwindow; /* window selected */
	if (target_win == None) target_win = root;
            }
            buttons++;
            break;
        case ButtonRelease:
            if (buttons > 0) /* there may have been some down before we started */
	buttons--;
             break;
        }
    } 

    XUngrabPointer(dpy, CurrentTime);            /* Done with pointer */

    return(target_win);
}


static Atom
get_window_type(Window win,
                                Atom property)
{
        Atom window_type = None;
        Atom actual_type;
        int actual_format;
        unsigned long nitems, bytes_after;
        unsigned char *prop_return = NULL;
        
        if(Success == XGetWindowProperty(dpy, win, property, 0L, sizeof(Atom),
                                                                         False, XA_ATOM, &actual_type,
                                                                         &actual_format, &nitems, &bytes_after,
                                                                         &prop_return) && prop_return)
        {
                window_type = *(Atom *)prop_return;
                XFree(prop_return);
        }
        
        return window_type;

}

void usage()
{
    fprintf(stderr, "Bad arguments\n");
}

#define OPAQUE	0xffffffff
#define OPACITY	"_NET_WM_WINDOW_OPACITY"

/* nothing fancy */
int main(int argc, char **argv)
{
    int gotd = 0;
    double d=0.85;
    int ts_type=0;
    unsigned int opacity;
    const char                 *display_name = getenv("DISPLAY");

    /* wonderful utility */
    dpy = XOpenDisplay(display_name);
    screen = DefaultScreen(dpy);

    if (argv[1])
    {
        printf ("got arg %s\n", argv[1]);
        d = atof (argv[1]);
        printf ("d is %g\n", d);
        gotd = 1;
    } else {
        printf ("Error:必须有1个或者2个参数。\n");
        printf ("第一个参数是“半透明度”，只有1个参数（半透明度）是“手动选择窗口”\n");
        printf ("第二个参数是“半透明应用范围”，0--包括dock的所有窗口；1--非dock窗口；2--活动窗口；\n");
        return -1;
    }    
    unsigned char *data;

    Atom actual;
    int format;
    unsigned long n, left;

    /* grab mouse and return window that is next clicked */
    if (argv[2])
    {
        ts_type=atoi(argv[2]);
        if (ts_type!=2)
        {
            Window *children, dummy;
            unsigned int nchildren;
            unsigned int i;
            Window w=0;
            Atom  _NET_WM_WINDOW_TYPE,_NET_WM_WINDOW_TYPE_DESKTOP, _NET_WM_WINDOW_TYPE_DOCK, window_type;
            XWindowAttributes attr;

//            _NET_WM_WINDOW_OPACITY = XInternAtom(dpy, "_NET_WM_WINDOW_OPACITY", False);
//            _NET_ACTIVE_WINDOW = XInternAtom(dpy, "_NET_ACTIVE_WINDOW", False);
            _NET_WM_WINDOW_TYPE = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE", False);
//            _NET_WM_NAME = XInternAtom(dpy, "_NET_WM_NAME", False);
            _NET_WM_WINDOW_TYPE_DESKTOP = XInternAtom(dpy,
                                                                                                "_NET_WM_WINDOW_TYPE_DESKTOP",
                                                                                            False);
            _NET_WM_WINDOW_TYPE_DOCK = XInternAtom(dpy, "_NET_WM_WINDOW_TYPE_DOCK",
                                                                                     False);

            if (!XQueryTree(dpy, RootWindow(dpy,screen), &dummy, &dummy, &children, &nchildren))
                    return(0);
            opacity = (unsigned int) (d * OPAQUE);
            for (i=0; i<nchildren; i++) 
            {
                XGetWindowAttributes(dpy, children[i], &attr);
                window_type = get_window_type(children[i],
                                                                        _NET_WM_WINDOW_TYPE);
                if (ts_type==0)
                {
                    if(window_type == _NET_WM_WINDOW_TYPE_DESKTOP
                         || window_type == _NET_WM_WINDOW_TYPE_DOCK)
                    {
                         continue;
                    }
                    if(attr.override_redirect == True)
                         continue;
                }
                printf("%lu Property to %g\n",children[i],(double) opacity / OPAQUE);
                XChangeProperty(dpy, children[i], XInternAtom(dpy, OPACITY, False), 
                    XA_CARDINAL, 32, PropModeReplace, 
                    (unsigned char *) &opacity, 1L);
                XSync(dpy, False);
            } 
            if (children) XFree ((char *)children);
            return(w);
        } else {
            opacity = (unsigned int) (d * OPAQUE);
            Window w=0;
            w=get_actual_window(dpy);
            if (w!=0)
            {
                printf("%lu Property to %g\n",w,(double) opacity / OPAQUE);
                XChangeProperty(dpy, w, XInternAtom(dpy, OPACITY, False), 
                    XA_CARDINAL, 32, PropModeReplace, 
                    (unsigned char *) &opacity, 1L);
                XSync(dpy, False);
            }
        }
    }
    else
    {
        target_win = Select_Window();
        printf("%lu \n",target_win);

        if (gotd)
            opacity = (unsigned int) (d * OPAQUE);
        else
        {
        /* get property */
            XGetWindowProperty(dpy, target_win, XInternAtom(dpy, OPACITY, False), 
		             0L, 1L, False, XA_CARDINAL, &actual, &format, &n, &left, 
		 (unsigned char **) &data);
    
            if (data != None)
            {
	        memcpy (&opacity, data, sizeof (unsigned int));
        	XFree(( void *) data );
	        printf("Found property: %g\n", (double) opacity / OPAQUE);
            }
            else
                opacity = OPAQUE;
    
        /* toggle */
            if (opacity != OPAQUE)
                opacity = OPAQUE;
            else
                opacity = 0xc0000000;
        }

        printf ("opacity 0x%x\n", opacity);
        if (opacity == OPAQUE)
            XDeleteProperty (dpy, target_win, XInternAtom(dpy, OPACITY, False));
        /* set it */
        else
            XChangeProperty(dpy, target_win, XInternAtom(dpy, OPACITY, False), 
		        XA_CARDINAL, 32, PropModeReplace, 
		        (unsigned char *) &opacity, 1L);
        XSync(dpy, False);
        printf("Set Property to %g\n", (double) opacity / OPAQUE);
    
    }
    /* all done, wasn't that simple */
    return 0;
}
