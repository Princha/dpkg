// g++ -o ./bin/icon-dock ./src/icon-dock.c  -lX11 -lImlib2 -lXmu `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xos.h>
#include <X11/Xatom.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib-2.0/glib.h>

#include "./other_src/MWMHints.h"
#include "Imlib2.h"

Display                        *disp;
Window                          win;
Window                          win2;
Visual                         *vis;
Colormap                        cm;
int                             depth;
XSetWindowAttributes attr;
char appToRun[1024];

#include "./other_src/wm_ctrl.c"

int main(int argc, char **argv)
{
    int                                 w, h, x, y;
    Imlib_Image                 im_bg = NULL;
    XEvent                            ev;
    const char                 *display_name = getenv("DISPLAY");
    Imlib_Image                 buffer;
    Imlib_Image                 back;
//    Imlib_Image                 bigback;
//    Imlib_Font                    font;
    Imlib_Color_Range     range;

    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=64;
    int screenHeight;
    screenHeight=64;
    int screenX=10;
    int screenY=10;
    int lowerraise=0;
    int autohidebutton=0;
    char *dock_opt;
    char *dock_title;
    char *dock_cmd;
    char                                *skip;
    int xl=0;
    int yl=0;
    int x2=1;
    int y2=1;
    int try_times;
//    MWMHints mwmhints;
//    Atom selection_atom, opcode_atom, data_atom;
//    Atom prop;
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));
//----arguments x y width height lower/raise(0/1) picture hidemode
    if ( argc != 14 )
    {
        printf("usage: icondock x y width height lower/raise(0/1) autohidebutton(0/1/2) dock_title dock_cmd dock_opt x2 y2 skip_win_class try_times \n");
        return 1;
    }
 // printf("ok\n");
    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    sscanf(argv[5], "%d", &lowerraise);
    sscanf(argv[6], "%d", &autohidebutton);
    dock_title=argv[7];
    dock_cmd=argv[8];
    dock_opt=argv[9];
    sscanf(argv[10], "%d", &x2);
    sscanf(argv[11], "%d", &y2);
    skip=argv[12];
    sscanf(argv[13], "%d", &try_times);
    
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text
    range = imlib_create_color_range();
    imlib_context_set_color_range(range);
    imlib_context_set_color(255, 255, 255, 255);
    imlib_add_color_to_color_range(0);
    /* add an orange color, semi-transparent 10 units from the first */
    imlib_context_set_color(255, 200, 10, 255);
    imlib_add_color_to_color_range(10);
    /* add black, fully transparent at the end 20 units away */
    imlib_context_set_color(70, 0, 0, 255);
    imlib_add_color_to_color_range(20);

    attr.override_redirect=True;
    win=XCreateWindow(disp,DefaultRootWindow(disp),screenX,screenY,screenWidth+2,screenHeight,0,CopyFromParent, InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    XMapWindow(disp, win);

    attr.override_redirect=True;
    win2=XCreateWindow(disp,DefaultRootWindow(disp),0,0,screenWidth+2,screenHeight,0,CopyFromParent, InputOutput,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
    XSelectInput(disp, win2, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    XMapWindow(disp, win2);

    if(lowerraise==0)
         XLowerWindow(disp,win);
    if(lowerraise==1)
         XRaiseWindow(disp,win);

     /**
        * Start rendering
        */

    imlib_context_set_display(disp);
    imlib_context_set_visual(vis);
    imlib_context_set_colormap(cm);
    imlib_context_set_drawable(win);
    imlib_context_set_dither(1);
    imlib_context_set_blend(0);
    imlib_context_set_color_modifier(NULL);

//--
    w=screenWidth;
    h=screenHeight;
    char back_pic[1280];
    sprintf(back_pic,"%s/.icon-DE/pics/background.png",home);
    if (access(back_pic,0)==-1)
        sprintf(back_pic,"/usr/share/icon-DE/pics/background.png");
    back = imlib_load_image(back_pic);
    imlib_context_set_image(back);
    buffer = imlib_create_cropped_scaled_image(0, 0,imlib_image_get_width() ,imlib_image_get_height() , w , h);
    XMapWindow(disp, win);
    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
//    bigback=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    imlib_context_set_image(back);
    imlib_render_image_on_drawable(0, 0);
    back=imlib_create_image_from_drawable( 0,0,0,w,h,1);

    XResizeWindow(disp, win, w, h);
    XSync(disp, False);
//    if (autohidebutton==1)
//         XMoveWindow(disp,win,-screenWidth+2 , screenY);
//    if (autohidebutton==2)
//         XMoveWindow(disp,win,-screenWidth/2 , screenY);
    x = -9999;
    y = -9999;
    x = -screenWidth/2;
    y = -screenHeight/2;
    unsigned long root_win=0;
    unsigned long i;
    #define PROGRAMNAME "icon-dock"
    int act_win_pid2=0;
    sprintf(appToRun,"%s %s &",dock_cmd,dock_opt);
    system(appToRun);
    sleep(1);
    int try_open=0;
    while (1)
    {
        act_win_pid=0;
        sleep(1);
        try_open=try_open+1;
        list_windows(disp,skip);
        for (i=0;i<win_count;i++)
        {
            if (win_pid_list[i]!=0) 
            if (get_window_title(disp,win_pid_list[i])!=NULL)
            if (strstr(get_window_title(disp,win_pid_list[i]),dock_title)!=NULL)
            {
                act_win_pid=win_pid_list[i];
                act_win_pid2=win_pid_list[i];
                break;
            }    
        } 
        if (act_win_pid!=0)
            break;
        if (try_open>=10)
        {
            printf("打开 %s 失败！！!\n",dock_cmd);
            return -1;
        }
    }
/*    memset(&mwmhints, 0, sizeof(mwmhints));
    prop = XInternAtom(disp, "_MOTIF_WM_HINTS", False);
    mwmhints.flags = MWM_HINTS_DECORATIONS;
    mwmhints.decorations = 0;
    XChangeProperty(disp, act_win_pid, prop, prop, 32, PropModeReplace,
                                    (unsigned char *) &mwmhints,
                                    PROP_MWM_HINTS_ELEMENTS);
*/
    XReparentWindow(disp, act_win_pid, win, x2, y2); 
    XMoveWindow(disp, act_win_pid, x2, y2);
    XMapRaised (disp, win);
    XMapRaised (disp, act_win_pid);
    XSelectInput (disp, win, SubstructureNotifyMask);
    XSelectInput(disp, act_win_pid,
                                 StructureNotifyMask|SubstructureNotifyMask);
    XSync(disp, False);
    try_open=0;
    while (1)
    {
        act_win_pid2=0;
        sleep(1);
        list_windows(disp,skip);
        try_open=try_open+1;
        for (i=0;i<win_count;i++)
        {
            if (win_pid_list[i]!=0) 
            if (get_window_title(disp,win_pid_list[i])!=NULL)
            if (strstr(get_window_title(disp,win_pid_list[i]),dock_title)!=NULL)
            {
                act_win_pid2=win_pid_list[i];
                break;
            }    
        }
        if (act_win_pid2==0)
            break;
        if (try_open>=10)
        {
            printf("调用 %s 失败！！!\n",dock_cmd);
//            sprintf(appToRun,"killall %s &",dock_cmd);
//            system(appToRun);
//            return -1;
            break;
        }
    }
    if (( act_win_pid2 !=0 ) and (try_times<10))
    {
        sprintf(appToRun,"killall %s    2>/dev/null &",dock_cmd);
        system(appToRun);
        printf("调用 %s 失败 %d 次，再次尝试！！!\n",dock_cmd,try_times+1);
        sprintf(appToRun,"sleep 4 && icon-dock %d %d %d %d %d %d \"%s\" %s \"%s\" %d %d \"%s\" %d &",screenX,screenY,screenWidth,screenHeight,lowerraise,autohidebutton,dock_title,dock_cmd,dock_opt,x2,y2,skip,try_times+1);
        system(appToRun);
        sprintf(appToRun,"killall icon-dock    2>/dev/null");
        system(appToRun);
    }    else {
        if     (try_times<10)
            printf("调用 %s 成功！！!\n",dock_cmd);
        else
        {
            printf("调用 %s 失败 10 次，停止尝试！！!\n",dock_cmd);
            return -1;
        }     
    }        

    XMoveWindow(disp, win2, screenX, screenY);
    XMoveWindow(disp, win, screenX, screenY);
    
    int fir=0;
    struct timeval now, tm;//,LastTime,LastTime2;
    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    
    while (1)
    {
                Imlib_Image                temp;

        if (XPending(disp))
        {
            XNextEvent(disp, &ev);
                     XNextEvent(disp, &ev);
                     switch (ev.type)
                     {
                            case Expose:
                                    break;
                            case MotionNotify:
                                    x = ev.xmotion.x;
                                    y = ev.xmotion.y;
                            default:
                                    break;
                            case ConfigureNotify:
                                        break;

                            case EnterNotify:		
                                    x = ev.xmotion.x;
                                    y = ev.xmotion.y;
                                    if ((autohidebutton==1) or (autohidebutton==2))
                                    {
                                            XMoveWindow(disp,win2,screenX , screenY);
                                            XMoveWindow(disp,win,screenX , screenY);
                                    }        
                                    break;
                            case LeaveNotify:		
                                    x = -screenWidth/2;
                                    y = -screenHeight/2;		

                                    if(autohidebutton==1)
                                    {
                                             XMoveWindow(disp,win2,-screenWidth+2 , screenY);
                                             XMoveWindow(disp,win,-screenWidth+2 , screenY);
                                    }         
                                    if(autohidebutton==2)
                                    {
                                            XMoveWindow(disp,win2,-screenWidth/2+1 , screenY);
                                            XMoveWindow(disp,win,-screenWidth/2 , screenY);
                                    }
                                    break;

                            case ButtonPress:				
    //                                                if(ev.xbutton.button==1)
                                                    
//                                                    if(ev.xbutton.button==3)
                                break;

                            case ReparentNotify:
                            {
//                                 XReparentEvent *xev = (XReparentEvent *) & ev;
                                 break;
                            }     
                            case UnmapNotify:
                            {
                                XEvent xevent;
//                                XClientMessageEvent *event = (XClientMessageEvent *) & ev;
                                if (fir==0)
                                {
                                    XReparentWindow (disp, act_win_pid, win, x2, y2);
                                    fir=1;
                                }    
                                XMapRaised (disp, act_win_pid);
                                xevent.xclient.window = act_win_pid;
                                xevent.xclient.type = ClientMessage;
                                xevent.xclient.message_type = XInternAtom (disp, "_XEMBED", False);
                                xevent.xclient.format = 32;
                                xevent.xclient.data.l[0] = CurrentTime;
                                xevent.xclient.data.l[1] = 0;
                                xevent.xclient.data.l[2] = 0;
                                xevent.xclient.data.l[3] = win;
                                xevent.xclient.data.l[4] = 0;
                                XSendEvent (disp, win, False, NoEventMask, &xevent);
                                XSendEvent (disp, win2, False, NoEventMask, &xevent);
                                XSendEvent (disp, root_win, False, NoEventMask, &xevent); 
                                break;
                            }
                            case DestroyNotify:
                                break;
//                            case SelectionClear:
//	                    {
//                                if (XGetSelectionOwner (disp, selection_atom) ==win2)
//                                {
//                                     XSetSelectionOwner (disp, selection_atom, None,CurrentTime);
//                                }
//                                return 1;
//                            }
                    }     
        } else {
            FD_ZERO(&rfds);
            FD_SET(xfd, &rfds);
            gettimeofday(&now, 0);
//display 是由 XopenDisplay 返回的 Display *
//如果到期则调用有关函数
//select 等待 100 毫秒
            tm.tv_sec=0l;
            tm.tv_usec=100000l;
            select(xfd + 1, &rfds, 0, 0, &tm);
        } /* End else*/

//        Imlib_Image                temp, temp2;
        xl=x;
        yl=y;

        imlib_context_set_blend(1);
        imlib_context_set_drawable(act_win_pid);
        imlib_context_set_image(back);
        temp = imlib_clone_image();
        imlib_context_set_image(temp);
        char bump[]="bump_map_point(x=[],y=[],map=""blend.jpg);";
        imlib_apply_filter
            (bump, &xl, &yl);
        imlib_context_set_image(back);
        imlib_render_image_on_drawable(0, 0);
        im_bg = temp;
        imlib_context_set_blend(1);
        imlib_render_image_on_drawable(0, 0);
        imlib_context_set_image(temp);
        imlib_free_image();


        imlib_context_set_blend(1);
        imlib_context_set_drawable(win2);
        imlib_context_set_image(back);
        temp = imlib_clone_image();
        imlib_context_set_image(temp);
        imlib_apply_filter
            (bump, &xl, &yl);
        imlib_context_set_image(back);
        imlib_render_image_on_drawable(0, 0);
        im_bg = temp;
        imlib_context_set_blend(1);
        imlib_render_image_on_drawable(0, 0);
        imlib_context_set_image(temp);
        imlib_free_image();
    
        imlib_context_set_blend(1);
        imlib_context_set_drawable(win);
        imlib_context_set_image(back);
        temp = imlib_clone_image();
        imlib_context_set_image(temp);
        imlib_apply_filter
            (bump, &xl, &yl);
        imlib_context_set_image(back);
        imlib_render_image_on_drawable(0, 0);
        im_bg = temp;
        imlib_context_set_blend(1);
        imlib_render_image_on_drawable(0, 0);
        imlib_context_set_image(temp);
        imlib_free_image();

        imlib_context_set_image(buffer);
        imlib_context_set_drawable(act_win_pid);
        temp = imlib_clone_image();
        imlib_context_set_image(temp);
        imlib_apply_filter
        (bump, &xl, &yl);
        imlib_context_set_image(buffer);
        imlib_render_image_on_drawable(0, 0);
        im_bg = temp;
        imlib_context_set_image(im_bg);
        imlib_context_set_blend(1);
        imlib_render_image_on_drawable(0, 0);
        imlib_context_set_image(temp);
        imlib_free_image();
    }

     return 0;
}
