
int ReplaceStr(char *sSrc,const char *sMatchStr,const char *sReplaceStr)
{
     int    StringLen;
     char caNewString[4096];
     char *FindPos = strstr(sSrc, sMatchStr);
     if( (!FindPos) || (!sMatchStr) )
            return -1;
     while( FindPos )
     {
            memset(caNewString, 0, sizeof(caNewString));
            StringLen = FindPos - sSrc;
            strncpy(caNewString, sSrc, StringLen);
            strcat(caNewString, sReplaceStr);
            strcat(caNewString, FindPos + strlen(sMatchStr));
            strcpy(sSrc, caNewString);
            FindPos = strstr(sSrc, sMatchStr);
     }

     return 0;
}
