char full_path_icon[4096]="N/A";
#include "./ReplaceStr.c"
char * find_icon_file(char * icon_name)
{
    FILE *fp=NULL;
    FILE *fp2=NULL;
    char buffer[4096];
    char l11[12]="N/A";
    char l19[20]="N/A";
    char icon_path[7][1024];
    char icon_find1[5][64];
    char icon_find2[10][64];
    int i,m,n;
    char icon_file[4096]="N/A";
    int have_find_icon=0;
    char s_dir[256]="";
    char icon_gtk3[1024]="N/A";
    char icon_gtk2[1024]="N/A";

    if (access(icon_name,0)!=-1)
        fp=fopen(icon_name,"r");
    if(fp!=NULL) 
    {
        fclose(fp);
        return icon_name;
    }    
    if (access("/etc/gtk-3.0/settings.ini",0)!=-1)
    {
        fp=fopen("/etc/gtk-3.0/settings.ini","r");
        if(fp==NULL) 
        {
            printf("can't open /etc/gtk-3.0/settings.ini\n");
        }
        else
        {
            fgets(buffer,4096,fp);
            for (i=0;i<4096;i++)
                if (buffer[i]=='\n') buffer[i]='\0';
            while ( ! feof(fp) )
            {
                sprintf(l19,"%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10],buffer[11],buffer[12],buffer[13],buffer[14],buffer[15],buffer[16],buffer[17],buffer[18]);
                if (strcmp(l19,"gtk-icon-theme-name")==0 )
                {
                    ReplaceStr(buffer,"gtk-icon-theme-name = ","");
                    ReplaceStr(buffer,"gtk-icon-theme-name= ","");
                    ReplaceStr(buffer,"gtk-icon-theme-name =","");
                    ReplaceStr(buffer,"gtk-icon-theme-name=","");
                    ReplaceStr(buffer,"gtk-icon-theme-name","");
//                    printf("gtk3-icon-theme-name: %s\n",buffer);
                    sprintf(icon_gtk3,"/usr/share/%s/",buffer);
                }
                fgets(buffer,4096,fp);
                for (i=0;i<4096;i++)
                    if (buffer[i]=='\n') buffer[i]='\0';
            }
        }
        fclose(fp);
    }
    if (access("/etc/gtk-2.0/settings.ini",0)!=-1)
    {
        fp=fopen("/etc/gtk-2.0/settings.ini","r");
        if(fp==NULL) 
        {
            printf("can't open /etc/gtk-2.0/settings.ini\n");
        }
        else
        {
            fgets(buffer,4096,fp);
            for (i=0;i<4096;i++)
                if (buffer[i]=='\n') buffer[i]='\0';
            while ( ! feof(fp) )
            {
                sprintf(l11,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);
                if (strcmp(l19,"gtk-icon-theme-name")==0 )
                {
                    ReplaceStr(buffer,"gtk-icon-theme-name = ","");
                    ReplaceStr(buffer,"gtk-icon-theme-name= ","");
                    ReplaceStr(buffer,"gtk-icon-theme-name =","");
                    ReplaceStr(buffer,"gtk-icon-theme-name=","");
                    ReplaceStr(buffer,"gtk-icon-theme-name","");
//                    printf("gtk2-icon-theme-name: %s\n",buffer);
                    sprintf(icon_gtk2,"/usr/share/%s/",buffer);
                }
                fgets(buffer,4096,fp);
                for (i=0;i<4096;i++)
                    if (buffer[i]=='\n') buffer[i]='\0';
            }
        }
        fclose(fp);
    }
    sprintf(icon_file,"%s/.icon-DE/icon-de.rc",home);
    if (access(icon_file,0)!=-1)
    {
        fp=fopen(icon_file,"r");
    }
    else if (access("usr/share/icon-DE/icon-de.rc",0)!=-1)
        fp=fopen("usr/share/icon-DE/icon-de.rc","r");
    if (fp==NULL)
    {
        printf("can't open ~/.icon-DE/icon-de.rc\n");
        sprintf(full_path_icon,"N/A");
        return full_path_icon;
    }
    fgets(buffer,4096,fp);
    for (i=0;i<4096;i++)
        if (buffer[i]=='\n') buffer[i]='\0';
    while ( ! feof(fp) )
    {
//        printf("%s\n",buffer);
        sprintf(l11,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);
        if (strcmp(l11,"icon_path1:")==0 )
        {
            ReplaceStr(buffer,"icon_path1:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[0],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[0],"%s",icon_gtk2);
            else    
                sprintf(icon_path[0],"%s",buffer);
        }

        if (strcmp(l11,"icon_path2:")==0 )
        {
            ReplaceStr(buffer,"icon_path2:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[1],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[1],"%s",icon_gtk2);
            else    
                sprintf(icon_path[1],"%s",buffer);
        }

        if (strcmp(l11,"icon_path3:")==0 )
        {
            ReplaceStr(buffer,"icon_path3:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[2],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[2],"%s",icon_gtk2);
            else    
                sprintf(icon_path[2],"%s",buffer);
        }

        if (strcmp(l11,"icon_path4:")==0 )
        {
            ReplaceStr(buffer,"icon_path4:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[3],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[3],"%s",icon_gtk2);
            else    
                sprintf(icon_path[3],"%s",buffer);
        }

        if (strcmp(l11,"icon_path5:")==0 )
        {
            ReplaceStr(buffer,"icon_path5:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[4],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[4],"%s",icon_gtk2);
            else    
                sprintf(icon_path[4],"%s",buffer);
        }

        if (strcmp(l11,"icon_path6:")==0 )
        {
            ReplaceStr(buffer,"icon_path6:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[5],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[5],"%s",icon_gtk2);
            else    
                sprintf(icon_path[5],"%s",buffer);
        }

        if (strcmp(l11,"icon_path7:")==0 )
        {
            ReplaceStr(buffer,"icon_path7:","");
            if (strcmp(buffer,"GTK3_DEFAULT")==0 )
                sprintf(icon_path[6],"%s",icon_gtk3);
            else if (strcmp(buffer,"GTK2_DEFAULT")==0 )
                sprintf(icon_path[6],"%s",icon_gtk2);
            else    
                sprintf(icon_path[6],"%s",buffer);
        }

        if (strcmp(l11,"icon_size1:")==0 )
        {
            ReplaceStr(buffer,"icon_size1:","");
            sprintf(icon_find1[0],"%s",buffer);
        }

        if (strcmp(l11,"icon_size2:")==0 )
        {
            ReplaceStr(buffer,"icon_size2:","");
            sprintf(icon_find1[1],"%s",buffer);
        }

        if (strcmp(l11,"icon_size3:")==0 )
        {
            ReplaceStr(buffer,"icon_size3:","");
            sprintf(icon_find1[2],"%s",buffer);
        }

        if (strcmp(l11,"icon_size4:")==0 )
        {
            ReplaceStr(buffer,"icon_size4:","");
            sprintf(icon_find1[3],"%s",buffer);
        }

        if (strcmp(l11,"icon_size5:")==0 )
        {
            ReplaceStr(buffer,"icon_size5:","");
            sprintf(icon_find1[4],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind1:")==0 )
        {
            ReplaceStr(buffer,"icon_kind1:","");
            sprintf(icon_find2[0],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind2:")==0 )
        {
            ReplaceStr(buffer,"icon_kind2:","");
            sprintf(icon_find2[1],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind3:")==0 )
        {
            ReplaceStr(buffer,"icon_kind3:","");
            sprintf(icon_find2[2],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind4:")==0 )
        {
            ReplaceStr(buffer,"icon_kind4:","");
            sprintf(icon_find2[3],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind5:")==0 )
        {
            ReplaceStr(buffer,"icon_kind5:","");
            sprintf(icon_find2[4],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind6:")==0 )
        {
            ReplaceStr(buffer,"icon_kind6:","");
            sprintf(icon_find2[5],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind7:")==0 )
        {
            ReplaceStr(buffer,"icon_kind7:","");
            sprintf(icon_find2[6],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind8:")==0 )
        {
            ReplaceStr(buffer,"icon_kind8:","");
            sprintf(icon_find2[7],"%s",buffer);
        }

        if (strcmp(l11,"icon_kind9:")==0 )
        {
            ReplaceStr(buffer,"icon_kind9:","");
            sprintf(icon_find2[8],"%s",buffer);
        }

        if (strcmp(l11,"icon_kinda:")==0 )
        {
            ReplaceStr(buffer,"icon_kinda:","");
            sprintf(icon_find2[9],"%s",buffer);
        }

        fgets(buffer,4096,fp);
        for (i=0;i<4096;i++)
            if (buffer[i]=='\n') buffer[i]='\0';
    }
    fclose(fp);
    have_find_icon=0;
//    printf("%s%s%s%s.png",icon_path[0],icon_find1[0],icon_find2[0],icon_name);
    for (i=0;i<7;i++)
    {
        for (m=0;m<5;m++)
        {
            for (n=0;n<10;n++)
            {
                sprintf(icon_file,"%s%s%s%s.png",icon_path[i],icon_find1[m],icon_find2[n],icon_name);
                if (access(icon_file,0)!=-1)
                {
//                    printf("FIND:%s\n",icon_file);
                    have_find_icon=1;
                    sprintf(full_path_icon,"%s",icon_file);
                    break;
                }
                sprintf(icon_file,"%s%s%s%s.xpm",icon_path[i],icon_find1[m],icon_find2[n],icon_name);
                if (access(icon_file,0)!=-1)
                {
//                    printf("FIND:%s\n",icon_file);
                    have_find_icon=1;
                    sprintf(full_path_icon,"%s",icon_file);
                    break;
                }
                sprintf(icon_file,"%s%s%s%s",icon_path[i],icon_find1[m],icon_find2[n],icon_name);
                if (access(icon_file,0)!=-1)
                {
//                    printf("FIND:%s\n",icon_file);
                    have_find_icon=1;
                    sprintf(full_path_icon,"%s",icon_file);
                    break;
                }
            }
            if (have_find_icon==1) break;
        }
        if (have_find_icon==0)
        {
            sprintf(icon_file,"%s%s.png",icon_path[i],icon_name);
            if (access(icon_file,0)!=-1)
            {
//                printf("FIND:%s\n",icon_file);
                have_find_icon=1;
                sprintf(full_path_icon,"%s",icon_file);
                break;
            }
            sprintf(icon_file,"%s%s.xpm",icon_path[i],icon_name);
            if (access(icon_file,0)!=-1)
            {
//                printf("FIND:%s\n",icon_file);
                have_find_icon=1;
                sprintf(full_path_icon,"%s",icon_file);
                break;
            }
            sprintf(icon_file,"%s%s",icon_path[i],icon_name);
            if (access(icon_file,0)!=-1)
            {
//                printf("FIND:%s\n",icon_file);
                have_find_icon=1;
                sprintf(full_path_icon,"%s",icon_file);
                break;
            }
        } else
            break;
    }
//    printf("%s\n",icon_name);
    if (have_find_icon==0)
    for (i=0;i<7;i++)
    {
        sprintf(icon_file,"%sindex.theme",icon_path[i]);
        if (access(icon_file,0)!=-1)
        {
            fp2=fopen(icon_file,"r");
            if(fp2==NULL) 
            {
                printf("can't open %sindex.theme\n",icon_path[i]);
            }
            else
            {
                fgets(buffer,4096,fp2);
                for (n=0;n<4096;n++)
                if (buffer[n]=='\n') buffer[n]='\0';
                while ( ! feof(fp2) )
                {
                    sprintf(l11,"%c%c%c%c%c%c%c%c%c%c%c",buffer[0],buffer[1],buffer[2],buffer[3],buffer[4],buffer[5],buffer[6],buffer[7],buffer[8],buffer[9],buffer[10]);
                    if (strcmp(l11,"Directories")==0 )
                    {
                        ReplaceStr(buffer,"Directories = ","");
                        ReplaceStr(buffer,"Directories= ","");
                        ReplaceStr(buffer,"Directories =","");
                        ReplaceStr(buffer,"Directories=","");
                        ReplaceStr(buffer,"Directories","");
                        break;
                    }
                    fgets(buffer,4096,fp2);
                        for (n=0;n<4096;n++)
                    if (buffer[n]=='\n') buffer[n]='\0';
                }
            }
            fclose(fp2);
            for (m=0;m<256;m++)
                s_dir[m]='\0';
            for (m=0;m<4096;m++)
            {
                if ((buffer[m]!=',') and (buffer[m]!='\0'))
                {
                    sprintf(s_dir,"%s%c",s_dir,buffer[m]);
                } else
                {
                    sprintf(icon_file,"%s%s/%s",icon_path[i],s_dir,icon_name);
                    //printf("%s%s/%s\n",icon_path[i],s_dir,icon_name);
                    if (access(icon_file,0)!=-1)
                    {
        //                printf("%s\n",icon_file);
                        have_find_icon=1;
                        sprintf(full_path_icon,"%s",icon_file);
                        break;
                    }
                    sprintf(icon_file,"%s%s/%s.png",icon_path[i],s_dir,icon_name);
                    if (access(icon_file,0)!=-1)
                    {
//                        printf("%s\n",icon_file);
                        have_find_icon=1;
                        sprintf(full_path_icon,"%s",icon_file);
                        break;
                    }

                    sprintf(icon_file,"%s%s/%s.xpm",icon_path[i],s_dir,icon_name);
                    if (access(icon_file,0)!=-1)
                    {
//                       printf("%s\n",icon_file);
                        have_find_icon=1;
                        sprintf(full_path_icon,"%s",icon_file);
                        break;
                    }
                    if (buffer[m]=='\0') break;
                    for (n=0;n<256;n++)
                        s_dir[n]='\0';
                }
            }
            if (have_find_icon==1)
                break;
            else
            {
                for (n=0;n<256;n++)
                    s_dir[n]='\0';
            }
        }
    }
    return full_path_icon;

}

