// g++ -o ./bin/icon-bord ./src/icon-bord.c  `pkg-config --cflags --libs glib-2.0` -lX11 -lImlib2 -lXmu
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>
#include <X11/Xos.h>
#include <X11/cursorfont.h>
#include <X11/Xmu/WinUtil.h>
#include <glib-2.0/glib.h>

#include "./other_src/MWMHints.h"

Display                        *disp;
Window                          win;
Visual                         *vis;
Colormap                        cm;
int                            depth;
XSetWindowAttributes attr;
int i3;

#include "./other_src/wm_ctrl.c"


int main(int argc, char **argv)
{
    const char                 *display_name = getenv("DISPLAY");
    char                       *skip;
    if (display_name == NULL)
        display_name = ":0";
    disp = XOpenDisplay(display_name);
    if (disp == NULL)
    {
        fprintf(stderr, "Can't open display %s\n", display_name);
        return 1;
    }
//    Imlib_Image                temp, temp2;

    char *title;
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));
    int bord=1;
    double trans_wind=0.75;
    if ( strcmp(home,"") == 0 )
    {
        printf("fatal error: no /home/xxx found!\n");
        return 1;
    }
//----arguments x y width height lower/raise(0/1) picture hidemode
    if ( argc != 5 )
    {
        printf("usage: title skip bord(0/1) trans_wind(0-1) \n");
        return 1;
    }
    title=argv[1];
    skip=argv[2];
    sscanf(argv[3], "%d", &bord);
    trans_wind=atof(argv[4]);
    
    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));
                // text

    attr.override_redirect=True;

    win=XCreateWindow(disp,DefaultRootWindow(disp),-10,-10,5,5,0,0,0,CopyFromParent,CWBackingStore|CWOverrideRedirect|CWEventMask,&attr);
    XSelectInput(disp, win, ButtonPressMask | ButtonReleaseMask | ButtonMotionMask | PointerMotionMask | ExposureMask | EnterWindowMask | LeaveWindowMask);
    XMapWindow(disp, win);

    XRaiseWindow(disp,win);
    XResizeWindow(disp, win, 5, 5);
    XSync(disp, False);

    unsigned int i=1;
    i3=1;
    int xfd = ConnectionNumber(disp);
    fd_set rfds;
    long ticks;
                        MWMHints mwmhints;
                        Atom prop;

    struct timeval now, tm,LastTime;
    gettimeofday(&LastTime, 0);

    int cg=0;

//    printf("ok\n");
    if (bord==1)
    {
    } else {
	
    }
    list_windows(disp,skip);
    while (1)
    {
        if ((cg==1) or (i3>=10))
        {
            sleep(10);
            return 1;
        }    
        FD_ZERO(&rfds);
        FD_SET(xfd, &rfds);
        gettimeofday(&now, 0);
        //LastTime 是 timeval 类型的变量,保存上次时间
        //ticks 的单位是毫秒 millisecond
        ticks=(now.tv_sec-LastTime.tv_sec)*1000+(now.tv_usec-LastTime.tv_usec)/1000;
        if (ticks>=2000)
        {
            i3=i3+1;
            list_windows(disp,skip);
            gettimeofday(&LastTime, 0);
            memset(&mwmhints, 0, sizeof(mwmhints));
            prop = XInternAtom(disp, "_MOTIF_WM_HINTS", False);
            mwmhints.flags = MWM_HINTS_DECORATIONS;
            mwmhints.decorations = 0;
            for (i=0;i<win_count;i++)
            {
                if (win_pid_list[i]!=0)
                if (strstr(get_window_title(disp,win_pid_list[i]),title)!=NULL)
                {
                     cg=1;
                     if (bord==1)
                         XChangeProperty(disp, win_pid_list[i], prop, prop, 32, PropModeReplace,
                                        (unsigned char *) &mwmhints,
                                        PROP_MWM_HINTS_ELEMENTS);
                     char app[2000];
                     sprintf(app , "icon-trans %f 2 &" ,trans_wind);
                     system(app);	
                }
            }
        }
//如果到期则调用有关函数
//select 等待 100 毫秒
        tm.tv_sec=0l;
        tm.tv_usec=100000l;
        select(xfd + 1, &rfds, 0, 0, &tm);
    } 
    return 0;
}

