//g++ -o ./icon-wmvm ./icon-wmvm.c -lX11    `pkg-config --cflags --libs glib-2.0`
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <assert.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xatom.h>
#include <glib-2.0/glib.h>


Display                        *disp;
Window                            win;
Visual                         *vis;
Colormap                        cm;
int                                 depth;
XSetWindowAttributes attr;
char *appToRun;
static gboolean envir_utf8; //2012.04.18

static void window_set_title (Display *disp, Window win, /* {{{ */
                const char *title,const char mode) {
        gchar *title_utf8;
        gchar *title_local;

        if (envir_utf8) {
                title_utf8 = (gchar*)g_strdup(title);
                title_local = NULL;
        }
        else {
                if (! (title_utf8 = (gchar*)g_locale_to_utf8(title, -1, NULL, NULL, NULL))) {
                        title_utf8 = (gchar*)g_strdup(title);
                }
                title_local = g_strdup(title);
        }
        
        if (mode == 'T' || mode == 'N') {
                /* set name */
                if (title_local) {
                        XChangeProperty(disp, win, XA_WM_NAME, XA_STRING, 8, PropModeReplace,
                                        (const unsigned char*)title_local, strlen(title_local));
                }
                else {
                        XDeleteProperty(disp, win, XA_WM_NAME);
                }
                XChangeProperty(disp, win, XInternAtom(disp, "_NET_WM_NAME", False), 
                                XInternAtom(disp, "UTF8_STRING", False), 8, PropModeReplace,
                                (const unsigned char*)title_utf8, strlen(title_utf8));
        }

        if (mode == 'T' || mode == 'I') {
                /* set icon name */
                if (title_local) {
                        XChangeProperty(disp, win, XA_WM_ICON_NAME, XA_STRING, 8, PropModeReplace,
                                        (const unsigned char*)title_local, strlen(title_local));
                }
                else {
                        XDeleteProperty(disp, win, XA_WM_ICON_NAME);
                }
                XChangeProperty(disp, win, XInternAtom(disp, "_NET_WM_ICON_NAME", False), 
                                XInternAtom(disp, "UTF8_STRING", False), 8, PropModeReplace,
                                (const unsigned char*)title_utf8, strlen(title_utf8));
        }
        
        g_free(title_utf8);
        g_free(title_local);
        
}/*}}}*/



int main(int argc, char **argv)
{
     int                                 w, h;
     XEvent                            ev;
     const char                 *display_name = getenv("DISPLAY");
//     char                                text[4096];
//     int    text_w, text_h;

     if (display_name == NULL)
             display_name = ":0";
     disp = XOpenDisplay(display_name);
     if (disp == NULL)
         {
             fprintf(stderr, "Can't open display %s\n", display_name);
             return 1;
         }
    char home[1024];
    sprintf(home,"%s",getenv("HOME"));

    int screen=DefaultScreen(disp);
    int screenWidth=0;
    screenWidth=XDisplayWidth(disp,screen);
    screenWidth=64;
    int screenHeight;
    screenHeight=64;
    int screenX=10;
    int screenY=10;
    int disp_id=6;
    char *term_cmd;
    char *term_opt='\0';
    sprintf(term_opt,"N/A");
    char *term_shell='\0';
    sprintf(term_shell,"N/A");
    char run_cmd[1024];
    char r_nc[]="WMVM";

//----arguments x y width height lower/raise(0/1) picture appToRun
    if ( ( argc != 7 ) and ( argc != 8 ) and ( argc != 9 )){
        printf("usage: icon-wmvm x y width height display_id term_cmd [term_opt] [term_shell] \n");
        return 1;
    }

    sscanf(argv[1], "%d", &screenX);
    sscanf(argv[2], "%d", &screenY);
    sscanf(argv[3], "%d", &screenWidth);
    sscanf(argv[4], "%d", &screenHeight);
    sscanf(argv[5], "%d", &disp_id);
    term_cmd = argv[6];
    if ( argc >= 8 ) term_opt = argv[7];
    if ( argc == 9 ) term_shell = argv[8];

    vis = DefaultVisual(disp, DefaultScreen(disp));
    depth = DefaultDepth(disp, DefaultScreen(disp));
    cm = DefaultColormap(disp, DefaultScreen(disp));


    win = XCreateSimpleWindow(disp,
                                    RootWindow(disp, screen),
                                    screenX, screenY,
                                    screenWidth, screenHeight,
                                    1, BlackPixel(disp, screen),
                                    WhitePixel(disp, screen));
    window_set_title (disp, win,"WM virtualization",'T'); 
    assert(win);
    XClassHint classhints;
    classhints.res_name = r_nc;
    classhints.res_class = r_nc;
    XSetClassHint(disp,win,&classhints);

    XMapWindow(disp, win);
    XRaiseWindow(disp,win);

     /**
        * Start rendering
        */


//--
    w=screenWidth;
    h=screenHeight;
    XResizeWindow(disp, win, w, h);
    XSync(disp, False);
    sleep(1);
    sprintf(run_cmd,"Xephyr :%d -parent %ld -keybd ephyr,,,xkbmodel=pc105,xkblayout=us,xkbrules=evdev,xkboption=euro -host-cursor -dpi 96    -ac &",disp_id,win);
    system(run_cmd);
    sleep(3);
    sprintf(run_cmd,"DISPLAY=:%d %s",disp_id,term_cmd);
    if (strcmp(term_opt,"N/A")!=0)
        sprintf(run_cmd,"%s -%s",run_cmd,term_opt);
    if (strcmp(term_shell,"N/A")!=0)
        sprintf(run_cmd,"%s %s",run_cmd,term_shell);
//    printf("%s &\n",run_cmd);
    sprintf(run_cmd,"%s &",run_cmd);
    system(run_cmd);
    system("icon-wmcl \"virtualization\" \" \" ");
    while (1)
    {
        do
        {
            XNextEvent(disp, &ev);
            switch (ev.type)
            {
            case Expose:
                break;
            case MotionNotify:
                break;
            default:
                break;
            case EnterNotify:
                break;
            case LeaveNotify:		
                break;
            case ButtonPress:				
                break;
            case DestroyNotify:
                system("killall -9 Xephyr");
                break;
            }
        } /* End else*/
        while (XPending(disp));
    }
    return 0;
}
